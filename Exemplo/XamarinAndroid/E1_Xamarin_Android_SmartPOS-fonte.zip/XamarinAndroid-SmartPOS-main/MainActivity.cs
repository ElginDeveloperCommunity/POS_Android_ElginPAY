﻿using System;
using Android.App;
using Android.OS;
using Android.Runtime;
using AndroidX.AppCompat.App;
using Android.Widget;
using Android.Util;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme.NoActionBar", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_main);

            LinearLayout btnPrinterMenu = FindViewById<LinearLayout>(Resource.Id.btnPrinterMenu);
            LinearLayout btnElginPay = FindViewById<LinearLayout>(Resource.Id.btnElginPay);
            LinearLayout btnDigitalWallet = FindViewById<LinearLayout>(Resource.Id.btnDigitalWallet);
            LinearLayout btnNFCE = FindViewById<LinearLayout>(Resource.Id.btnNFCE);
            LinearLayout btnBarcodeReader = FindViewById<LinearLayout>(Resource.Id.btnBarcodeReader);

            btnPrinterMenu.Click += delegate { GoToActivity(typeof(PrinterMenu)); };
            btnElginPay.Click += delegate { GoToActivity(typeof(ElginPay)); };
            btnDigitalWallet.Click += delegate { GoToActivity(typeof(CarteiraDigital)); };
            btnNFCE.Click += delegate { GoToActivity(typeof(NFCE)); };
            btnBarcodeReader.Click += delegate { GoToActivity(typeof(BarcodeReader)); };
        }
        public void GoToActivity(Type myActivity)
        {
            StartActivity(myActivity);
        }

        public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        {
            Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

            base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        }

        protected override void OnDestroy()
        {
            base.OnDestroy();
            Log.Debug("OnDestroy: ", "STOP PRINTER");
            if (PrinterMenu.printerService != null)
                PrinterMenu.printerService.PrinterStop();
        }

        protected override void OnResume()
        {
            base.OnResume();
            Log.Debug("OnResume: ", "STOP PRINTER");
            if (PrinterMenu.printerService != null)
            {
                Log.Debug("OnResume: ", "STOP PRINTER2");
                PrinterMenu.printerService.PrinterStop();
            }
        }
    }
}
