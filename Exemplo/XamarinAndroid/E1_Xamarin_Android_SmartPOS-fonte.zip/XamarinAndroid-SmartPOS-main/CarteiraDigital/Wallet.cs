﻿using Newtonsoft.Json;

namespace XamarinAndroid_SmartPOS
{
    public class Wallet
    {
        [JsonProperty(PropertyName = "name")]
        public string name { get; set; }
    }
}