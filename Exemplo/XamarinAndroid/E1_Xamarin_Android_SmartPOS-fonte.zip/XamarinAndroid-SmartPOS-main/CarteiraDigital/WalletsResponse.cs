﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace XamarinAndroid_SmartPOS
{
    class WalletsResponse
    {
        [JsonProperty(PropertyName = "wallets")]
        public List<Wallet> wallets { get; set; }
    }
}