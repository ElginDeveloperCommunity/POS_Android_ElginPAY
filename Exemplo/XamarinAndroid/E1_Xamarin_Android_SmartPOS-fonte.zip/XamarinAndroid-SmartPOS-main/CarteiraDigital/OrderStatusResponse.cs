﻿using Newtonsoft.Json;

namespace XamarinAndroid_SmartPOS
{
    public class OrderStatusResponse
    {
        [JsonProperty(PropertyName = "status")]
        public string status { get; set; }
    }
}