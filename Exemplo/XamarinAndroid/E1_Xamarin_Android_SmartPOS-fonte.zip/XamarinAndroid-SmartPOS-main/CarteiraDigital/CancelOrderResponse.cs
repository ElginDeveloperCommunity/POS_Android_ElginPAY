﻿using Newtonsoft.Json;

namespace XamarinAndroid_SmartPOS
{
    public class CancelOrderResponse
    {
        [JsonProperty(PropertyName = "status")]
        public string status { get; set; }
    }
}