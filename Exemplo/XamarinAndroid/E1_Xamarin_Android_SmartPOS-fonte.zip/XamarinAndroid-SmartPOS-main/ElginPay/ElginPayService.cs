﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Util;
using Android.Widget;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace XamarinAndroid_SmartPOS
{
    class ElginPayService
    {
        private Handler handler;
        private Context context;
        readonly Com.Elgin.E1.Pagamento.ElginPay pagamento = new Com.Elgin.E1.Pagamento.ElginPay();

        public ElginPayService(Context c)
        {
            context = c;

            //USADO PARA ENVIAR E PROCESSAR MENSAGENS
            handler = new CustomHandler(Looper.MainLooper, this);
        }

        public void IniciarPagamentoDebito(string valor)
        {
            Toast.MakeText(context, "Debito", ToastLength.Long).Show();
            pagamento.IniciarPagamentoDebito(valor, context, handler);
        }

        public void IniciarPagamentoCredito(string valor, int tipoFinanciamento)
        {
            Toast.MakeText(context, "Crédito", ToastLength.Long).Show();
            pagamento.InciarPagamentoCredito(valor, tipoFinanciamento, context, handler);
        }

        public void IniciarCancelamentoVenda(string valor)
        {
            Toast.MakeText(context, "Cancelamento", ToastLength.Long).Show();
            pagamento.IniciarCancelamentoVenda(valor, context, handler);
        }

        public void IniciarOperacaoAdministrativa()
        {
            Toast.MakeText(context, "Administrativa", ToastLength.Long).Show();
            pagamento.IniciarOperacaoAdministrativa(context, handler);
        }

        private class CustomHandler : Handler
        {
            ElginPayService ctx;
            public CustomHandler(Looper l, ElginPayService ctx) : base(l)
            {
                this.ctx = ctx;
            }

            public override void HandleMessage(Message msg)
            {
                // JObject.Parse("{number:1000, str:'string', array: [1,2,3,4,5,6]}");
                base.HandleMessage(msg);
                string saida = (string)msg.Obj;
                // Toast.MakeText(ctx.context, saida, ToastLength.Long).Show();

                dynamic json = JObject.Parse(saida);
                //Log.Debug("Retorno", saida);
                string comprovanteGraficoLojista = (string) json.comprovanteGraficoLojista;
                // Log.Debug("Retorno_1", "" + saida);
                // Log.Debug("Retorno_2", "" + comprovanteGraficoLojista);
            }
        }
    }
}