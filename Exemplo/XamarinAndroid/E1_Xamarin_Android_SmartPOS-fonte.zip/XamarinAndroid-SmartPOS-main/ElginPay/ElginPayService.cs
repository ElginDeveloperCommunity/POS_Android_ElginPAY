﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Util;
using Android.Widget;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace XamarinAndroid_SmartPOS
{
    class ElginPayService
    {
        private Handler handler;
        private ElginPay elginPayActivity;
        readonly Com.Elgin.E1.Pagamento.ElginPay pagamento = new Com.Elgin.E1.Pagamento.ElginPay();

        public ElginPayService(ElginPay c)
        {
            elginPayActivity = c;

            //USADO PARA ENVIAR E PROCESSAR MENSAGENS
            handler = new CustomHandler(Looper.MainLooper, this);
        }

        public void IniciarPagamentoDebito(string valor)
        {
            Toast.MakeText(elginPayActivity, "Debito", ToastLength.Long).Show();
            pagamento.IniciarPagamentoDebito(valor, elginPayActivity, handler);
        }

        public void IniciarPagamentoCredito(string valor, int tipoFinanciamento)
        {
            Toast.MakeText(elginPayActivity, "Crédito", ToastLength.Long).Show();
            pagamento.InciarPagamentoCredito(valor, tipoFinanciamento, elginPayActivity, handler);
        }

        public void IniciarCancelamentoVenda(string valor)
        {
            Toast.MakeText(elginPayActivity, "Cancelamento", ToastLength.Long).Show();
            pagamento.IniciarCancelamentoVenda(valor, elginPayActivity, handler);
        }

        public void IniciarOperacaoAdministrativa()
        {
            Toast.MakeText(elginPayActivity, "Administrativa", ToastLength.Long).Show();
            pagamento.IniciarOperacaoAdministrativa(elginPayActivity, handler);
        }

        private class CustomHandler : Handler
        {
            ElginPayService elginPayService;
            public CustomHandler(Looper l, ElginPayService elginPayService) : base(l)
            {
                this.elginPayService = elginPayService;
            }

            public override void HandleMessage(Message msg)
            {
                base.HandleMessage(msg);
                string saida = (string)msg.Obj;
                // Toast.MakeText(elginPayService.context, saida, ToastLength.Long).Show();

                dynamic json = JObject.Parse(saida);

                // Acessando campos do JSON
                string comprovanteGraficoLojista = (string) json.comprovanteGraficoLojista;

                elginPayService.elginPayActivity.SaveElginPayData(saida);
            }
        }
    }
}