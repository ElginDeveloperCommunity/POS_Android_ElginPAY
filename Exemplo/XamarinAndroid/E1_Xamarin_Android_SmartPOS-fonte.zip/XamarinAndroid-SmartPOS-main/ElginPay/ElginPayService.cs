﻿// compile with: /reference:e1_v2.0.4_release.dll;
using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.Graphics;
using Android.OS;
using Android.Text;
using Android.Util;
using Android.Views.InputMethods;
using Android.Widget;
using Java.IO;
using Java.Util;
using Java.Text;
using System.IO;
using IOException = Java.IO.IOException;
using File = Java.IO.File;
using BR.Com.Setis.Interfaceautomacao;

namespace XamarinAndroid_SmartPOS
{
    class ElginPayService
    {
        private readonly Handler handler;
        private readonly ElginPay elginPayActivity;
        readonly Com.Elgin.E1.Pagamento.ElginPay pagamento = new Com.Elgin.E1.Pagamento.ElginPay();

        public ElginPayService(ElginPay c)
        {
            elginPayActivity = c;

            //USADO PARA ENVIAR E PROCESSAR MENSAGENS
            handler = new CustomHandler(Looper.MainLooper, this);
        }

        public void IniciarPagamentoDebito(string valor)
        {
            Toast.MakeText(elginPayActivity, "Debito", ToastLength.Long).Show();
            pagamento.IniciaVendaDebito(valor, elginPayActivity, handler);
        }

        public void IniciarPagamentoCredito(string valor, int tipoFinanciamento, int numeroParcelas)
        {
            Toast.MakeText(elginPayActivity, "Crédito", ToastLength.Long).Show();
            pagamento.IniciaVendaCredito(valor, tipoFinanciamento, numeroParcelas, elginPayActivity, handler);
        }

        public void IniciarCancelamentoVenda(string valor)
        {
            //Data do dia de hoje:
            Date date = new Date();

            //Objeto capaz de formatar a date para o formato aceito pelo Elgin Pay ("dd/mm/aa")
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            //Aplicando formatação
            string todayDate = dateFormat.Format(date);

            // Declare your builder here -
            AlertDialog.Builder builder = new AlertDialog.Builder(elginPayActivity);

            //Definindo título do AlertDialog
            builder.SetTitle("Código de Referência:");

            // Criando um EditText para pegar o input do usuário na caixa de diálogo
            EditText input = new EditText(elginPayActivity)
            {
                //Configurando o EditText para negrito e configurando o tipo de inserção para apenas número
                Typeface = Typeface.DefaultBold,
                InputType = InputTypes.ClassNumber
            };

            //Tornando o dialógo não-cancelável
            builder.SetCancelable(false);

            builder.SetView(input);

            builder.SetPositiveButton("OK", (senderAlert, args) => {
                string saleRef = input.Text;

                //Setando o foco de para o input do dialógo
                input.RequestFocus();
                InputMethodManager imm = (InputMethodManager)elginPayActivity.GetSystemService(Context.InputMethodService);
                imm.ShowSoftInput(input, ShowFlags.Implicit);

                if (saleRef.Equals(""))
                {
                    ElginPay.AlertMessageStatus(elginPayActivity, "Alert", "O campo código de referência da transação não pode ser vazio! Digite algum valor.");
                    return;
                }
                else
                {
                    Toast.MakeText(elginPayActivity, "Cancelamento", ToastLength.Long).Show();
                    pagamento.IniciaCancelamentoVenda(valor, saleRef, todayDate, elginPayActivity, handler);
                }
            });

            builder.Show();
        }

        public void IniciarOperacaoAdministrativa()
        {
            Toast.MakeText(elginPayActivity, "Administrativa", ToastLength.Long).Show();
            pagamento.IniciaOperacaoAdministrativa(elginPayActivity, handler);
        }

        private File CreateFileFromInputStream(Stream inputStream)
        {
            try
            {
                File f = new File("sdcard/logo2.png");
                OutputStream outputStream = new FileOutputStream(f);
                byte[] buffer = new byte[1024];
                int length = 0;

                while ((length = inputStream.Read(buffer)) > 0)
                {
                    outputStream.Write(buffer, 0, length);
                }

                outputStream.Close();
                inputStream.Close();

                return f;
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }

            return null;
        }

        private Personalizacao ObterPersonalizacao()
        {
            //Processo de personalização do layout
            Personalizacao.Builder pb = new Personalizacao.Builder();
            string corDestaque = "#FED20B"; // AMARELO
            string corPrimaria = "#050609"; // PRETO
            string corSecundaria = "#808080";

            pb.InformaCorFonte(corDestaque);
            pb.InformaCorFonteTeclado(corPrimaria);
            pb.InformaCorFundoToolbar(corDestaque);
            pb.InformaCorFundoTela(corPrimaria);
            pb.InformaCorTeclaLiberadaTeclado(corDestaque);
            pb.InformaCorTeclaPressionadaTeclado(corSecundaria);
            pb.InformaCorFundoTeclado(corPrimaria);
            pb.InformaCorTextoCaixaEdicao(corDestaque);
            pb.InformaCorSeparadorMenu(corDestaque);

            try
            {
                AssetManager am = elginPayActivity.Assets;
                Stream inputStream = am.Open("logo.png");
                File file = CreateFileFromInputStream(inputStream);
                pb.InformaIconeToolbar(file);
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }

            return pb.Build();
        }

        //Métodos de customização

        //Aplica o layout do batpay ao objeto de pagamento
        public void SetCustomLayoutOn()
        {
            pagamento.SetPersonalizacao(ObterPersonalizacao());
        }

        //Aplica um layout padrão ao objeto de pagamento
        public void SetCustomLayoutOff()
        {
            pagamento.SetPersonalizacao(new Personalizacao.Builder().Build());
        }

        private class CustomHandler : Handler
        {
            readonly ElginPayService elginPayService;
            public CustomHandler(Looper l, ElginPayService elginPayService) : base(l)
            {
                this.elginPayService = elginPayService;
            }

            public override void HandleMessage(Message msg)
            {
                base.HandleMessage(msg);
                string saida = (string)msg.Obj;

                // Acessando campos do JSON
                // dynamic json = JObject.Parse(saida);
                // string comprovanteGraficoLojista = (string) json.comprovanteGraficoLojista;
                Log.Debug("HANDLER_RESULT", saida);

                elginPayService.elginPayActivity.SaveElginPayData(saida);
            }
        }
    }
}