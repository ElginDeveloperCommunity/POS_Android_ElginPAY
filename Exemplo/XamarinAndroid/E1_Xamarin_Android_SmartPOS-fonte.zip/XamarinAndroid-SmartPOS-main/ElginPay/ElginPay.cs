﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Util;
using Android.Views;
using Android.Widget;
using AndroidX.AppCompat.Widget;
using AndroidX.AppCompat.Content.Res;
using Java.Lang;
using Java.Math;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "ElginPay")]
    public class ElginPay : Activity
    {
        ElginPayService elginPayService;

        // RETORNO ELGIN PAY
        public static string saidaUltimaTransacao = "";
        
        //Layout Num. parcelas
        LinearLayout numberOfInstallmentsLayout;

        //EDIT TEXTs
        EditText editTextValue;
        EditText editTextNumberOfInstallments;

        //BUTTONS TYPE OF PAYMENTS
        AppCompatButton buttonCreditOption;
        AppCompatButton buttonDebitOption;

        //BUTTONS TYPE OF INSTALLMENTS
        AppCompatButton buttonStoreOption;
        AppCompatButton buttonAdmOption;
        AppCompatButton buttonAvistaOption;
        LinearLayout containerTypeInsatllments;

        //BUTTONS ACTIONS TEF
        Button buttonSendTransaction;
        Button buttonCancelTransaction;
        Button buttonConfigsTransaction;

        //INIT DEFAULT OPTIONS
        string selectedPaymentMethod = "Crédito";
        int selectedInstallmentType = FINANCIAMENTO_A_VISTA;
        int numberOfInstallments = 1;

        // TYPE OF INSTALLMENTS
        private const int FINANCIAMENTO_A_VISTA = 1;
        private const int FINANCIAMENTO_PARCELADO_EMISSOR = 2;
        private const int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 3;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.elgin_pay);

            elginPayService = new ElginPayService(this);

            //Finding LinearLayout to remove conditionally
            numberOfInstallmentsLayout = FindViewById<LinearLayout>(Resource.Id.linearLayoutNumberOfInstallments);

            //INIT EDIT TEXTs
            editTextValue = FindViewById<EditText>(Resource.Id.editTextInputValueTEF);
            editTextNumberOfInstallments = FindViewById<EditText>(Resource.Id.editTextInputNumberOfInstallmentsTEF);

            //INIT BUTTONS TYPES PAYMENTS
            buttonCreditOption = FindViewById<AppCompatButton>(Resource.Id.buttonCreditOption);
            buttonDebitOption = FindViewById<AppCompatButton>(Resource.Id.buttonDebitOption);

            //INIT BUTTONS TYPE INSTALLMENTS
            buttonStoreOption = FindViewById<AppCompatButton>(Resource.Id.buttonStoreOption);
            buttonAdmOption = FindViewById<AppCompatButton>(Resource.Id.buttonAdmOption);
            buttonAvistaOption = FindViewById<AppCompatButton>(Resource.Id.buttonAvistaOption);
            containerTypeInsatllments = FindViewById<LinearLayout>(Resource.Id.containerTypeInsatllments);

            //INIT BUTTONS ACTIONS TEF
            buttonSendTransaction = FindViewById<Button>(Resource.Id.buttonSendTransactionTEF);
            buttonCancelTransaction = FindViewById<Button>(Resource.Id.buttonCancelTransactionTEF);
            buttonConfigsTransaction = FindViewById<Button>(Resource.Id.buttonConfigsTEF);

            //SELECT INITIALS OPTIONS
            buttonCreditOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
            buttonAvistaOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);

            //INIT DEFAULT INPUTS
            editTextValue.AddTextChangedListener(new InputMaskMoney(editTextValue));
            editTextValue.Text = "2000";

            //O padrão da aplicação é iniciar com a opção de pagamento por crédito com parcelamento a vista, portanto o número de parcelas deve ser obrigatoriamente 1
            editTextNumberOfInstallments.Text = String.ValueOf(numberOfInstallments);
            editTextNumberOfInstallments.Enabled = false;

            //SELECT OPTION CREDIT PAYMENT
            buttonCreditOption.Click += delegate
            {
                selectedPaymentMethod = "Crédito";

                buttonCreditOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
                buttonDebitOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);

                //linearLayout of installmentsNumber should be restored
                numberOfInstallmentsLayout.Visibility = ViewStates.Visible;
                editTextNumberOfInstallments.Text = "1";
            };

            //SELECT OPTION DEBIT PAYMENT
            buttonDebitOption.Click += delegate
            {
                selectedPaymentMethod = "Débito";
                buttonCreditOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonDebitOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);

                //linearLayout of installmentsNumber shold be gone:
                numberOfInstallmentsLayout.Visibility = ViewStates.Gone;
            };

            //SELECT OPTION STORE INSTALLMENT
            buttonStoreOption.Click += delegate
            {
                selectedInstallmentType = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

                buttonStoreOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
                buttonAdmOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAvistaOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);

                editTextNumberOfInstallments.Text = "2";
                numberOfInstallments = 1;
                editTextNumberOfInstallments.Enabled = true;
            };

            //SELECT OPTION ADM INSTALLMENT
            buttonAdmOption.Click += delegate
            {
                selectedInstallmentType = FINANCIAMENTO_PARCELADO_EMISSOR;

                buttonStoreOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAdmOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
                buttonAvistaOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                
                editTextNumberOfInstallments.Text = "2";
                numberOfInstallments = 1;
                editTextNumberOfInstallments.Enabled = true;
            };

            //SELECT OPTION AVISTA INSTALLMENT
            buttonAvistaOption.Click += delegate
            {
                selectedInstallmentType = FINANCIAMENTO_A_VISTA;

                buttonStoreOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAdmOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAvistaOption.SupportBackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);

                editTextNumberOfInstallments.Text = "1";
                numberOfInstallments = 1;
                editTextNumberOfInstallments.Enabled = false;
            };

            /**
             * isValueValidToElginPay() é uma checagem feita antes de qualquer transação para checar se o valor a ser enviado é superior a R$ 1.00 e impedir transação caso seja.
             */
            //SELECT BUTTON SEND TRANSACTION
            buttonSendTransaction.Click += delegate
            {
                //Checa se o número de parcelas é valido
                if (IsValueValidToElginPay() && IsInstallmentsFieldValid())
                {
                    StartActionTEF("SALE");
                }
            };

            //SELECT BUTTON CANCEL TRANSACTION
            buttonCancelTransaction.Click += delegate
            {
                if (IsValueValidToElginPay())
                {
                    StartActionTEF("CANCEL");
                }
            };

            //SELECT BUTTON CONFIGS TRANSACTION
            buttonConfigsTransaction.Click += delegate
            {
                elginPayService.IniciarOperacaoAdministrativa();
            };
        }

        // Armazena e exibe retorno da última operação
        public void SaveElginPayData(string retornoOperacaoElginPay)
        {
            saidaUltimaTransacao = retornoOperacaoElginPay;

            AlertDialog alertDialog = new AlertDialog.Builder(this).Create();
            alertDialog.SetTitle("DADOS ELGIN PAY");
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });

            // Adicionar Scroll para poder ver conteúdo completo
            ScrollView scrollView = new ScrollView(this);

            TextView textView = new TextView(this);
            textView.Text = retornoOperacaoElginPay;
            textView.SetPadding(30, 5, 30, 0);

            LinearLayout view = new LinearLayout(this);
            view.Orientation = Orientation.Vertical;
            view.AddView(textView);
            scrollView.AddView(view);

            alertDialog.SetView(scrollView);
            alertDialog.Show();
        }

        public void StartActionTEF(string action)
        {
            SendElginPayParams(action);
        }

        public void SendElginPayParams(string action)
        {
            //Remove a vírgula do campo referente ao valor, uma vez que o ElginPay espera o valore em centavos (ex: 1850 para R$ 18,50)
            string inputCleanForElginPay = editTextValue.Text.Replace(",", "").Trim();

            // Valor deve ser enviado sem pontuação. 20.00 -> 2000
            if (action.Equals("SALE"))
            {
                //Na opçao de pagamento por credito na lib E1 de versao 1.0.16 ou superior é necessario a data em que a venda foi realizada como parametro para realizar o cancelamento, para fins de simplificaçao e tomando que o app experience da Elgin
                //se trata de um exemplo iremos enviar sempre a data do dia atual.
                if (selectedPaymentMethod == "Crédito")
                {
                    elginPayService.IniciarPagamentoCredito(inputCleanForElginPay, selectedInstallmentType, numberOfInstallments);
                }
                else if (selectedPaymentMethod == "Débito")
                {
                    elginPayService.IniciarPagamentoDebito(inputCleanForElginPay);
                }
            }
            if (action.Equals("CANCEL"))
            {
                elginPayService.IniciarCancelamentoVenda(inputCleanForElginPay);
            }
        }

        public static void OptionReturnElginPay(Context ctx, string retorno, string via_impressao)
        {
            if (retorno != null)
            {
                if (retorno.Equals("Transacao autorizada"))
                {
                    string imageViaBase64 = via_impressao;

                    byte[] decodedString = Base64.Decode(imageViaBase64, Base64Flags.Default);
                    Bitmap decodedByte = BitmapFactory.DecodeByteArray(decodedString, 0, decodedString.Length);

                    AlertImage(ctx, "Comprovante ElginPAY", decodedByte);
                    AlertMessageStatus(ctx, "Alert", retorno);
                }
                else
                {
                    AlertMessageStatus(ctx, "Alert", retorno);
                }
            }
            else
            {
                AlertMessageStatus(ctx, "Alert", retorno);
            }
        }

        public bool IsValueValidToElginPay()
        {
            //Valor do campo formatado par a criação do BigDecimal formatado
            string valueFormatted = editTextValue.Text.Replace(",", ".").Trim();

            //BigDecimal utilizado para comparar com 1.00 real (valor mínimo para transação ElginPay) com maior precisão
            BigDecimal actualValueInBigDecimal = new BigDecimal(valueFormatted);

            //Checa se o valor é menor que 1 real
            if (actualValueInBigDecimal.CompareTo(new BigDecimal("1.00")) == -1)
            {
                AlertMessageStatus(this, "Alerta", "O valor mínimo para a transação é de R$1.00!");
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool IsInstallmentsFieldValid()
        {
            try
            {
                int intNumberOfInstallments = int.Parse(String.ValueOf(editTextNumberOfInstallments.Text));

                //Se o parcelamento não for a vista, o número mínimo de parcelas para se iniciar uma transação é 2
                if ((selectedInstallmentType == FINANCIAMENTO_PARCELADO_EMISSOR || selectedInstallmentType == FINANCIAMENTO_PARCELADO_ESTABELECIMENTO) && intNumberOfInstallments < 2)
                {
                    AlertMessageStatus(this, "Alerta", "O número mínimo de parcelas para esse tipo de parcelamento é 2!");
                    return false;
                }

                //Como não há nenhum problema com o valor do campo de parcelas, atualizamos a váriavel:
                numberOfInstallments = intNumberOfInstallments;

                return true;
            }
            catch (Exception)
            {
                //Como o inputType do campo está setado como "number" a única exception possível para este catch é de o campo estar vazio, uma vez que não é possível inserir quaisquer cacteres alem dos digitos [0-9].
                AlertMessageStatus(this, "Alert", "O campo número de parcelas não pode ser vazio! Digite algum valor.");

                return false;
            }
        }

        public static void AlertMessageStatus(Context ctx, string titleAlert, string messageAlert)
        {
            AlertDialog alertDialog = new AlertDialog.Builder(ctx).Create();
            alertDialog.SetTitle(titleAlert);
            alertDialog.SetMessage(messageAlert);
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }

        public static void AlertImage(Context ctx, string titleAlert, Bitmap bitmap)
        {
            ImageView image = new ImageView(ctx);
            image.SetImageBitmap(bitmap);
            image.SetMinimumHeight(100);

            AlertDialog.Builder builder =
                    new AlertDialog.Builder(ctx).
                            SetMessage(titleAlert).
                            SetPositiveButton("OK", (c, ev) =>
                            {
                                ((IDialogInterface)c).Dispose();
                            }
            ).
                        SetView(image);
            builder.Create().Show();
        }
    }
}