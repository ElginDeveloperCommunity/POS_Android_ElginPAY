﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Util;
using Android.Views;
using Android.Widget;
using AndroidX.AppCompat.Content.Res;
using BR.Com.Setis.Interfaceautomacao;
using Java.Lang;
using System.Collections.Generic;
using Double = Java.Lang.Double;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "ElginPay")]
    public class ElginPay : Activity
    {
        ElginPayService elginPayService;

        // RETORNO ELGIN PAY
        public static string saidaUltimaTransacao = "";

        //EDIT TEXTs
        EditText editTextValueTEF;

        //BUTTONS TYPE OF PAYMENTS
        Button buttonCreditOption;
        Button buttonDebitOption;

        //BUTTONS TYPE OF INSTALLMENTS
        Button buttonStoreOption;
        Button buttonAdmOption;
        Button buttonAvistaOption;
        LinearLayout containerTypeInsatllments;

        //BUTTONS ACTIONS TEF
        Button buttonSendTransaction;
        Button buttonCancelTransaction;
        Button buttonConfigsTransaction;

        //INIT DEFAULT OPTIONS
        string selectedPaymentMethod = "Crédito";
        int selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;
        string selectedTefType = "PayGo";
        string selectedAction = "SALE";

        // TYPE OF INSTALLMENTS
        private const int FINANCIAMENTO_A_VISTA = 0;
        private const int FINANCIAMENTO_PARCELADO_EMISSOR = 1;
        private const int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 2;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.elgin_pay);

            elginPayService = new ElginPayService(this);

            //INIT EDIT TEXTs
            editTextValueTEF = FindViewById<EditText>(Resource.Id.editTextInputValueTEF);

            //INIT BUTTONS TYPES PAYMENTS
            buttonCreditOption = FindViewById<Button>(Resource.Id.buttonCreditOption);
            buttonDebitOption = FindViewById<Button>(Resource.Id.buttonDebitOption);

            //INIT BUTTONS TYPE INSTALLMENTS
            buttonStoreOption = FindViewById<Button>(Resource.Id.buttonStoreOption);
            buttonAdmOption = FindViewById<Button>(Resource.Id.buttonAdmOption);
            buttonAvistaOption = FindViewById<Button>(Resource.Id.buttonAvistaOption);
            containerTypeInsatllments = FindViewById<LinearLayout>(Resource.Id.containerTypeInsatllments);

            //INIT BUTTONS ACTIONS TEF
            buttonSendTransaction = FindViewById<Button>(Resource.Id.buttonSendTransactionTEF);
            buttonCancelTransaction = FindViewById<Button>(Resource.Id.buttonCancelTransactionTEF);
            buttonConfigsTransaction = FindViewById<Button>(Resource.Id.buttonConfigsTEF);

            //SELECT INITIALS OPTIONS
            buttonCreditOption.BackgroundTintList = (AppCompatResources.GetColorStateList(this, Resource.Color.verde));
            buttonAvistaOption.BackgroundTintList = (AppCompatResources.GetColorStateList(this, Resource.Color.verde));

            //INIT DEFAULT INPUTS
            MaskInputValue();
            editTextValueTEF.Text = "2000";

            //SELECT OPTION CREDIT PAYMENT
            buttonCreditOption.Click += delegate
            {
                selectedPaymentMethod = "Crédito";

                buttonCreditOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
                buttonDebitOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);

                containerTypeInsatllments.Visibility = ViewStates.Visible;
            };

            //SELECT OPTION DEBIT PAYMENT
            buttonDebitOption.Click += delegate
            {
                selectedPaymentMethod = "Débito";

                buttonCreditOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonDebitOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);

                containerTypeInsatllments.Visibility = ViewStates.Invisible;
            };

            //SELECT OPTION STORE INSTALLMENT
            buttonStoreOption.Click += delegate
            {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

                buttonStoreOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
                buttonAdmOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAvistaOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
            };

            //SELECT OPTION ADM INSTALLMENT
            buttonAdmOption.Click += delegate
            {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_EMISSOR;

                buttonStoreOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAdmOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
                buttonAvistaOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
            };

            //SELECT OPTION AVISTA INSTALLMENT
            buttonAvistaOption.Click += delegate
            {
                selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;

                buttonStoreOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAdmOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.black);
                buttonAvistaOption.BackgroundTintList = AppCompatResources.GetColorStateList(this, Resource.Color.verde);
            };

            //SELECT BUTTON SEND TRANSACTION
            buttonSendTransaction.Click += delegate
            {
                if (IsEntriesValid())
                {
                    StartActionTEF("SALE");
                }
            };

            //SELECT BUTTON CANCEL TRANSACTION
            buttonCancelTransaction.Click += delegate
            {
                if (IsEntriesValid())
                {
                    StartActionTEF("CANCEL");
                }
            };

            //SELECT BUTTON CONFIGS TRANSACTION
            buttonConfigsTransaction.Click += delegate
            {
                elginPayService.IniciarOperacaoAdministrativa();
            };
        }

        public void SaveElginPayData(string retornoOperacaoElginPay)
        {
            saidaUltimaTransacao = retornoOperacaoElginPay;

            AlertDialog alertDialog = new AlertDialog.Builder(this).Create();
            alertDialog.SetTitle("DADOS ELGIN PAY");
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });

            // Adicionar Scroll para poder ver conteúdo completo
            ScrollView scrollView = new ScrollView(this);

            TextView textView = new TextView(this);
            textView.Text = (retornoOperacaoElginPay);
            textView.SetPadding(30, 5, 30, 0);

            LinearLayout view = new LinearLayout(this);
            view.Orientation = Orientation.Vertical;
            view.AddView(textView);
            scrollView.AddView(view);

            alertDialog.SetView(scrollView);
            alertDialog.Show();
        }

        public void StartActionTEF(string action)
        {
            selectedAction = action;
            SendElginPayParams(action);
        }

        public void SendElginPayParams(string action)
        {
            if (IsValueInvalidToElginPAY(editTextValueTEF.Text.ToString()))
            {
                AlertMessageStatus(this, "Alerta", "O valor para essa transação deve ser maior ou igual a 1.00");
                return;
            }

            if (action.Equals("SALE"))
            {
                if (selectedPaymentMethod == "Crédito")
                {
                    elginPayService.IniciarPagamentoCredito(CleanInputValue(editTextValueTEF.Text.ToString()), selectedInstallmentsMethod);
                }
                else if (selectedPaymentMethod == "Débito")
                {
                    elginPayService.IniciarPagamentoDebito(CleanInputValue(editTextValueTEF.Text.ToString()));
                }
            }
            if (action.Equals("CANCEL"))
            {
                elginPayService.IniciarCancelamentoVenda(CleanInputValue(editTextValueTEF.Text.ToString()));
            }
        }

        public static void OptionReturnElginPay(Context ctx, string retorno, string via_impressao)
        {
            if (retorno != null)
            {
                if (retorno.Equals("Transacao autorizada"))
                {
                    string imageViaBase64 = via_impressao;

                    byte[] decodedString = Base64.Decode(imageViaBase64, Base64Flags.Default);
                    Bitmap decodedByte = BitmapFactory.DecodeByteArray(decodedString, 0, decodedString.Length);

                    AlertImage(ctx, "Comprovante ElginPAY", decodedByte);
                    AlertMessageStatus(ctx, "Alert", retorno);
                }
                else
                {
                    AlertMessageStatus(ctx, "Alert", retorno);
                }
            }
            else
            {
                AlertMessageStatus(ctx, "Alert", retorno);
            }
        }

        public bool IsEntriesValid()
        {
            if (IsValueNotEmpty(editTextValueTEF.Text.ToString()))
            {
                return true;
            }
            else
            {
                AlertMessageStatus(this, "Alerta", "Verifique a entrada de valor de pagamento!");
                return false;
            }
        }

        public static void AlertMessageStatus(Context ctx, string titleAlert, string messageAlert)
        {
            AlertDialog alertDialog = new AlertDialog.Builder(ctx).Create();
            alertDialog.SetTitle(titleAlert);
            alertDialog.SetMessage(messageAlert);
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }

        public static void AlertImage(Context ctx, string titleAlert, Bitmap bitmap)
        {
            ImageView image = new ImageView(ctx);
            image.SetImageBitmap(bitmap);
            image.SetMinimumHeight(100);

            AlertDialog.Builder builder =
                    new AlertDialog.Builder(ctx).
                            SetMessage(titleAlert).
                            SetPositiveButton("OK", (c, ev) =>
                            {
                                ((IDialogInterface)c).Dispose();
                            }
            ).
                        SetView(image);
            builder.Create().Show();
        }

        public bool IsValueNotEmpty(string inputTextValue)
        {
            return !CleanInputValue(inputTextValue).Equals("000");
        }

        public bool IsValueInvalidToElginPAY(string inputTextValue)
        {
            string s = inputTextValue.Replace(",", ".");
            double value = Double.ParseDouble(s);
            return value < 1.00;
        }

        public bool IsInstallmentEmptyOrLessThanZero(string inputTextInstallment)
        {
            if (inputTextInstallment.Equals(""))
            {
                return false;
            }
            else
            {
                return Integer.ParseInt(inputTextInstallment) > 0;
            }
        }

        private void MaskInputValue()
        {
            editTextValueTEF.AddTextChangedListener(new InputMaskMoney(editTextValueTEF));
        }

        public string CleanInputValue(string value)
        {
            return InputMaskMoney.CleanInputMaskMoney(value);
        }
    }
}