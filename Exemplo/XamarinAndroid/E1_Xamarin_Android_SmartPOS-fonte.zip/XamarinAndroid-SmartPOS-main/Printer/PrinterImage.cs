﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.OS;
using Android.Provider;
using Android.Util;
using Android.Widget;
using System.Collections.Generic;
using Java.Lang;
using Android.Views;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "PrinterImage")]
    public class PrinterImage : Activity
    {

        //ImageView
        ImageView imageView;

        //Checkbox
        CheckBox checkBoxIsCutPaper;

        //Buttons
        Button buttonSelectImage, buttonPrintImage;

        //Path of image
        Bitmap bitmap;
        string pathImage = "";

        //Default name of path and file image default
        public static string NAME_IMAGE = "elgin";
        public static string DEF_TYPE = "drawable";

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.printer_image);

            //image view
            imageView = FindViewById<ImageView>(Resource.Id.previewImgDefault);

            //checkbox
            checkBoxIsCutPaper = FindViewById<CheckBox>(Resource.Id.checkBoxCutPaperPrintImage);

            //button
            buttonSelectImage = FindViewById<Button>(Resource.Id.buttonSelectImage);
            buttonPrintImage = FindViewById<Button>(Resource.Id.buttonPrintImage);


            if (PrinterMenu.selectedPrinterType.Equals("Interna")) checkBoxIsCutPaper.Visibility = ViewStates.Invisible;

            buttonSelectImage.Click += delegate
            {
                StartGallery();
            };

            buttonPrintImage.Click += delegate
            {
                SendPrinterImage();
            };
        }

        private void StartGallery()
        {

            AlertDialog.Builder alert = new AlertDialog.Builder(this);
            //define o titulo e mensagem a exibir no dialogo
            alert.SetTitle("AVISO");
            alert.SetMessage("Certifique-se de que a imagem selecionada tenha até 400px de largura ou ela será cortada durante a impressão.");
            //define o botão positivo
            alert.SetPositiveButton("OK", (senderAlert, args) => {
                Intent cameraIntent = new Intent(Intent.ActionPick);

                cameraIntent.SetType("image/*");

                StartActivityForResult(cameraIntent, 1000);
            });
            alert.Show();
        }

        protected override void OnActivityResult(int requestCode, Result resultCode, Intent data)
        {
            base.OnActivityResult(requestCode, resultCode, data);
            if (resultCode == Result.Ok)
            {
                if (requestCode == 1000)
                {
                    Android.Net.Uri returnUri = data.Data;

                    Bitmap bitmapImage = null;
                    try
                    {
                        bitmapImage = MediaStore.Images.Media.GetBitmap(ContentResolver, returnUri);
                        SetBitmap(bitmapImage);
                    }
                    catch (Java.IO.IOException e)
                    {
                        e.PrintStackTrace();
                    }
                    imageView.SetImageBitmap(bitmapImage);
                }
            }
            else
            {
                Toast.MakeText(this, "You haven't picked an Image", ToastLength.Long).Show();
            }
        }

        public void SetBitmap(Bitmap bitmapFileSelected)
        {
            bitmap = bitmapFileSelected;
        }

        public void SendPrinterImage()
        {
            if (bitmap != null)
            {

                //printerInstance.imprimeImagem(bitmap);
                Log.Debug("IMPRIME IMAGEM", PrinterMenu.printerService.ImprimeImagem(bitmap).ToString());
            }
            else
            {
                int id = 0;

                id = ApplicationContext.Resources.GetIdentifier(
                        NAME_IMAGE,
                        DEF_TYPE,
                        ApplicationContext.PackageName
                );
                JavaSystem.Out.Println("id: " + id);

                bitmap = BitmapFactory.DecodeResource(ApplicationContext.Resources, id);

                //printerInstance.imprimeImagem(bitmap);
                Log.Debug("IMPRIME IMAGEM", PrinterMenu.printerService.ImprimeImagem(bitmap).ToString());
            }

            JumpLine();

            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            mapValues["quant"] = 10;
            if (checkBoxIsCutPaper.Checked) PrinterMenu.printerService.CutPaper(mapValues);
        }

        public void JumpLine()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            mapValues["quant"] = 10;
            PrinterMenu.printerService.AvancaLinhas(mapValues);
        }
    }
}