﻿using Android.Content;
using Android.Graphics;
using Com.Elgin.E1.Impressora;
using System;
using System.Collections.Generic;

namespace XamarinAndroid_SmartPOS
{
    public class PrinterService
    {
        private readonly Context mContext;

        public PrinterService(Context context)
        {
            mContext = context;
            Termica.SetContext(context);
        }

        public int PrinterInternalImpStart()
        {
            PrinterStop();
            int result = Termica.AbreConexaoImpressora(5, "SMARTPOS", "", 0);
            return result;
        }

        public int PrinterExternalImpStart(string ip, int port)
        {
            PrinterStop();
            try
            {
                int result = Termica.AbreConexaoImpressora(3, "I9", ip, port);
                return result;
            }
            catch
            {
                return PrinterInternalImpStart();
            }
        }

        public void PrinterStop()
        {
            Termica.FechaConexaoImpressora();
        }

        public int AvancaLinhas(Dictionary<string,object> map)
        {
            int lines = (int)map["quant"];
            return Termica.AvancaPapel(lines);
        }

        public int CutPaper(Dictionary<string, object> map)
        {
            int lines = (int)map["quant"];
            return Termica.Corte(lines);
        }

        public int ImprimeTexto(Dictionary<string, object> map)
        {
            string text = (string)map["text"];
            string align = (string)map["align"];
            string font = (string)map["font"];
            int fontSize = (int)map["fontSize"];
            int styleValue = 0;

            int alignValue;
            // ALINHAMENTO VALUE
            if (align.Equals("Esquerda"))
            {
                alignValue = 0;
            }
            else if (align.Equals("Centralizado"))
            {
                alignValue = 1;
            }
            else
            {
                alignValue = 2;
            }
            //STILO VALUE
            if (font.Equals("FONT B"))
            {
                styleValue += 1;
            }
            if ((bool)map["isUnderline"])
            {
                styleValue += 2;
            }
            if ((bool)map["isBold"])
            {
                styleValue += 8;
            }

            //System.out.println(text + " " + align + " " + font + " " + string.valueOf(fontSize));

            int result = Termica.ImpressaoTexto(text, alignValue, styleValue, fontSize);
            return result;
        }

        private int CodeOfBarCode(string barCodeName)
        {
            if (barCodeName.Equals("UPC-A"))
                return 0;
            else if (barCodeName.Equals("UPC-E"))
                return 1;
            else if (barCodeName.Equals("EAN 13") || barCodeName.Equals("JAN 13"))
                return 2;
            else if (barCodeName.Equals("EAN 8") || barCodeName.Equals("JAN 8"))
                return 3;
            else if (barCodeName.Equals("CODE 39"))
                return 4;
            else if (barCodeName.Equals("ITF"))
                return 5;
            else if (barCodeName.Equals("CODE BAR"))
                return 6;
            else if (barCodeName.Equals("CODE 93"))
                return 7;
            else if (barCodeName.Equals("CODE 128"))
                return 8;
            else return 0;
        }

        public int ImprimeBarCode(Dictionary<string, object> map)
        {
            int barCodeType = CodeOfBarCode((string)map["barCodeType"]);
            string text = (string)map["text"];
            int height = (int)map["height"];
            int width = (int)map["width"];
            string align = (string)map["align"];

            int hri = 4; // NO PRINT
            int result;
            int alignValue;

            // ALINHAMENTO VALUE
            if (align.Equals("Esquerda"))
            {
                alignValue = 0;
            }
            else if (align.Equals("Centralizado"))
            {
                alignValue = 1;
            }
            else
            {
                alignValue = 2;
            }

            Termica.DefinePosicao(alignValue);

            result = Termica.ImpressaoCodigoBarras(barCodeType, text, height, width, hri);

            return result;
        }

        public int ImprimeQR_CODE(Dictionary<string, object> map)
        {
            int size = (int)map["qrSize"];
            string text = (string)map["text"];
            string align = (string)map["align"];
            int nivelCorrecao = 2;
            int result;
            int alignValue;

            // ALINHAMENTO VALUE
            if (align.Equals("Esquerda"))
            {
                alignValue = 0;
            }
            else if (align.Equals("Centralizado"))
            {
                alignValue = 1;
            }
            else
            {
                alignValue = 2;
            }

            Termica.DefinePosicao(alignValue);

            result = Termica.ImpressaoQRCode(text, size, nivelCorrecao);
            return result;
        }

        public int ImprimeImagem(Bitmap bitmap)
        {
            int result;

            result = Termica.ImprimeBitmap(bitmap);
            return result;
        }

        public int ImprimeXMLNFCe(Dictionary<string, object> map)
        {
            string xmlNFCe = (string)map["xmlNFCe"];
            int indexcsc = (int)map["indexcsc"];
            string csc = (string)map["csc"];
            int param = (int)map["param"];
            return Termica.ImprimeXMLNFCe(xmlNFCe, indexcsc, csc, param);
        }

        public int ImprimeXMLSAT(Dictionary<string, object> map)
        {
            string xml = (string)map["xmlSAT"];
            int param = (int)map["param"];
            return Termica.ImprimeXMLSAT(xml, param);
        }

        public int ImprimeCupomTEF(Dictionary<string, object> map)
        {
            string base64 = (string)map["base64"];

            return Termica.ImprimeCupomTEF(base64);
        }

        public int StatusGaveta() { return Termica.StatusImpressora(1); }

        public int AbrirGaveta() { return Termica.AbreGavetaElgin(); }

        public int StatusSensorPapel()
        {
            return Termica.StatusImpressora(3);
        }

        public int StatusSensorPapelSmartPOS() { return Termica.StatusImpressora(0); }
    }
}