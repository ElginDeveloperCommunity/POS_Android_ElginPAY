﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Java.Util.Regex;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pattern = Java.Util.Regex.Pattern;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "PrinterMenu")]
    public class PrinterMenu : Activity
    {
        //Printer Object
        public static PrinterService printerService;

        //EditTexts
        public static EditText editTextInputIP;

        //Radios
        RadioButton radioButtonConnectPrinterIntern;
        RadioGroup radioGroupConnectPrinterIE;

        //Buttons
        Button buttonPrinterText, buttonPrinterBarCode, buttonPrinterImage, buttonStatusPrinter, buttonStatusDrawer, buttonOpenDrawer;

        //Params
        public static string selectedPrinterType = "Interna";
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.printer_menu);

            printerService = new PrinterService(this);
            Log.Debug("INIT PRINTER", printerService.PrinterInternalImpStart().ToString());


            buttonPrinterText = FindViewById<Button>(Resource.Id.buttonPrinterText);
            buttonPrinterBarCode = FindViewById<Button>(Resource.Id.buttonPrinterBarCode);
            buttonPrinterImage = FindViewById<Button>(Resource.Id.buttonPrinterImage);
            buttonStatusPrinter = FindViewById<Button>(Resource.Id.buttonStatusPrinter);
            buttonStatusDrawer = FindViewById<Button>(Resource.Id.buttonStatusDrawer);
            buttonOpenDrawer = FindViewById<Button>(Resource.Id.buttonOpenDrawer);
            radioButtonConnectPrinterIntern = FindViewById<RadioButton>(Resource.Id.radioButtonConnectPrinterIntern);
            radioButtonConnectPrinterIntern.Checked = true;

            editTextInputIP = FindViewById<EditText>(Resource.Id.editTextInputIP);
            editTextInputIP.Text = "192.168.0.34:9100";

            radioGroupConnectPrinterIE = FindViewById<RadioGroup>(Resource.Id.radioGroupConnectPrinterIE);
            radioGroupConnectPrinterIE.CheckedChange += delegate (object sender, RadioGroup.CheckedChangeEventArgs e)
            {
                switch (e.CheckedId)
                {
                    case Resource.Id.radioButtonConnectPrinterIntern:
                        selectedPrinterType = "Interna";
                        break;

                    case Resource.Id.radioButtonConnectPrinterExtern:
                        if (IsIpValid(editTextInputIP.Text.ToString()))
                        {
                            selectedPrinterType = "Externa";
                            string[] ipAndPort = editTextInputIP.Text.Split(":");
                            int result = printerService.PrinterExternalImpStart(ipAndPort[0], int.Parse(ipAndPort[1]));
                            Log.Debug("RESULT EXTERN: ", result.ToString());
                        }
                        else
                        {
                            AlertMessageStatus("Digite um IP válido.");
                            radioButtonConnectPrinterIntern.Checked = true;
                        }
                        break;
                }
            };

            buttonPrinterText.Click += delegate
            {
                StartActivity(typeof(PrinterText));
            };

            buttonPrinterBarCode.Click += delegate
            {
                StartActivity(typeof(PrinterBarCode));
            };

            buttonPrinterImage.Click += delegate
            {
                StartActivity(typeof(PrinterImage));
            };

            buttonStatusPrinter.Click += delegate
            {
                StatusPrinter();
            };
        }

        public void StatusPrinter()
        {
            int resultStatus = printerService.StatusSensorPapel();
            Log.Debug("STATUS GAVETA: ", printerService.StatusGaveta().ToString());

            string statusPrinter;
            if (resultStatus == 5)
            {
                statusPrinter = "Papel está presente e não está próximo do fim!";
            }
            else if (resultStatus == 6)
            {
                statusPrinter = "Papel próximo do fim!";
            }
            else if (resultStatus == 7)
            {
                statusPrinter = "Papel ausente!";
            }
            else
            {
                statusPrinter = "Status Desconhecido!";
            }

            AlertMessageStatus(statusPrinter);
        }

        public void AlertMessageStatus(string messageAlert)
        {
            AlertDialog alertDialog = new AlertDialog.Builder(this).Create();
            alertDialog.SetTitle("Alert");
            alertDialog.SetMessage(messageAlert);
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }

        public static bool IsIpValid(string ip)
        {
            Pattern pattern = Pattern.Compile("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]):[0-9]+$");
            Matcher matcher = pattern.Matcher(ip);
            return matcher.Matches();
        }

        public void StartActivity(Type typeOfClass)
        {
            Intent intent = new Intent(this, typeOfClass);
            StartActivity(intent);
        }
    }
}