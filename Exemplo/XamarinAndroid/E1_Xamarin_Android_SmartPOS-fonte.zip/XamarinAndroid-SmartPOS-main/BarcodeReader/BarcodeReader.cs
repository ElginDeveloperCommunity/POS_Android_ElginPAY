﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Util;
using Android.Widget;
using Com.Elgin.E1.Scanner;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "BarcodeReader")]
    public class BarcodeReader : Activity
    {
        Button buttonInitRead;
        Button buttonCleanField;
        EditText editTextCodeBar1;
        EditText editTextCodeBar2;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.barcode_reader);

            buttonInitRead = FindViewById<Button>(Resource.Id.buttonInitRead);
            buttonCleanField = FindViewById<Button>(Resource.Id.buttonCleanField);
            editTextCodeBar1 = FindViewById<EditText>(Resource.Id.editTextCodeBar1);
            editTextCodeBar2 = FindViewById<EditText>(Resource.Id.editTextCodeBar2);

            buttonCleanField.Click += delegate {
                editTextCodeBar1.Text = "";
                editTextCodeBar2.Text = "";
            };
            buttonInitRead.Click += delegate {
                LerCodigo();
            };
        }

        public void LerCodigo()
        {
            editTextCodeBar1.Text = "";
            editTextCodeBar2.Text = "";
            /*
             * Intent in e' chamada com requestCode #1;
             * se bem-sucedida, a Intent retorna resultCode #2
             */
            Intent intent = Scanner.GetScanner(this);
            StartActivityForResult(intent, 1);
        }

        // Sobrescreve onActivityResult(), para manipulacao dos dados retornados...
        protected override void OnActivityResult(int requestCode, Result resultCode, Intent? data)
        {
            base.OnActivityResult(requestCode, resultCode, data);

            if (requestCode == 1)
            { // Intent Scanner
                if (resultCode.ToString() == "2")
                {
                    string[] result = data.GetStringArrayExtra("result");

                    string cs;
                    if (result[0].Equals("1"))
                    {
                        cs = "Codigo: " + result[1] + "\nTipo: " + result[3];
                        editTextCodeBar1.Text = result[1];
                        editTextCodeBar2.Text = result[3];
                    }
                    else
                    {
                        cs = "Erro # " + result[0] + " na leitura do código.";
                        Toast.MakeText(this, cs, ToastLength.Long).Show();
                    }
                }
            }
        }

    }
}