﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Util;
using Android.Widget;
using System.Collections.Generic;
using Java.Lang;
using Android.Views;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "PrinterBarCode")]
    public class PrinterBarCode : Activity
    {
        //EditText
        EditText editTextInputBarCode;

        //Spinner
        Spinner spinnerBarCodeType;
        Spinner spinnerBarCodeWidth;
        Spinner spinnerBarCodeHeight;

        //Radio Buttons
        RadioGroup radioGroupAlignBarCode;
        RadioButton buttonRadioAlignCenter;

        //Checkbox
        CheckBox checkBoxIsCutPaper;

        //Buttons
        Button buttonPrinterBarCode;

        //Default values
        string typeOfBarCode = "EAN 8";
        string typeAlignOfBarCode = "Centralizado";
        int widthOfBarCode = 1;
        int heightOfBarCode = 20;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.printer_bar_code);

            //editText
            editTextInputBarCode = FindViewById<EditText>(Resource.Id.editTextInputBarCode);
            editTextInputBarCode.Text = "40170725";

            //Radios, Spinners and Buttons
            spinnerBarCodeType = FindViewById<Spinner>(Resource.Id.spinnerBarCodeType);
            buttonRadioAlignCenter = FindViewById<RadioButton>(Resource.Id.radioButtonBarCodeAlignCenter);
            spinnerBarCodeWidth = FindViewById<Spinner>(Resource.Id.spinnerBarCodeWidth);
            spinnerBarCodeHeight = FindViewById<Spinner>(Resource.Id.spinnerBarCodeHeight);
            checkBoxIsCutPaper = FindViewById<CheckBox>(Resource.Id.checkBoxCutPaper);
            buttonPrinterBarCode = FindViewById<Button>(Resource.Id.buttonPrinterBarCode);

            if (PrinterMenu.selectedPrinterType.Equals("Interna")) checkBoxIsCutPaper.Visibility = ViewStates.Invisible;

            //Font Family
            spinnerBarCodeType.ItemSelected += delegate (object sender, AdapterView.ItemSelectedEventArgs e)
            {
                typeOfBarCode = e.Parent.GetItemAtPosition(e.Position).ToString();
                SetTypeCodeMessage(typeOfBarCode);
            };

            //Alignment
            buttonRadioAlignCenter.Checked = true;
            radioGroupAlignBarCode = FindViewById<RadioGroup>(Resource.Id.radioGroupAlignBarCode);
            radioGroupAlignBarCode.CheckedChange += delegate (object sender, RadioGroup.CheckedChangeEventArgs e)
            {
                switch (e.CheckedId)
                {
                    case Resource.Id.radioButtonBarCodeAlignLeft:
                        typeAlignOfBarCode = "Esquerda";
                        JavaSystem.Out.Println(typeAlignOfBarCode);
                        break;
                    case Resource.Id.radioButtonBarCodeAlignCenter:
                        typeAlignOfBarCode = "Centralizado";
                        JavaSystem.Out.Println(typeAlignOfBarCode);
                        break;
                    case Resource.Id.radioButtonBarCodeAlignRight:
                        typeAlignOfBarCode = "Direita";
                        JavaSystem.Out.Println(typeAlignOfBarCode);
                        break;
                }
            };

            //Width
            spinnerBarCodeWidth.ItemSelected += delegate (object sender, AdapterView.ItemSelectedEventArgs e)
            {
                widthOfBarCode = int.Parse(e.Parent.GetItemAtPosition(e.Position).ToString());
            };

            //Height
            spinnerBarCodeHeight.ItemSelected += delegate (object sender, AdapterView.ItemSelectedEventArgs e)
            {
                heightOfBarCode = int.Parse(e.Parent.GetItemAtPosition(e.Position).ToString());
            };

            //buttonPrinterBarCode
            buttonPrinterBarCode = FindViewById<Button>(Resource.Id.buttonPrinterBarCode);

            //button print barcode
            buttonPrinterBarCode.Click += delegate
            {
                if (typeOfBarCode.Equals("QR CODE"))
                {
                    SendPrinterQrCode();
                }
                else
                {
                    SendPrinterBarCode();
                }
            };
        }

        public void SendPrinterBarCode()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            if (editTextInputBarCode.Text.Equals(""))
            {
                AlertMessage();
            }
            else
            {
                mapValues["barCodeType"] = typeOfBarCode;
                mapValues["text"] = editTextInputBarCode.Text;
                mapValues["height"] = heightOfBarCode;
                mapValues["width"] = widthOfBarCode;
                mapValues["align"] = typeAlignOfBarCode;

                int result = PrinterMenu.printerService.ImprimeBarCode(mapValues);
                Log.Debug("RESULT BAR CODE: ", result.ToString());
                JumpLine();

                mapValues["quant"] = 10;
                if (checkBoxIsCutPaper.Checked) PrinterMenu.printerService.CutPaper(mapValues);
            }
        }
        public void SendPrinterQrCode()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            if (editTextInputBarCode.Text.Equals(""))
            {
                AlertMessage();
            }
            else
            {
                mapValues["qrSize"] = widthOfBarCode;
                mapValues["text"] = editTextInputBarCode.Text;
                mapValues["align"] = typeAlignOfBarCode;

                PrinterMenu.printerService.ImprimeQR_CODE(mapValues);
                JumpLine();

                mapValues["quant"] = 10;
                if (checkBoxIsCutPaper.Checked) PrinterMenu.printerService.CutPaper(mapValues);
            }
        }
        public void SetTypeCodeMessage(string typeActual)
        {
            switch (typeActual)
            {
                case "EAN 8":
                    editTextInputBarCode.Text = "40170725";
                    break;
                case "EAN 13":
                    editTextInputBarCode.Text = "0123456789012";
                    break;
                case "QR CODE":
                    editTextInputBarCode.Text = "ELGIN DEVELOPERS COMMUNITY";
                    break;
                case "UPC-A":
                    editTextInputBarCode.Text = "123601057072";
                    break;
                case "CODE 39":
                    editTextInputBarCode.Text = "CODE39";
                    break;
                case "ITF":
                    editTextInputBarCode.Text = "05012345678900";
                    break;
                case "CODE BAR":
                    editTextInputBarCode.Text = "A3419500A";
                    break;
                case "CODE 93":
                    editTextInputBarCode.Text = "CODE93";
                    break;
                case "CODE 128":
                    editTextInputBarCode.Text = "{C1233";
                    break;
            }
        }

        public void JumpLine()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            mapValues["quant"] = 10;
            PrinterMenu.printerService.AvancaLinhas(mapValues);
        }
        
        public void AlertMessage()
        {
            AlertDialog alertDialog = new AlertDialog.Builder(this).Create();
            alertDialog.SetTitle("Alert");
            alertDialog.SetMessage("Campo código vazio.");
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }
    }
}