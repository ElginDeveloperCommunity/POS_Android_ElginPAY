﻿using Android.App;
using Android.Content;
using Android.OS;
using Android.Util;
using Android.Views;
using Android.Widget;
using Java.IO;
using Java.Lang;
using System.Collections.Generic;
using StringBuilder = Java.Lang.StringBuilder;

namespace XamarinAndroid_SmartPOS
{
    [Activity(Label = "PrinterText")]
    public class PrinterText : Activity
    {
        Context mContext;

        //Buttons
        Button buttonPrintText, buttonPrinterNFCe, buttonPrinterSAT;


        //EditText messagem
        EditText editTextInputMessage;

        //Alignment
        RadioGroup radioGroupAlign;
        RadioButton buttonRadioCenter;

        //FontFamily/FontSize
        Spinner spinnerFontFamily;
        Spinner spinnerFontSize;

        //Checkbox
        CheckBox checkBoxIsBold;
        CheckBox checkBoxIsUnderLine;
        CheckBox checkBoxIsCutPaper;

        //Initial values
        string typeOfAlignment = "Centralizado";
        string typeOfFontFamily = "FONT A";
        int typeOfFontSize = 17;
        string xmlNFCe = "xmlnfce";
        string xmlSAT = "xmlsat";

        //PARAMS DEFAULT TO PRINT XML NFCe AND SAT
        public static int INDEXCSC = 1;
        public static string CSC = "CODIGO-CSC-CONTRIBUINTE-36-CARACTERES";

        public static int PARAM = 0;
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here
            SetContentView(Resource.Layout.printer_text);
            mContext = this;

            //INIT EDIT TEXT
            editTextInputMessage = FindViewById<EditText>(Resource.Id.editTextInputMessage);
            editTextInputMessage.Text = "ELGIN DEVELOPERS COMMUNITY";

            //INIT RADIOS, SPINNER AND BUTTONS
            radioGroupAlign = FindViewById<RadioGroup>(Resource.Id.radioGroupAlign);
            buttonRadioCenter = FindViewById<RadioButton>(Resource.Id.radioButtonCenter);
            spinnerFontFamily = FindViewById<Spinner>(Resource.Id.spinnerFontFamily);

            spinnerFontSize = FindViewById<Spinner>(Resource.Id.spinnerFontSize);
            checkBoxIsBold = FindViewById<CheckBox>(Resource.Id.checkBoxBold);
            checkBoxIsUnderLine = FindViewById<CheckBox>(Resource.Id.checkBoxUnderline);
            checkBoxIsCutPaper = FindViewById<CheckBox>(Resource.Id.checkBoxCutPaper);

            buttonPrintText = FindViewById<Button>(Resource.Id.buttonPrintText);
            buttonPrinterNFCe = FindViewById<Button>(Resource.Id.buttonPrinterNFCe);
            buttonPrinterSAT = FindViewById<Button>(Resource.Id.buttonPrinterSAT);

            if (PrinterMenu.selectedPrinterType.Equals("Interna")) checkBoxIsCutPaper.Visibility = ViewStates.Invisible;

            buttonPrintText.Click += delegate
            {
                PrintText();
            };

            buttonPrinterNFCe.Click += delegate
            {
                try
                {
                    PrintXmlNFCe();
                }
                catch (IOException e)
                {
                    e.PrintStackTrace();
                }
            };

            buttonPrinterSAT.Click += delegate
            {
                try
                {
                    PrintXmlSAT();
                }
                catch (IOException e)
                {
                    e.PrintStackTrace();
                }
            };

            //Alignment
            buttonRadioCenter.Checked = true;
            radioGroupAlign = FindViewById<RadioGroup>(Resource.Id.radioGroupAlign);
            radioGroupAlign.CheckedChange += delegate (object sender, RadioGroup.CheckedChangeEventArgs e)
            {
                switch (e.CheckedId)
                {
                    case Resource.Id.radioButtonLeft:
                        typeOfAlignment = "Esquerda";
                        break;
                    case Resource.Id.radioButtonCenter:
                        typeOfAlignment = "Centralizado";
                        break;
                    case Resource.Id.radioButtonRight:
                        typeOfAlignment = "Direita";
                        break;
                }
            };

            //Font Family
            spinnerFontFamily.ItemSelected += delegate (object sender, AdapterView.ItemSelectedEventArgs e)
            {
                Spinner spinner = (Spinner)sender;
                typeOfFontFamily = spinner.GetItemAtPosition(e.Position).ToString();

                if (typeOfFontFamily.Equals("FONT B"))
                {
                    checkBoxIsBold.Checked = false;
                    checkBoxIsBold.Visibility = ViewStates.Invisible;
                }
                else
                {
                    checkBoxIsBold.Visibility = ViewStates.Visible;
                }
                Log.Debug("FONT FAMILY: ", typeOfFontFamily + " " + checkBoxIsUnderLine.Checked.ToString());
            };

            //Font Size
            spinnerFontSize.ItemSelected += delegate (object sender, AdapterView.ItemSelectedEventArgs e)
            {
                Spinner spinner = (Spinner)sender;
                typeOfFontSize = int.Parse(spinner.GetItemAtPosition(e.Position).ToString());
                Log.Debug("FONT SIZE: ", typeOfFontSize + " " + checkBoxIsUnderLine.Checked.ToString());
            };
        }

        public void PrintText()
        {
            if (editTextInputMessage.Text.Equals(""))
            {
                AlertMessage();
            }
            else
            {
                Dictionary<string, object> mapValues = new Dictionary<string, object>() {
                    { "text", editTextInputMessage.Text },
                    { "align", typeOfAlignment },
                    { "font", typeOfFontFamily },
                    { "fontSize", typeOfFontSize },
                    { "isBold", checkBoxIsBold.Checked },
                    { "isUnderline", checkBoxIsUnderLine.Checked },
                    { "quant", 10 }
                };

                int Return = PrinterMenu.printerService.ImprimeTexto(mapValues);
                JumpLine();
                Log.Debug("ImprimeTexto", Return.ToString());

                mapValues["quant"] = 10;
                if (checkBoxIsCutPaper.Checked) PrinterMenu.printerService.CutPaper(mapValues);
            }
        }
        public void PrintXmlNFCe()
        {
            string stringXMLNFCe;

            System.IO.Stream ins = mContext.Resources.OpenRawResource(
                    mContext.Resources.GetIdentifier(
                            xmlNFCe,
                            "raw",
                            mContext.PackageName
                    )
            );

            BufferedReader br = new BufferedReader(new InputStreamReader(ins));
            StringBuilder sb = new StringBuilder();
            string line = null;

            try
            {
                line = br.ReadLine();
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }

            while (line != null)
            {
                sb.Append(line);
                sb.Append(JavaSystem.LineSeparator());
                line = br.ReadLine();
            }
            stringXMLNFCe = sb.ToString();

            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            mapValues["xmlNFCe"] = stringXMLNFCe;
            mapValues["indexcsc"] = INDEXCSC;
            mapValues["csc"] = CSC;
            mapValues["param"] = PARAM;

            PrinterMenu.printerService.ImprimeXMLNFCe(mapValues);

            Log.Debug("XML NFCE: ", stringXMLNFCe);
            JumpLine();
        }

        public void PrintXmlSAT()
        {
            string stringXMLSat;

            System.IO.Stream ins = mContext.Resources.OpenRawResource(
                    mContext.Resources.GetIdentifier(
                            xmlSAT,
                            "raw",
                            mContext.PackageName
                    )
        );

            BufferedReader br = new BufferedReader(new InputStreamReader(ins));
            StringBuilder sb = new StringBuilder();
            string line = null;

            try
            {
                line = br.ReadLine();
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }

            while (line != null)
            {
                sb.Append(line);
                sb.Append(JavaSystem.LineSeparator());
                line = br.ReadLine();
            }
            stringXMLSat = sb.ToString();

            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            mapValues["xmlSAT"] = stringXMLSat;
            mapValues["param"] = PARAM;

            PrinterMenu.printerService.ImprimeXMLSAT(mapValues);

            JumpLine();

        }

        public void JumpLine()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            mapValues["quant"] = 10;
            PrinterMenu.printerService.AvancaLinhas(mapValues);
        }

        public void AlertMessage()
        {
            AlertDialog alertDialog = new AlertDialog.Builder(this).Create();
            alertDialog.SetTitle("Alert");
            alertDialog.SetMessage("Campo Mensagem vazio.");
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }
    }
}