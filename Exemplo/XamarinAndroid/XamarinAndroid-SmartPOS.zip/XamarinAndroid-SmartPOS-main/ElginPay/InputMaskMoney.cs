﻿using Android.Widget;
using Android.Text;
using Java.Lang;
using Java.Lang.Ref;
using Java.Math;
using Java.Text;
using Android.Util;
using System.Text.RegularExpressions;

namespace XamarinAndroid_SmartPOS
{
    class InputMaskMoney : Object, ITextWatcher
    {
        private WeakReference editTextWeakReference;

        public InputMaskMoney(EditText editText)
        {
            editTextWeakReference = new WeakReference(editText);
        }

        public void AfterTextChanged(IEditable editable)
        {
            EditText editText = (EditText) editTextWeakReference.Get();
            if (editText == null) return;
            editText.RemoveTextChangedListener(this);
            BigDecimal parsed = ParseToBigDecimal(editable.ToString().Replace(NumberFormat.CurrencyInstance.Currency.Symbol, ""));
            string formatted = NumberFormat.CurrencyInstance.Format(parsed);
            Log.Debug("MONEY", formatted);
            Log.Debug("MONEY", NumberFormat.CurrencyInstance.Currency.Symbol);
            // NumberFormat.getNumberInstance(locale).format(parsed); // sem o simbolo de moeda
            editText.Text = (formatted.Replace(NumberFormat.CurrencyInstance.Currency.Symbol, ""));
            editText.SetSelection(formatted.Length - 2);
            editText.AddTextChangedListener(this);
        }

        public void BeforeTextChanged(ICharSequence s, int start, int count, int after) { }

        public void OnTextChanged(ICharSequence s, int start, int before, int count) { }

        private BigDecimal ParseToBigDecimal(string value)
        {
            string replaceable = string.Format("[%s,.\\s]", NumberFormat.CurrencyInstance.Currency.Symbol);
            string cleanString = value.Replace(replaceable, "");
            return new BigDecimal(cleanString).SetScale(
                    2, RoundOptions.Floor).Divide(new BigDecimal(100), RoundOptions.Floor
            );
        }
        public static string cleanInputMaskMoney(string value)
        {
            return value.Replace("[.]", "").Replace("[-]", "").Replace("[:]", "")
                    .Replace("[/]", "").Replace("[(]", "").Replace(",", "")
                    .Replace("[)]", "").Replace("["+Regex.Escape(NumberFormat.CurrencyInstance.Currency.Symbol)+"]", "").Trim();
        }
    }
}