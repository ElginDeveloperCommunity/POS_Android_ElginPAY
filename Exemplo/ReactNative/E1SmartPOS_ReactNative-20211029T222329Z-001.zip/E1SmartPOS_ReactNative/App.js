import React from 'react';
import Routes from './scr/Routes';
const App =()=> {
  return (
    <Routes/>
  );
};



export default App;