package com.example.e1_kotlin_smartpos

import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.*
import android.util.Base64
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.content.res.AppCompatResources
import com.example.e1_kotlin_smartpos.ElginPayController.ElginPayService
import com.example.e1_kotlin_smartpos.ElginPayController.InputMaskMoney
import java.math.BigDecimal


class ElginPayMenu: AppCompatActivity() {
    lateinit var elginPayService: ElginPayService

    //numberOfInstallmentsLayout
    lateinit var numberOfInstallmentsLayout: LinearLayout

    //EDIT TEXTs
    lateinit var editTextValue: EditText
    lateinit var editTextNumberOfInstallments: EditText

    //BUTTONS TYPE OF PAYMENTS
    lateinit var buttonCreditOption: Button
    lateinit var buttonDebitOption: Button

    //BUTTONS TYPE OF INSTALLMENTS
    lateinit var buttonStoreOption: Button
    lateinit var buttonAdmOption: Button
    lateinit var buttonAvistaOption: Button
    lateinit var containerTypeInsatllments: LinearLayout

    //BUTTONS ACTIONS TEF
    lateinit var buttonSendTransaction: Button
    lateinit var buttonCancelTransaction: Button
    lateinit var buttonConfigsTransaction: Button

    //CHECKBOX
    lateinit var checkBoxCustomLayout: CheckBox

    //INIT DEFAULT OPTIONS
    var selectedPaymentMethod = "Crédito"
    var selectedTefType = "PayGo"
    var selectedAction = "SALE"

    ////INIT DEFAULT OPTIONS
    var selectedInstallmentType = FINANCIAMENTO_A_VISTA
    var numberOfInstallments = 1

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_elgin_pay_menu)
        elginPayService = ElginPayService(this)
        ctx = this

        //Finding LinearLayout to remove conditionally
        numberOfInstallmentsLayout = findViewById(R.id.linearLayoutNumberOfInstallments)

        //INIT EDIT TEXTs
        editTextValue = findViewById(R.id.editTextInputValue)
        editTextNumberOfInstallments = findViewById(R.id.editTextInputNumberOfInstallments)


        //INIT BUTTONS TYPES PAYMENTS
        buttonCreditOption = findViewById(R.id.buttonCreditOption)
        buttonDebitOption = findViewById(R.id.buttonDebitOption)
        containerTypeInsatllments = findViewById(R.id.containerTypeInsatllments)

        //INIT BUTTONS TYPE INSTALLMENTS
        buttonStoreOption = findViewById(R.id.buttonStoreOption)
        buttonAdmOption = findViewById(R.id.buttonAdmOption)
        buttonAvistaOption = findViewById(R.id.buttonAvistaOption)

        //INIT BUTTONS ACTIONS TEF
        buttonSendTransaction = findViewById(R.id.buttonSendTransactionTEF)
        buttonCancelTransaction = findViewById(R.id.buttonCancelTransactionTEF)
        buttonConfigsTransaction = findViewById(R.id.buttonConfigsTEF)
        checkBoxCustomLayout = findViewById(R.id.checkBoxCustomLayout)

        //SELECT INITIALS OPTION
        buttonCreditOption.setBackgroundTintList(
            AppCompatResources.getColorStateList(
                ctx as ElginPayMenu,
                R.color.verde
            )
        )
        buttonAvistaOption.setBackgroundTintList(
            AppCompatResources.getColorStateList(
                ctx as ElginPayMenu,
                R.color.verde
            )
        )




        //Set MaskInput on editTextValue
        editTextValue.addTextChangedListener(InputMaskMoney(editTextValue))

        //INIT DEFAULT INPUTS
        editTextValue.setText("2000")

        //O padrão da aplicação é iniciar com a opção de pagamento por crédito com parcelamento a vista, portanto o número de parcelas deve ser obrigatoriamente 1
        editTextNumberOfInstallments.setText("1")
        numberOfInstallments = 1
        editTextNumberOfInstallments.setEnabled(false)


        //SELECT OPTION CREDIT PAYMENT
        buttonCreditOption.setOnClickListener(View.OnClickListener {
            selectedPaymentMethod = "Crédito"
            buttonCreditOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.verde
                )
            )
            buttonDebitOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            containerTypeInsatllments.setVisibility(View.VISIBLE)

            //linearLayout of installmentsNumber should be restored
            numberOfInstallmentsLayout.setVisibility(View.VISIBLE)
            editTextNumberOfInstallments.setText("1")
        })

        //SELECT OPTION DEBIT PAYMENT
        buttonDebitOption.setOnClickListener(View.OnClickListener {
            selectedPaymentMethod = "Débito"
            buttonCreditOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            buttonDebitOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.verde
                )
            )
            containerTypeInsatllments.setVisibility(View.INVISIBLE)

            //linearLayout of installmentsNumber shold be gone:
            numberOfInstallmentsLayout.setVisibility(View.GONE)
        })


        //SELECT OPTION STORE INSTALLMENT
        buttonStoreOption.setOnClickListener(View.OnClickListener {
            selectedInstallmentType = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO
            buttonStoreOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.verde
                )
            )
            buttonAdmOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            buttonAvistaOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            editTextNumberOfInstallments.setText("2")
            numberOfInstallments = 1
            editTextNumberOfInstallments.setEnabled(true)
        })

        //SELECT OPTION ADM INSTALLMENT
        buttonAdmOption.setOnClickListener(View.OnClickListener {
            selectedInstallmentType = FINANCIAMENTO_PARCELADO_EMISSOR
            buttonStoreOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            buttonAdmOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.verde
                )
            )
            buttonAvistaOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            editTextNumberOfInstallments.setText("2")
            numberOfInstallments = 1
            editTextNumberOfInstallments.setEnabled(true)
        })

        //SELECT OPTION AVISTA INSTALLMENT
        buttonAvistaOption.setOnClickListener(View.OnClickListener {
            selectedInstallmentType = FINANCIAMENTO_A_VISTA
            buttonStoreOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            buttonAdmOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.black
                )
            )
            buttonAvistaOption.setBackgroundTintList(
                AppCompatResources.getColorStateList(
                    ctx as ElginPayMenu,
                    R.color.verde
                )
            )
            editTextNumberOfInstallments.setText("1")
            numberOfInstallments = 1
            editTextNumberOfInstallments.setEnabled(false)
        })
        /**
         * @!isValueValidToElginPay() é uma checagem feita antes de qualquer transação para checar se o valor a ser enviado é superior a R$ 1.00 e impedir transação caso seja.
         */
        //SELECT BUTTON SEND TRANSACTION
        buttonSendTransaction.setOnClickListener(View.OnClickListener { //Checa se o número de parcelas é valido
            if (isValueValidToElginPay && isInstallmentsFieldValid) {
                startActionTEF("SALE")
            }
        })

        //SELECT BUTTON CANCEL TRANSACTION
        buttonCancelTransaction.setOnClickListener(View.OnClickListener {
            if (isValueValidToElginPay) {
                startActionTEF("CANCEL")
            }
        })

        //SELECT BUTTON CONFIGS TRANSACTION
        buttonConfigsTransaction.setOnClickListener(View.OnClickListener { elginPayService!!.IniciarOperacaoAdministrativa() })
        checkBoxCustomLayout.setOnClickListener(View.OnClickListener { if (checkBoxCustomLayout.isChecked()) elginPayService!!.setCustomLayoutOn() else elginPayService!!.setCustomLayoutOff() })
    }

    fun startActionTEF(action: String) {
        selectedAction = action
        sendElginPayParams(action)
    }

    //Declaração da Classe Handler para receber a saida da transação.
    private val handler: Handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            val saida = msg.obj as String
            Toast.makeText(applicationContext, saida, Toast.LENGTH_LONG).show()
        }
    }

    fun sendElginPayParams(action: String) {
        //Remove a vírgula do campo referente ao valor, uma vez que o ElginPay espera o valore em centavos (ex: 1850 para R$ 18,50)
        val inputCleanForElginPay =
            editTextValue!!.text.toString().replace(",", "").trim { it <= ' ' }

        if (action == "SALE") {
            //Na opçao de pagamento por credito na lib E1 de versao 1.0.16 ou superior é necessario a data em que a venda foi realizada como parametro para realizar o cancelamento, para fins de simplificaçao e tomando que o app experience da Elgin
            //se trata de um exemplo iremos enviar sempre a data do dia atual.
            if (selectedPaymentMethod === "Crédito") {
                elginPayService!!.IniciarPagamentoCredito(
                    inputCleanForElginPay, selectedInstallmentType,
                    numberOfInstallments
                )
            } else if (selectedPaymentMethod === "Débito") {
                elginPayService!!.IniciarPagamentoDebito(inputCleanForElginPay)
            }
        } else if (action == "CANCEL") {
            elginPayService!!.IniciarCancelamentoVenda(inputCleanForElginPay)
        }
    }

    fun optionReturnElginPay(map: Map<*, *>) {
        val mapValues: MutableMap<String, Any?> = HashMap()
        if (map["retorno"] != null) {
            if (map["retorno"] == "Transacao autorizada") {
                val imageViaBase64 = map["via_impressao"] as String?
                val decodedString = Base64.decode(imageViaBase64, Base64.DEFAULT)
                val decodedByte =
                    BitmapFactory.decodeByteArray(decodedString, 0, decodedString.size)
                mapValues["quant"] = 10
                mapValues["base64"] = imageViaBase64
                alertImage("Comprovante ElginPAY", decodedByte)
                alertMessageStatus("Alert", map["retorno"].toString())
            } else {
                alertMessageStatus("Alert", map["retorno"].toString())
            }
        } else {
            alertMessageStatus("Alert", map["retorno"].toString())
        }
    }//Como o inputType do campo está setado como "number" a única exception possível para este catch é de o campo estar vazio, uma vez que não é possível inserir quaisquer cacteres alem dos digitos [0-9].
    //Se o parcelamento não for a vista, o número mínimo de parcelas para se iniciar uma transação é 2

    //Como não há nenhum problema com o valor do campo de parcelas, atualizamos a váriavel:
    val isInstallmentsFieldValid: Boolean
        get() = try {
            val intNumberOfInstallments = editTextNumberOfInstallments!!.text.toString().toInt()

            //Se o parcelamento não for a vista, o número mínimo de parcelas para se iniciar uma transação é 2
            if ((selectedInstallmentType == FINANCIAMENTO_PARCELADO_EMISSOR || selectedInstallmentType == FINANCIAMENTO_PARCELADO_ESTABELECIMENTO) && intNumberOfInstallments < 2) {
                alertMessageStatus(
                    "Alerta",
                    "O número mínimo de parcelas para esse tipo de parcelamento é 2!"
                )
                false
            }

            //Como não há nenhum problema com o valor do campo de parcelas, atualizamos a váriavel:
            numberOfInstallments = intNumberOfInstallments
            true
        } catch (e: Exception) {
            //Como o inputType do campo está setado como "number" a única exception possível para este catch é de o campo estar vazio, uma vez que não é possível inserir quaisquer cacteres alem dos digitos [0-9].
            alertMessageStatus(
                "Alert",
                "O campo número de parcelas não pode ser vazio! Digite algum valor."
            )
            false
        }

    //Valor do campo formatado par a criação do BigDecimal formatado
    val isValueValidToElginPay: Boolean

    //BigDecimal utilizado para comparar com 1.00 real (valor mínimo para transação ElginPay) com maior precisão

        //Checa se o valor é menor que 1 real
        get() {
            //Valor do campo formatado par a criação do BigDecimal formatado
            val valueFormatted =
                editTextValue!!.text.toString().replace(",".toRegex(), ".").trim { it <= ' ' }

            //BigDecimal utilizado para comparar com 1.00 real (valor mínimo para transação ElginPay) com maior precisão
            val actualValueInBigDecimal = BigDecimal(valueFormatted)

            //Checa se o valor é menor que 1 real
            return if (actualValueInBigDecimal.compareTo(BigDecimal("1.00")) == -1) {
                alertMessageStatus("Alerta", "O valor mínimo para a transação é de R$1.00!")
                false
            } else {
                true
            }
        }

    fun alertImage(titleAlert: String?, bitmap: Bitmap?) {
        val image = ImageView(this)
        image.setImageBitmap(bitmap)
        image.minimumHeight = 100
        val builder = AlertDialog.Builder(this).setMessage(titleAlert).setPositiveButton(
            "OK"
        ) { dialog, which -> dialog.dismiss() }.setView(image)
        builder.create().show()
    }

    companion object {
        var saidaUltimaTransacao = ""
        var ctx: Context? = null

        // TYPE OF INSTALLMENTS
        const val FINANCIAMENTO_A_VISTA = 1
        const val FINANCIAMENTO_PARCELADO_EMISSOR = 2
        const val FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 3

        fun alertMessageStatus(titleAlert: String?, messageAlert: String?) {
            val alertDialog = AlertDialog.Builder(ctx).create()
            alertDialog.setTitle(titleAlert)
            alertDialog.setMessage(messageAlert)
            alertDialog.setButton(
                AlertDialog.BUTTON_NEUTRAL, "OK"
            ) { dialog, which -> dialog.dismiss() }
            alertDialog.show()
        }
    }
}