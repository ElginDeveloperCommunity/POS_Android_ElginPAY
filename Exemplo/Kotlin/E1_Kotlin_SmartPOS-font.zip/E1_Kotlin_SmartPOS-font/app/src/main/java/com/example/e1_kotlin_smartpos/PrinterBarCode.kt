package com.example.e1_kotlin_smartpos

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.util.HashMap


class PrinterBarCode : AppCompatActivity() {
    //EditText
    lateinit var editTextInputBarCode: EditText

    //TextView
    lateinit var textWidth: TextView
    lateinit var textHeight: TextView

    //Spinner
    lateinit var spinnerBarCodeType: Spinner
    lateinit var spinnerBarCodeWidth: Spinner
    lateinit var spinnerBarCodeHeight: Spinner

    //Radio Buttons
    lateinit var radioGroupAlignBarCode: RadioGroup
    lateinit var buttonRadioAlignCenter: RadioButton

    //Checkbox
    lateinit var checkBoxIsCutPaper: CheckBox

    //Buttons
    lateinit var buttonPrinterBarCode: Button

    //Default values
    var typeOfBarCode = "EAN 8"
    var typeAlignOfBarCode = "Centralizado"
    var widthOfBarCode = 1
    var heightOfBarCode = 20

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_printer_bar_code)

        //editText
        editTextInputBarCode = findViewById(R.id.editTextInputBarCode)
        editTextInputBarCode.setText("40170725")

        //Radios, Spinners and Buttons
        spinnerBarCodeType = findViewById(R.id.spinnerBarCodeType)
        buttonRadioAlignCenter = findViewById(R.id.radioButtonBarCodeAlignCenter)
        spinnerBarCodeWidth = findViewById(R.id.spinnerBarCodeWidth)
        spinnerBarCodeHeight = findViewById(R.id.spinnerBarCodeHeight)
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode)

        //textView
        textWidth = findViewById(R.id.TextWidth)
        textHeight = findViewById(R.id.TextHeight)

        //Checkboxs

        //Checkboxs
        checkBoxIsCutPaper = findViewById(R.id.checkBoxCutPaperBarCode)

        if (PrinterMenu.selectedPrinterType.equals("Interna")) checkBoxIsCutPaper.setVisibility(View.INVISIBLE)

        //Font Family
        spinnerBarCodeType.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                typeOfBarCode = parent.getItemAtPosition(position).toString()
                setTypeCodeMessage(typeOfBarCode)

                //Mudança de label
                if( typeOfBarCode == "QR CODE"){
                    spinnerBarCodeWidth.visibility = View.VISIBLE
                    spinnerBarCodeHeight.visibility = View.INVISIBLE
                    textWidth.visibility = View.VISIBLE
                    textHeight.visibility = View.INVISIBLE
                    textWidth.setText("SQUARE")
                }
                else if(typeOfBarCode == "CODE 128") {
                    textWidth.visibility = View.VISIBLE
                    textHeight.visibility = View.VISIBLE
                    spinnerBarCodeWidth.visibility = View.VISIBLE
                    spinnerBarCodeHeight.visibility = View.VISIBLE
                    textWidth.setText("WIDTH")
                }
                else
                {
                    textHeight.visibility = View.INVISIBLE
                    textWidth.visibility = View.INVISIBLE
                    spinnerBarCodeHeight.visibility = View.INVISIBLE
                    spinnerBarCodeWidth.visibility = View.INVISIBLE

                }
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        //Alignment
        buttonRadioAlignCenter.setChecked(true)
        radioGroupAlignBarCode = findViewById(R.id.radioGroupAlignBarCode)
        radioGroupAlignBarCode.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.radioButtonBarCodeAlignLeft -> {
                    typeAlignOfBarCode = "Esquerda"
                    println(typeAlignOfBarCode)
                }
                R.id.radioButtonBarCodeAlignCenter -> {
                    typeAlignOfBarCode = "Centralizado"
                    println(typeAlignOfBarCode)
                }
                R.id.radioButtonBarCodeAlignRight -> {
                    typeAlignOfBarCode = "Direita"
                    println(typeAlignOfBarCode)
                }
            }
        })

        //Width
        spinnerBarCodeWidth.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                widthOfBarCode = parent.getItemAtPosition(position).toString().toInt()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        //Height
        spinnerBarCodeHeight.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>,
                view: View,
                position: Int,
                id: Long
            ) {
                heightOfBarCode = parent.getItemAtPosition(position).toString().toInt()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        })

        //buttonPrinterBarCode
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode)

        //button print barcode
        buttonPrinterBarCode.setOnClickListener(View.OnClickListener {
            if (typeOfBarCode == "QR CODE") {
                sendPrinterQrCode()
            } else {
                sendPrinterBarCode()
            }
        })
    }

    fun sendPrinterBarCode() {
        val mapValues: MutableMap<String, Any> = HashMap()
        if (editTextInputBarCode!!.text.toString() == "") {
            alertMessage()
        } else {
            mapValues["barCodeType"] = typeOfBarCode
            mapValues["text"] = editTextInputBarCode!!.text.toString()
            mapValues["height"] = heightOfBarCode
            mapValues["width"] = widthOfBarCode
            mapValues["align"] = typeAlignOfBarCode
            mapValues["quant"] = 10

            val result: Int = PrinterMenu.printerInstance!!.imprimeBarCode(mapValues)
            println("RESULT BAR CODE: $result")
            jumpLine()

            if(checkBoxIsCutPaper.isChecked()) PrinterMenu.printerInstance!!.cutPaper(mapValues);
        }
    }

    fun sendPrinterQrCode() {
        val mapValues: MutableMap<String, Any> = HashMap()
        if (editTextInputBarCode!!.text.toString() == "") {
            alertMessage()
        } else {
            mapValues["qrSize"] = widthOfBarCode
            mapValues["text"] = editTextInputBarCode!!.text.toString()
            mapValues["align"] = typeAlignOfBarCode
            mapValues["quant"] = 10
            PrinterMenu.printerInstance!!.imprimeQR_CODE(mapValues)
            jumpLine()
            if(checkBoxIsCutPaper.isChecked()) PrinterMenu.printerInstance!!.cutPaper(mapValues);
        }
    }

    fun setTypeCodeMessage(typeActual: String?) {
        when (typeActual) {
            "EAN 8" -> editTextInputBarCode!!.setText("40170725")
            "EAN 13" -> editTextInputBarCode!!.setText("0123456789012")
            "QR CODE" -> editTextInputBarCode!!.setText("ELGIN DEVELOPERS COMMUNITY")
            "UPC-A" -> editTextInputBarCode!!.setText("123601057072")
            "CODE 39" -> editTextInputBarCode!!.setText("CODE39")
            "ITF" -> editTextInputBarCode!!.setText("05012345678900")
            "CODE BAR" -> editTextInputBarCode!!.setText("A3419500A")
            "CODE 93" -> editTextInputBarCode!!.setText("CODE93")
            "CODE 128" -> editTextInputBarCode!!.setText("{C1233")
        }
    }

    fun jumpLine() {
        val mapValues: MutableMap<String, Any> = HashMap()
        mapValues["quant"] = 10
        PrinterMenu.printerInstance!!.AvancaLinhas(mapValues)
    }

    fun alertMessage() {
        val alertDialog = AlertDialog.Builder(this).create()
        alertDialog.setTitle("Alert")
        alertDialog.setMessage("Campo código vazio.")
        alertDialog.setButton(
            AlertDialog.BUTTON_NEUTRAL, "OK"
        ) { dialog, which -> dialog.dismiss() }
        alertDialog.show()
    }
}