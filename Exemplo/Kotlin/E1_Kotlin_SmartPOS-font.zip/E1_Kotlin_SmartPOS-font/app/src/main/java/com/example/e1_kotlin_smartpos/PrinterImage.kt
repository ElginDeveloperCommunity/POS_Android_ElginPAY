package com.example.e1_kotlin_smartpos

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.e1_kotlin_smartpos.PrinterMenu.Companion.printerInstance
import java.io.IOException


class PrinterImage : AppCompatActivity() {

    //ImageView
    lateinit var imageView: ImageView

    //Buttons
    lateinit var buttonSelectImage: Button
    lateinit var buttonPrintImage: Button


    //Path of image
     var bitmap1: Bitmap? = null
     var pathImage = ""

    //CheckBox
    lateinit var checkBoxIsCutPaper: CheckBox

    //Default name of path and file image default
    var NAME_IMAGE = "elgin"
    var DEF_TYPE = "drawable"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_printer_image)

        //image view
        imageView = findViewById(R.id.previewImgDefault)

        //button
        buttonSelectImage = findViewById(R.id.buttonSelectImage)
        buttonPrintImage = findViewById(R.id.buttonPrintImage)


        //Checkbox
        checkBoxIsCutPaper = findViewById(R.id.checkBoxCutPaperImage)
        if (PrinterMenu.selectedPrinterType.equals("Interna")) checkBoxIsCutPaper.setVisibility(View.INVISIBLE)
        buttonSelectImage.setOnClickListener( { startGallery() })
        buttonPrintImage.setOnClickListener({ sendPrinterImage() })

    }

    private fun startGallery() {

        val cameraIntent = Intent(Intent.ACTION_PICK)
        cameraIntent.type = "image/*"
        startActivityForResult(cameraIntent, 1000)

    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == RESULT_OK) {
            if (requestCode == 1000) {

                val returnUri = data?.data
                var bitmapImage: Bitmap? = null
                try {
                    bitmapImage = MediaStore.Images.Media.getBitmap(this.contentResolver, returnUri)
                    setBitmap(bitmapImage)
                } catch (e: IOException) {
                    e.printStackTrace()
                }
                imageView!!.setImageBitmap(bitmapImage)
            }
        } else {
            Toast.makeText(this, "You haven't picked an Image", Toast.LENGTH_LONG).show()
        }
    }

    fun setBitmap(bitmapFileSelected: Bitmap?) {
        if (bitmapFileSelected != null) {
            bitmap1 = bitmapFileSelected
        }
    }


    fun sendPrinterImage() {
        if (bitmap1 != null) {

            printerInstance.imprimeImagem(bitmap1);

        } else {
            var id = 0
            id = this.applicationContext.resources.getIdentifier(
                NAME_IMAGE,
                DEF_TYPE,
                this.applicationContext.packageName
            )
            println("id: $id")
            bitmap1 = BitmapFactory.decodeResource(this.applicationContext.resources, id)
            printerInstance.imprimeImagem(bitmap1)
        }
        jumpLine()

    }

    fun jumpLine() {
        val mapValues: MutableMap<String?, Any?> = HashMap()
        mapValues["quant"] = 10
        printerInstance.AvancaLinhas(mapValues)
    }

}