package com.example.e1_kotlin_smartpos

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.elgin.e1.Scanner.Scanner


class BarcodeReader : AppCompatActivity() {
    lateinit var buttonInitRead: Button
    lateinit var buttonCleanField: Button
    lateinit var editTextCodeBar1: EditText
    lateinit var editTextCodeBar2: EditText
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_barcode_reader)
        buttonInitRead = findViewById(R.id.buttonInitRead)
        buttonCleanField = findViewById(R.id.buttonCleanField)
        editTextCodeBar1 = findViewById(R.id.editTextCodeBar1)
        editTextCodeBar2 = findViewById(R.id.editTextCodeBar2)
        buttonCleanField.setOnClickListener(View.OnClickListener {
            editTextCodeBar1.setText("")
            editTextCodeBar2.setText("")
        })
        buttonInitRead.setOnClickListener(View.OnClickListener { view -> lerCodigo(view) })
    }

    // Essa funcao pode ser chamada em onCreate() ou atraves de um botao, por exemplo

    fun lerCodigo(view: View?) {
        editTextCodeBar1!!.setText("")
        editTextCodeBar2!!.setText("")
        /*
         * Intent in e' chamada com requestCode #1;
         * se bem-sucedida, a Intent retorna resultCode #2
         */
        val `in` = Scanner.getScanner(this)
        startActivityForResult(`in`, 1)
    }

    // Sobrescreve onActivityResult(), para manipulacao dos dados retornados...
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1) { // Intent Scanner
            if (resultCode == 2) {
                val result = data!!.getStringArrayExtra("result")
                val cs: CharSequence
                if (result!![0] == "1") {
                    cs = """
                        Codigo: ${result[1]}
                        Tipo: ${result[3]}
                        """.trimIndent()
                    editTextCodeBar1!!.setText(result[1])
                    editTextCodeBar2!!.setText(result[3])
                } else {
                    cs = "Erro # " + result[0] + " na leitura do código."
                    Toast.makeText(this, cs, Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    companion object {
        var context: Context? = null
    }
}