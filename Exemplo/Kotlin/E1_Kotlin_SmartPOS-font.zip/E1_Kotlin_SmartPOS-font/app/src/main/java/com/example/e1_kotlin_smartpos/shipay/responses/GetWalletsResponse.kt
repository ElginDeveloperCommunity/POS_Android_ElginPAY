package com.example.e1_kotlin_smartpos.shipay.responses

import com.example.e1_kotlin_smartpos.shipay.models.wallet.Wallet
import com.google.gson.annotations.SerializedName

data class GetWalletsResponse (
    @SerializedName("wallets")
    var wallets: List<Wallet>
)
