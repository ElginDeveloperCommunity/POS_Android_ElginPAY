package com.example.e1_kotlin_smartpos

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.e1_kotlin_smartpos.NFCE.NfcePage

class MainActivity : AppCompatActivity() {
    lateinit var buttonPrinterMenu: LinearLayout
    lateinit var buttonElginPay: LinearLayout
    lateinit var buttonDigitalWallet: LinearLayout
    lateinit var buttonBarcodeReader: LinearLayout
    lateinit var buttonNfce: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        buttonPrinterMenu = findViewById(R.id.buttonPrinterMenu)
        buttonElginPay = findViewById(R.id.buttonElginPay)
        buttonDigitalWallet = findViewById(R.id.buttonDigitalWallet)
        buttonBarcodeReader = findViewById(R.id.buttonBarcodeReader)
        buttonNfce = findViewById(R.id.buttonNFCE)
        buttonNfce.setOnClickListener {startActivity(NfcePage::class.java)}
        buttonPrinterMenu.setOnClickListener { startActivity(PrinterMenu::class.java) }
        buttonElginPay.setOnClickListener { startActivity(ElginPayMenu::class.java) }
        buttonDigitalWallet.setOnClickListener { startActivity(ShipayMenu::class.java) }
        buttonBarcodeReader.setOnClickListener { startActivity(BarcodeReader::class.java) }
    }

    fun startActivity(typeOfClass: Class<*>?) {
        val intent = Intent(this, typeOfClass)
        startActivity(intent)
    }
}