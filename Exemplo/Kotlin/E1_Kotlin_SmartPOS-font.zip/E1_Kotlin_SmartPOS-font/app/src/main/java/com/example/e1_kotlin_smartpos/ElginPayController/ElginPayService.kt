package com.example.e1_kotlin_smartpos.ElginPayController

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.text.InputType
import android.util.Log
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.Toast
import br.com.setis.interfaceautomacao.Personalizacao
import com.elgin.e1.Pagamento.ElginPay
import com.example.e1_kotlin_smartpos.ElginPayMenu
import com.example.e1_kotlin_smartpos.ElginPayMenu.Companion.alertMessageStatus
import java.io.*
import java.text.SimpleDateFormat
import java.util.*


class ElginPayService(  //Objeto utilizado para receber o contexto da classe ElginPayMenu para facilitar o uso de operações que necessitem de contexto.
    private val context: Context
) {
    var pagamento = ElginPay()

    //USADO PARA ENVIAR E PROCESSAR MENSAGENS
    private val handler: Handler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            super.handleMessage(msg)
            val saida = msg.obj as String

            //Guarda o ultimo retorno do Elgin Pay em uma váriavel reservada dentro da atividade que lida com o mesmo.
            ElginPayMenu.saidaUltimaTransacao = saida
            Log.d("DEBUG", saida)
            alertMessageStatus("Retorno ElginPay", ElginPayMenu.saidaUltimaTransacao)
        }
    }

    fun IniciarPagamentoDebito(valor: String?) {
        Toast.makeText(context, "Débito", Toast.LENGTH_LONG).show()
        pagamento.iniciaVendaDebito(valor, context, handler)
    }

    fun IniciarPagamentoCredito(valor: String?, tipoFinanciamento: Int, numeroParcelas: Int) {
        Toast.makeText(context, "Crédito", Toast.LENGTH_LONG).show()
        pagamento.iniciaVendaCredito(valor, tipoFinanciamento, numeroParcelas, context, handler)
    }

    fun IniciarCancelamentoVenda(valor: String?) {
        //Data do dia de hoje:
        val date = Date()

        //Objeto capaz de formatar a date para o formato aceito pelo Elgin Pay ("dd/mm/aa")
        val dateFormat = SimpleDateFormat("dd/MM/yy")

        //Aplicando formatação
        val todayDate = dateFormat.format(date)

        // Declare your builder here -
        val builder = AlertDialog.Builder(context)

        //Definindo título do AlertDialog
        builder.setTitle("Código de Referência:")

        // Criando um EditText para pegar o input do usuário na caixa de diálogo
        val input = EditText(context)

        //Configurando o EditText para negrito e configurando o tipo de inserção para apenas número
        input.setTypeface(null, Typeface.BOLD)
        input.inputType = InputType.TYPE_CLASS_NUMBER

        //Tornando o dialógo não-cancelável
        builder.setCancelable(false)
        builder.setView(input)
        builder.setPositiveButton("OK",
            DialogInterface.OnClickListener { dialog, whichButton ->
                val saleRef = input.text.toString()

                //Setando o foco de para o input do dialógo
                input.requestFocus()
                val imm =
                    context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT)
                if (saleRef == "") {
                    alertMessageStatus(
                        "Alert",
                        "O campo código de referência da transação não pode ser vazio! Digite algum valor."
                    )
                    return@OnClickListener
                } else {
                    Toast.makeText(context, "Cancelamento", Toast.LENGTH_LONG).show()
                    pagamento.iniciaCancelamentoVenda(valor, saleRef, todayDate, context, handler)
                }
            })
        builder.show()
    }

    fun IniciarOperacaoAdministrativa() {
        Toast.makeText(context, "Administrativa", Toast.LENGTH_LONG).show()
        pagamento.iniciaOperacaoAdministrativa(context, handler)
    }

    private fun createFileFromInputStream(inputStream: InputStream): File? {
        try {
            val f = File("sdcard/logo2.png")
            val outputStream: OutputStream = FileOutputStream(f)
            val buffer = ByteArray(1024)
            var length = 0
            while (inputStream.read(buffer).also { length = it } > 0) {
                outputStream.write(buffer, 0, length)
            }
            outputStream.close()
            inputStream.close()
            return f
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return null
    }

    private fun obterPersonalizacao(): Personalizacao {
        //Processo de personalização do layout
        val pb = Personalizacao.Builder()
        val corDestaque = "#FED20B" // AMARELO
        val corPrimaria = "#050609" // PRETO
        val corSecundaria = "#808080"
        pb.informaCorFonte(corDestaque)
        pb.informaCorFonteTeclado(corPrimaria)
        pb.informaCorFundoToolbar(corDestaque)
        pb.informaCorFundoTela(corPrimaria)
        pb.informaCorTeclaLiberadaTeclado(corDestaque)
        pb.informaCorTeclaPressionadaTeclado(corSecundaria)
        pb.informaCorFundoTeclado(corPrimaria)
        pb.informaCorTextoCaixaEdicao(corDestaque)
        pb.informaCorSeparadorMenu(corDestaque)
        try {
            val am = context.assets
            val inputStream = am.open("logo.png")
            val file = createFileFromInputStream(inputStream)
            pb.informaIconeToolbar(file!!)
        } catch (e: IOException) {
            e.printStackTrace()
        }
        return pb.build()
    }

    //Métodos de customização
    //Aplica o layout do batpay ao objeto de pagamento
    fun setCustomLayoutOn() {
        pagamento.setPersonalizacao(obterPersonalizacao())
    }

    //Aplica um layout padrão ao objeto de pagamento
    fun setCustomLayoutOff() {
        pagamento.setPersonalizacao(Personalizacao.Builder().build())
    }
}
