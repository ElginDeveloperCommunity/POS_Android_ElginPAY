package com.example.e1_kotlin_smartpos

import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText

import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity


class PrinterMenu : AppCompatActivity() {
    //Radios
    lateinit var radioButtonConnectPrinterIntern: RadioButton
    lateinit var radioGroupConnectPrinterIE: RadioGroup

    //Buttons
    lateinit var buttonPrinterText: Button
    lateinit var buttonPrinterBarCode: Button
    lateinit var buttonPrinterImage: Button
    lateinit var buttonStatusPrinter: Button
    lateinit var buttonStatusDrawer: Button
    lateinit var buttonOpenDrawer: Button


    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_printer_menu)
        printerInstance = Printer(this)
        printerInstance!!.printerInternalImpStart()
        buttonPrinterText = findViewById(R.id.buttonPrinterText)
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode)
        buttonPrinterImage = findViewById(R.id.buttonPrinterImage)
        buttonStatusPrinter = findViewById(R.id.buttonStatusPrinter)
        buttonStatusDrawer = findViewById(R.id.buttonStatusDrawer)
        buttonOpenDrawer = findViewById(R.id.buttonOpenDrawer)
        radioButtonConnectPrinterIntern = findViewById(R.id.radioButtonConnectPrinterIntern)
        radioButtonConnectPrinterIntern.setChecked(true)
        editTextInputIP = findViewById(R.id.editTextInputIP1)
        editTextInputIP.setText("192.168.0.34:9100")
        radioGroupConnectPrinterIE = findViewById(R.id.radioGroupConnectPrinterIE)
        radioGroupConnectPrinterIE.setOnCheckedChangeListener(object :
            RadioGroup.OnCheckedChangeListener {
            override fun onCheckedChanged(group: RadioGroup?, checkedId: Int) {
                when (checkedId) {
                    R.id.radioButtonConnectPrinterIntern -> {
                        selectedPrinterType = "Interna"
                        printerInstance!!.printerInternalImpStart()
                    }
                    R.id.radioButtonConnectPrinterExtern -> if (isIpValid(
                            editTextInputIP.getText().toString()
                        )
                    ) {
                        selectedPrinterType = "Externa"
                        connectExternPrinter(editTextInputIP.getText().toString())
                    } else {
                        alertMessageStatus("Digite um IP válido.")
                        radioButtonConnectPrinterIntern.setChecked(true)
                    }
                }
            }
        })
        buttonPrinterText.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                startActivity(PrinterText::class.java)
            }
        })
        buttonPrinterBarCode.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                startActivity(PrinterBarCode::class.java)
            }
        })
        buttonPrinterImage.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                startActivity(PrinterImage::class.java)
            }
        })
        buttonStatusPrinter.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                statusPrinter()
            }
        })
        buttonStatusDrawer.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                statusGaveta()
            }
        })
        buttonOpenDrawer.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                abrirGaveta()
            }
        })
    }

    protected override fun onDestroy() {
        super.onDestroy()
        printerInstance?.printerStop()
    }

    fun statusPrinter() {
        var statusPrinter = ""
        val resultStatus = printerInstance!!.statusSensorPapel()
        System.out.println("STATUS GAVETA: " + printerInstance!!.statusGaveta())
        statusPrinter = if (resultStatus == 5) {
            "Papel está presente e não está próximo do fim!"
        } else if (resultStatus == 6) {
            "Papel próximo do fim!"
        } else if (resultStatus == 7) {
            "Papel ausente!"
        } else {
            "Status Desconhecido!"
        }
        alertMessageStatus(statusPrinter)
    }

    private fun statusGaveta() {
        var statusGaveta = ""
        val resultStatusGaveta = printerInstance.statusGaveta()
      if (resultStatusGaveta == 1) {
          statusGaveta = "Gaveta aberta!"
        } else if (resultStatusGaveta == 2) {
            statusGaveta = "Gaveta fechada!"
        } else {
            statusGaveta = "Status Desconhecido!"
        }
        alertMessageStatus(statusGaveta)
    }

    private fun abrirGaveta(): Int? {
        return printerInstance.abrirGaveta()
    }

    fun alertMessageStatus(messageAlert: String?) {
        val alertDialog: AlertDialog = AlertDialog.Builder(this).create()
        alertDialog.setTitle("Alert")
        alertDialog.setMessage(messageAlert)
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
            object : DialogInterface.OnClickListener {
                override fun onClick(dialog: DialogInterface, which: Int) {
                    dialog.dismiss()
                }
            })
        alertDialog.show()
    }

    fun startActivity(typeOfClass: java.lang.Class<*>?) {
        val intent = Intent(this, typeOfClass)
        startActivity(intent)
    }

    fun connectExternPrinter(ip: String) {
        val ipAndPort: Array<String> = ip.split(":").toTypedArray()

        val result: Int = printerInstance?.printerExternalImpStart(
            ipAndPort[0], ipAndPort[1].toInt()
        )
    }

    companion object {
        //Printer Object
        lateinit var printerInstance: Printer

        //EditTexts
        lateinit var editTextInputIP: EditText
        //Params
        var selectedPrinterType = "Interna"
        fun isIpValid(ip: String?): Boolean {
            val pattern: java.util.regex.Pattern =
                java.util.regex.Pattern.compile("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]):[0-9]+$")
            val matcher: java.util.regex.Matcher = pattern.matcher(ip)
            return matcher.matches()
        }
    }
}