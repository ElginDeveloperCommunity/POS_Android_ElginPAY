package com.example.e1_kotlin_smartpos

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.lang.StringBuilder
import java.util.HashMap


class PrinterText : AppCompatActivity() {
    lateinit var mContext: Context

    //Buttons
    lateinit var buttonPrintText: Button
    lateinit var buttonPrinterNFCe: Button
    lateinit var buttonPrinterSAT: Button

    //EditText messagem
    lateinit var editTextInputMessage: EditText

    //Alignment
    lateinit var radioGroupAlign: RadioGroup
    lateinit var buttonRadioCenter: RadioButton

    //FontFamily/FontSize
    lateinit var spinnerFontFamily: Spinner
    lateinit var spinnerFontSize: Spinner

    //Checkbox
    lateinit var checkBoxIsBold: CheckBox
    lateinit var checkBoxIsUnderLine: CheckBox
    lateinit var checkBoxIsCutPaper: CheckBox

    //Initial values
    var typeOfAlignment = "Centralizado"
    var typeOfFontFamily = "FONT A"
    var typeOfFontSize = 17
    var xmlNFCe = "xmlnfce"
    var xmlSAT = "xmlsat"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_printer_text)
        mContext = this

        //INIT EDIT TEXT
        editTextInputMessage = findViewById(R.id.editTextInputMessage)
        editTextInputMessage.setText("ELGIN DEVELOPERS COMMUNITY")

        //INIT RADIOS, SPINNER AND BUTTONS

        //INIT RADIOS, SPINNER AND BUTTONS
        radioGroupAlign = findViewById(R.id.radioGroupAlign)
        buttonRadioCenter = findViewById(R.id.radioButtonCenter)
        spinnerFontFamily = findViewById(R.id.spinnerFontFamily)

        spinnerFontSize = findViewById(R.id.spinnerFontSize)

        checkBoxIsBold = findViewById(R.id.checkBoxBold)
        checkBoxIsUnderLine = findViewById(R.id.checkBoxUnderline)
        checkBoxIsCutPaper = findViewById(R.id.checkBoxCutPaper)

        if (PrinterMenu.selectedPrinterType.equals("Interna")) checkBoxIsCutPaper.setVisibility(View.INVISIBLE)


        buttonPrintText = findViewById(R.id.buttonPrintText)
        buttonPrinterNFCe = findViewById(R.id.buttonPrinterNFCe)
        buttonPrinterSAT = findViewById(R.id.buttonPrinterSAT)

        buttonPrintText.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                printText()
            }
        })

        buttonPrinterNFCe.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                try {
                    printXmlNFCe()
                } catch (e: java.io.IOException) {
                    e.printStackTrace()
                }
            }
        })

        buttonPrinterSAT.setOnClickListener(object : View.OnClickListener {
            override fun onClick(v: View?) {
                try {
                    printXmlSAT()
                } catch (e: java.io.IOException) {
                    e.printStackTrace()
                }
            }
        })

        //Alignment
        buttonRadioCenter.setChecked(true)
        radioGroupAlign = findViewById(R.id.radioGroupAlign)
        radioGroupAlign.setOnCheckedChangeListener(RadioGroup.OnCheckedChangeListener { group, checkedId ->
            when (checkedId) {
                R.id.radioButtonLeft -> typeOfAlignment = "Esquerda"
                R.id.radioButtonCenter -> typeOfAlignment = "Centralizado"
                R.id.radioButtonRight -> typeOfAlignment = "Direita"
            }
        })

        //Font Family
        spinnerFontFamily.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}

            override fun onItemSelected(adapter: AdapterView<*>, v: View, i: Int, lng: Long) {

                typeOfFontFamily = adapter.getItemAtPosition(i).toString()
                println(
                    "FONT FAMILY: " + typeOfFontFamily + " " + checkBoxIsUnderLine.isChecked()
                        .toString()
                )
                if ( typeOfFontFamily == "FONT B"){
                    checkBoxIsBold.visibility = View.INVISIBLE
                }
                else
                    checkBoxIsBold.visibility = View.VISIBLE
            }
        })

        //Font Size
        spinnerFontSize.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(adapter: AdapterView<*>, v: View, i: Int, lng: Long) {
                typeOfFontSize = adapter.getItemAtPosition(i).toString().toInt()
            }
        })
    }

    fun printText() {
        if (editTextInputMessage.getText().toString().equals("")) {
            alertMessage()
        } else {
            val mapValues: HashMap<String?, Any?> = object : java.util.HashMap<String?, Any?>() {
                init {
                    put("text", editTextInputMessage.getText().toString())
                    put("align", typeOfAlignment)
                    put("font", typeOfFontFamily)
                    put("fontSize", typeOfFontSize)
                    put("isBold", checkBoxIsBold.isChecked())
                    put("isUnderline", checkBoxIsUnderLine.isChecked())
                    put("quant", 10)
                }
            }
            val Return: Int = (PrinterMenu.printerInstance?.imprimeTexto(mapValues))
            jumpLine()
            if (checkBoxIsCutPaper.isChecked()) PrinterMenu.printerInstance?.cutPaper(mapValues)
            Log.d("Return", Return.toString())
        }
    }

    @Throws(IOException::class)
    fun printXmlNFCe() {
        val stringXMLNFCe: String
        val ins = mContext!!.resources.openRawResource(
            mContext!!.resources.getIdentifier(
                xmlNFCe,
                "raw",
                mContext!!.packageName
            )
        )
        val br = BufferedReader(InputStreamReader(ins))
        val sb = StringBuilder()
        var line: String? = null
        try {
            line = br.readLine()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        while (line != null) {
            sb.append(line)
            sb.append(System.lineSeparator())
            line = br.readLine()
        }
        stringXMLNFCe = sb.toString()
        val mapValues: MutableMap<String?, Any?> = HashMap()
        mapValues["xmlNFCe"] = stringXMLNFCe
        mapValues["indexcsc"] = INDEXCSC
        mapValues["csc"] = CSC
        mapValues["param"] = PARAM
        PrinterMenu.printerInstance!!.imprimeXMLNFCe(mapValues)
        println("XML NFCE: $stringXMLNFCe")
        jumpLine()
    }

    @Throws(IOException::class)
    fun printXmlSAT() {
        val stringXMLSat: String
        val ins = mContext!!.resources.openRawResource(
            mContext!!.resources.getIdentifier(
                xmlSAT,
                "raw",
                mContext!!.packageName
            )
        )
        val br = BufferedReader(InputStreamReader(ins))
        val sb = StringBuilder()
        var line: String? = null
        try {
            line = br.readLine()
        } catch (e: IOException) {
            e.printStackTrace()
        }
        while (line != null) {
            sb.append(line)
            sb.append(System.lineSeparator())
            line = br.readLine()
        }
        stringXMLSat = sb.toString()
        val mapValues: MutableMap<String?, Any?> = HashMap()
        mapValues["xmlSAT"] = stringXMLSat
        mapValues["param"] = PARAM
        mapValues["quant"] = 10
        PrinterMenu.printerInstance!!.imprimeXMLSAT(mapValues)
        jumpLine()
    }

    fun jumpLine() {
        val mapValues: MutableMap<String?, Any?> = HashMap()
        mapValues["quant"] = 10
        PrinterMenu.printerInstance!!.AvancaLinhas(mapValues)
    }

    fun alertMessage() {
        val alertDialog = AlertDialog.Builder(this).create()
        alertDialog.setTitle("Alert")
        alertDialog.setMessage("Campo Mensagem vazio.")
        alertDialog.setButton(
            AlertDialog.BUTTON_NEUTRAL, "OK"
        ) { dialog, which -> dialog.dismiss() }
        alertDialog.show()
    }

    companion object {
        //PARAMS DEFAULT TO PRINT XML NFCe AND SAT
        var INDEXCSC = 1
        var CSC = "CODIGO-CSC-CONTRIBUINTE-36-CARACTERES"
        var PARAM = 0
    }
}