﻿using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Widget;
using Xamarin.Forms;
using Com.Elgin.E1.Scanner;
using Android.OS;
using BR.Com.Setis.Interfaceautomacao;
using System.Collections.Generic;
using System;
using Android.Util;

[assembly: Dependency(typeof(XamarinForms_SmartPOS.Droid.ElginPay))]
namespace XamarinForms_SmartPOS.Droid
{
    class ElginPay : IElginPay
    {
        private Handler handler;
        private Context context;
        readonly Com.Elgin.E1.Pagamento.ElginPay pagamento = new Com.Elgin.E1.Pagamento.ElginPay();

        public ElginPay()
        {
            context = (MainActivity)Forms.Context;

            //USADO PARA ENVIAR E PROCESSAR MENSAGENS
            handler = new CustomHandler(Looper.MainLooper, this);
        }

        public void IniciarPagamentoDebito(string valor)
        {
            Toast.MakeText(context, "Debito", ToastLength.Long).Show();
            pagamento.IniciarPagamentoDebito(valor, context, handler);
        }

        public void IniciarPagamentoCredito(string valor, int tipoFinanciamento)
        {
            Toast.MakeText(context, "Crédito", ToastLength.Long).Show();
            pagamento.InciarPagamentoCredito(valor, tipoFinanciamento, context, handler);
        }

        public void IniciarCancelamentoVenda(string valor)
        {
            Toast.MakeText(context, "Cancelamento", ToastLength.Long).Show();
            pagamento.IniciarCancelamentoVenda(valor, context, handler);
        }

        public void IniciarOperacaoAdministrativa()
        {
            Toast.MakeText(context, "Administrativa", ToastLength.Long).Show();
            pagamento.IniciarOperacaoAdministrativa(context, handler);
        }

        public void AlertMessageStatus(string titleAlert, string messageAlert)
        {
            AlertDialog alertDialog = new AlertDialog.Builder(context).Create();
            alertDialog.SetTitle(titleAlert);
            alertDialog.SetMessage(messageAlert);
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }

        private class CustomHandler : Handler
        {
            ElginPay ctx;
            public CustomHandler(Looper l, ElginPay ctx) : base(l)
            {
                this.ctx = ctx;
            }

            public override void HandleMessage(Message msg)
            {
                base.HandleMessage(msg);
                string saida = (string)msg.Obj;
                Toast.MakeText(ctx.context, saida, ToastLength.Long).Show();
                Log.Debug("Retorno", saida);
            }
        }
    }
}