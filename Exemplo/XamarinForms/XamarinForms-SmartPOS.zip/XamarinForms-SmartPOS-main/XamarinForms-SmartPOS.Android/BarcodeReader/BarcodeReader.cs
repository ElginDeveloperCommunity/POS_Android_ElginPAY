﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.Widget;
using Xamarin.Forms;
using Com.Elgin.E1.Scanner;

[assembly: Dependency(typeof(XamarinForms_SmartPOS.Droid.BarcodeReader))]
namespace XamarinForms_SmartPOS.Droid
{
    class BarcodeReader : IBarcodeReader
    {
        public Task<string[]> ReadBarcode()
        {
            var activity = (MainActivity)Forms.Context;
            ActivityResultListener listener = new ActivityResultListener(activity);

            const int RequestBarCode = 2;
            Intent intent = Scanner.GetScanner(activity);
            activity.StartActivityForResult(intent, RequestBarCode);

            return listener.Task;
        }

        private class ActivityResultListener
        {
            private TaskCompletionSource<string[]> Complete = new TaskCompletionSource<string[]>();
            public Task<string[]> Task { get { return this.Complete.Task; } }

            public ActivityResultListener(MainActivity activity)
            {
                // subscribe to activity results
                activity.ActivityResult += OnActivityResult;
            }

            private void OnActivityResult(int requestCode, Result resultCode, Intent data)
            {
                // unsubscribe from activity results
                var activity = (MainActivity)Forms.Context;
                activity.ActivityResult -= OnActivityResult;

                // process result
                if (requestCode != 2 || resultCode.ToString() != "2")
                    Complete.TrySetResult(null);
                else
                {
                    string[] result = data.GetStringArrayExtra("result");

                    if (result[0].Equals("1"))
                    {
                        Complete.TrySetResult(result);
                    }
                    else
                    {
                        string cs = "Erro # " + result[0] + " na leitura do código.";
                        Toast.MakeText(Android.App.Application.Context, cs, ToastLength.Long).Show();
                        Complete.TrySetResult(null);
                    }
                }
            }
        }
    }
}