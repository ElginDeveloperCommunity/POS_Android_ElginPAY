﻿using BR.Com.Setis.Interfaceautomacao;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ElginPayPage : ContentPage
    {
        IElginPay elginPayService = DependencyService.Get<IElginPay>();

        //INIT DEFAULT OPTIONS
        string selectedPaymentMethod = "Crédito";
        int selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;

        // TYPE OF INSTALLMENTS
        private const int FINANCIAMENTO_A_VISTA = 0;
        private const int FINANCIAMENTO_PARCELADO_EMISSOR = 1;
        private const int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 2;

        public ElginPayPage()
        {
            InitializeComponent();

            //INIT DEFAULT INPUTS
            MaskInputValue();
            valorEntry.Text = "20.00";

            //SELECT OPTION CREDIT PAYMENT
            btnCreditOption.Clicked += delegate {
                selectedPaymentMethod = "Crédito";

                btnCreditOption.BorderColor = Color.FromHex("23F600");
                btnDebitOption.BorderColor = Color.Black;

                containerInstallmentOptions.IsVisible = true;
            };

            //SELECT OPTION DEBIT PAYMENT
            btnDebitOption.Clicked += delegate {
                selectedPaymentMethod = "Débito";

                btnCreditOption.BorderColor = Color.Black;
                btnDebitOption.BorderColor = Color.FromHex("23F600");

                containerInstallmentOptions.IsVisible = false;
            };

            //SELECT OPTION STORE INSTALLMENT
            btnStoreOption.Clicked += delegate {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

                btnStoreOption.BorderColor = Color.FromHex("23F600");
                btnAdmOption.BorderColor = Color.Black;
                btnAvistaOption.BorderColor = Color.Black;
            };

            //SELECT OPTION ADM INSTALLMENT
            btnAdmOption.Clicked += delegate {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_EMISSOR;

                btnStoreOption.BorderColor = Color.Black;
                btnAdmOption.BorderColor = Color.FromHex("23F600");
                btnAvistaOption.BorderColor = Color.Black;
            };

            //SELECT OPTION AVISTA INSTALLMENT
            btnAvistaOption.Clicked += delegate {
                selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;

                btnStoreOption.BorderColor = Color.Black;
                btnAdmOption.BorderColor = Color.Black;
                btnAvistaOption.BorderColor = Color.FromHex("23F600");
            };

            //SELECT BUTTON SEND TRANSACTION
            btnSendTransaction.Clicked += delegate {
                if (IsEntriesValid())
                {
                    StartActionTEF("SALE");
                }
            };

            //SELECT BUTTON CANCEL TRANSACTION
            btnCancelTransaction.Clicked += delegate {
                if (IsEntriesValid())
                {
                    StartActionTEF("CANCEL");
                }
            };

            //SELECT BUTTON CONFIGS TRANSACTION
            btnConfigsTransaction.Clicked += delegate {
                if (IsEntriesValid())
                {
                    StartActionTEF("CONFIGS");
                }
            };
        }

        public void StartActionTEF(string action)
        {
            SendElginPayParams(action);
        }

        public void SendElginPayParams(string action)
        {

            elginPayService = DependencyService.Get<IElginPay>();
            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            if (IsValueInvalidToElginPAY(valorEntry.Text))
            {
                AlertMessageStatus("Alerta", "O valor para essa transação deve ser maior ou igual a 1.00");
                return;
            }

            if (action.Equals("SALE"))
            {
                if (selectedPaymentMethod == "Crédito")
                {
                    elginPayService.IniciarPagamentoCredito(CleanInputValue(valorEntry.Text.ToString()), selectedInstallmentsMethod);
                }
                else if (selectedPaymentMethod == "Débito")
                {
                    elginPayService.IniciarPagamentoDebito(CleanInputValue(valorEntry.Text.ToString()));
                }
            }
            if (action.Equals("CANCEL"))
            {
                elginPayService.IniciarCancelamentoVenda(CleanInputValue(valorEntry.Text.ToString()));
            }
        }

        public bool IsEntriesValid()
        {
            if (IsValueNotEmpty(valorEntry.Text.ToString()))
            {
                return true;
            }
            else
            {
                AlertMessageStatus("Alerta", "Verifique a entrada de valor de pagamento!");
                return false;
            }
        }

        public void AlertMessageStatus(string titleAlert, string messageAlert)
        {
            elginPayService.AlertMessageStatus(titleAlert, messageAlert);
        }

        public bool IsValueNotEmpty(string inputTextValue)
        {
            return !CleanInputValue(inputTextValue).Equals("0.00");
        }

        public bool IsValueInvalidToElginPAY(string inputTextValue)
        {
            string s = inputTextValue.Replace(",", ".");
            double value = double.Parse(s);
            return value < 1.00;
        }

        public bool IsInstallmentEmptyOrLessThanZero(string inputTextInstallment)
        {
            if (inputTextInstallment.Equals(""))
            {
                return false;
            }
            else
            {
                return int.Parse(inputTextInstallment) > 0;
            }
        }

        private void MaskInputValue()
        {
            var mask = new InputMaskMoney();
            valorEntry.Behaviors.Add(mask);
        }

        public string CleanInputValue(string value)
        {
            return InputMaskMoney.CleanInputMaskMoney(value);
        }
    }
}