﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class BarcodeReaderPage : ContentPage
    {
        public BarcodeReaderPage()
        {
            InitializeComponent();
        }
        private async void InitRead(object sender, EventArgs e) {
            entryCodigo.Text = "";
            entryTipo.Text = "";
            var result = await DependencyService.Get<IBarcodeReader>().ReadBarcode();
            if (result.Length > 0)
            {
                entryCodigo.Text = result[1];
                entryTipo.Text = result[3];
            }
        }
        private void ClearFields(object sender, EventArgs e)
        {
            entryCodigo.Text = "";
            entryTipo.Text = "";
        }
    }
}