﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PrinterBarCodePage : ContentPage
    {
        //Default values
        string typeOfBarCode = "EAN 8";
        string typeAlignOfBarCode = "Centralizado";
        int widthOfBarCode = 1;
        int heightOfBarCode = 20;

        public PrinterBarCodePage()
        {
            InitializeComponent();
            entryCodigo.Text = "40170725";

            //Font Family
            pickerTipoCodigo.SelectedIndexChanged += delegate (object sender, EventArgs e)
            {
                var itemSelecionado = pickerTipoCodigo.Items[pickerTipoCodigo.SelectedIndex];
                SetTypeCodeMessage(itemSelecionado);
            };

            radioAlinhaEsquerda.CheckedChanged += OnRadioButtonCheckedChanged;
            radioAlinhaCentralizado.CheckedChanged += OnRadioButtonCheckedChanged;
            radioAlinhaDireita.CheckedChanged += OnRadioButtonCheckedChanged;

            //Width
            pickerWidth.SelectedIndexChanged += delegate (object sender, EventArgs e)
            {
                var itemSelecionado = pickerWidth.Items[pickerWidth.SelectedIndex];
                Console.WriteLine("WIDTH: {0}", "" + itemSelecionado.ToString());
                widthOfBarCode = int.Parse(itemSelecionado.ToString());
            };

            //Height
            pickerHeight.SelectedIndexChanged += delegate (object sender, EventArgs e)
            {
                var itemSelecionado = pickerHeight.Items[pickerHeight.SelectedIndex];
                Console.WriteLine("HEIGHT: {0}", "" + itemSelecionado.ToString());
                heightOfBarCode = int.Parse(itemSelecionado.ToString());
            };

            btnImprimirCodigoDeBarras.Clicked += delegate
            {
                if (typeOfBarCode.Equals("QR CODE"))
                {
                    sendPrinterQrCode();
                }
                else
                {
                    SendPrinterBarCode();
                }
            };

            pickerTipoCodigo.SelectedIndex = 0;
            pickerWidth.SelectedIndex = 0;
            pickerHeight.SelectedIndex = 0;

            if (PrinterMenuPage.selectedPrinterType.Equals("Interna"))
            {
                chkCutPaperContainer.IsVisible = false;
            }
        }

        void OnRadioButtonCheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (radioAlinhaEsquerda.IsChecked)
            {
                typeAlignOfBarCode = "Esquerda";
            }
            if (radioAlinhaCentralizado.IsChecked)
            {
                typeAlignOfBarCode = "Centralizado";
            }
            if (radioAlinhaDireita.IsChecked)
            {
                typeAlignOfBarCode = "Direita";
            }
        }

        public void SendPrinterBarCode()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            if (string.IsNullOrEmpty(entryCodigo.Text))
            {
                AlertMessage();
                Console.WriteLine("RESULT BAR CODE: {0}", "Não Foi");
            }
            else
            {
                Console.WriteLine("RESULT BAR CODE: {0}", "Tá indo");
                mapValues["barCodeType"] = typeOfBarCode;
                mapValues["text"] = entryCodigo.Text;
                mapValues["height"] = heightOfBarCode;
                mapValues["width"] = widthOfBarCode;
                mapValues["align"] = typeAlignOfBarCode;

                int result = PrinterMenuPage.printerService.ImprimeBarCode(mapValues);
                Console.WriteLine("RESULT BAR CODE: {0}", result.ToString());
                JumpLine();

                mapValues["quant"] = 10;
                if (chkCutPaper.IsChecked) PrinterMenuPage.printerService.CutPaper(mapValues);
            }
        }

        public void sendPrinterQrCode()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            if (string.IsNullOrEmpty(entryCodigo.Text))
            {
                AlertMessage();
                Console.WriteLine("RESULT QR CODE: {0}","Não Foi");
            }
            else
            {
                Console.WriteLine("RESULT QR CODE: {0}", "Tá indo");
                mapValues["qrSize"] = widthOfBarCode;
                mapValues["text"] = entryCodigo.Text;
                mapValues["align"] = typeAlignOfBarCode;

                int result = PrinterMenuPage.printerService.ImprimeQR_CODE(mapValues);
                Console.WriteLine("RESULT QR CODE: acabou {0}", result.ToString());
                JumpLine();

                mapValues["quant"] = 10;
                if (chkCutPaper.IsChecked) PrinterMenuPage.printerService.CutPaper(mapValues);
            }
        }

        public void SetTypeCodeMessage(string typeActual)
        {
            switch (typeActual)
            {
                case "EAN 8":
                    entryCodigo.Text = "40170725";
                    break;
                case "EAN 13":
                    entryCodigo.Text = "0123456789012";
                    break;
                case "QR CODE":
                    entryCodigo.Text = "ELGIN DEVELOPERS COMMUNITY";
                    break;
                case "UPC-A":
                    entryCodigo.Text = "123601057072";
                    break;
                case "CODE 39":
                    entryCodigo.Text = "CODE39";
                    break;
                case "ITF":
                    entryCodigo.Text = "05012345678900";
                    break;
                case "CODE BAR":
                    entryCodigo.Text = "A3419500A";
                    break;
                case "CODE 93":
                    entryCodigo.Text = "CODE93";
                    break;
                case "CODE 128":
                    entryCodigo.Text = "{C1233";
                    break;
            }
        }

        public void JumpLine()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            mapValues["quant"] = 10;
            PrinterMenuPage.printerService.AvancaLinhas(mapValues);
        }
        public void AlertMessage()
        {
            PrinterMenuPage.printerService.AlertMessageStatus("Campo código vazio.");
        }
    }
}