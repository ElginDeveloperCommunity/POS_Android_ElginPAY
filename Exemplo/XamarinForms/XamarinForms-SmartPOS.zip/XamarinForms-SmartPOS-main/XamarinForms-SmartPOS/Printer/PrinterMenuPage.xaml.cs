﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PrinterMenuPage : ContentPage
    {
        //Printer Object
        public static IPrinter printerService = DependencyService.Get<IPrinter>();

        //Params
        public static string selectedPrinterType = "Interna";
        public PrinterMenuPage()
        {
            InitializeComponent();

            radioImpInterna.IsChecked = true;
            entryIP.Text = "192.168.0.34:9100";

            radioImpInterna.CheckedChanged += OnRadioButtonCheckedChanged;
            radioImpExterna.CheckedChanged += OnRadioButtonCheckedChanged;

            Console.WriteLine("INIT INTERNA: {0}", printerService.PrinterInternalImpStart().ToString());

            btnImprimirTexto.Clicked += async delegate
            {
                await Navigation.PushAsync(new PrinterTextPage());
            };

            btnImprimirCodigoDeBarras.Clicked += async delegate
            {
                await Navigation.PushAsync(new PrinterBarCodePage());
            };

            btnImprimirImagem.Clicked += async delegate
            {
                await Navigation.PushAsync(new PrinterImagePage());
            };

            btnStatusImpressora.Clicked += delegate
            {
                StatusPrinter();
            };

            btnStatusGaveta.Clicked += delegate
            {
                string statusGaveta = "";

                int resultStatusGaveta = printerService.StatusGaveta();

                statusGaveta = resultStatusGaveta == 1 ? "Gaveta aberta!" : resultStatusGaveta == 2 ? "Gaveta fechada!" : "Status Desconhecido!";

                AlertMessageStatus(statusGaveta);
            };

            btnAbrirGaveta.Clicked += delegate
            {
                AbrirGaveta();
            };
        }

        void OnRadioButtonCheckedChanged(object sender, CheckedChangedEventArgs e) {
            if (radioImpInterna.IsChecked)
            {
                selectedPrinterType = "Interna";
                Console.WriteLine("INIT INTERNA: {0}", printerService.PrinterInternalImpStart().ToString());
            }
            if (radioImpExterna.IsChecked)
            {
                selectedPrinterType = "Interna";
                if (IsIpValid(entryIP.Text))
                {
                    selectedPrinterType = "Externa";

                    int dividerIndex = entryIP.Text.IndexOf(':');
                    
                    string ip = entryIP.Text.Substring(0, dividerIndex);
                    int port = int.Parse(entryIP.Text.Substring(dividerIndex + 1));

                    Console.WriteLine("INIT EXTERNA: {0}", printerService.PrinterExternalImpStart(ip, port).ToString());
                }
                else
                {
                    AlertMessageStatus("Digite um IP válido.");
                    radioImpInterna.IsChecked = true;
                    radioImpExterna.IsChecked = false;
                    Console.WriteLine("INIT INTERNA: {0}", printerService.PrinterInternalImpStart().ToString());
                }
            }
        }

        public void StatusPrinter()
        {
            int resultStatus = printerService.StatusSensorPapel();
            Console.WriteLine("STATUS GAVETA: {0}", printerService.StatusGaveta().ToString());

            string statusPrinter;
            if (resultStatus == 5)
            {
                statusPrinter = "Papel está presente e não está próximo do fim!";
            }
            else if (resultStatus == 6)
            {
                statusPrinter = "Papel próximo do fim!";
            }
            else if (resultStatus == 7)
            {
                statusPrinter = "Papel ausente!";
            }
            else
            {
                statusPrinter = "Status Desconhecido!";
            }

            AlertMessageStatus(statusPrinter);
        }

        public int AbrirGaveta ()
        {
            int resultStatusGaveta = printerService.AbrirGaveta();
            return resultStatusGaveta;
        }

        public void AlertMessageStatus(string messageAlert)
        {
            DependencyService.Get<IPrinter>().AlertMessageStatus(messageAlert);
        }

        public static bool IsIpValid(string ip)
        {
            return DependencyService.Get<IPrinter>().IsIpValid(ip);
        }
    }
}