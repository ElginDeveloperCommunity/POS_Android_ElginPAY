﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PrinterTextPage : ContentPage
    {

        //Initial values
        string typeOfAlignment = "Centralizado";
        string typeOfFontFamily = "FONT A";
        int typeOfFontSize = 17;

        //PARAMS DEFAULT TO PRINT XML NFCe AND SAT
        public static int INDEXCSC = 1;
        public static string CSC = "CODIGO-CSC-CONTRIBUINTE-36-CARACTERES";

        private const string nomeXmlSat = "xmlsat";
        private const string nomeXmlNFCE = "xmlnfce";

        private readonly string xmlSat = PrinterMenuPage.printerService.CarregarArquivo(nomeXmlSat);
        private readonly string xmlNFCE = PrinterMenuPage.printerService.CarregarArquivo(nomeXmlNFCE);

        public static int PARAM = 0;

        public PrinterTextPage()
        {
            InitializeComponent();

            btnImprimirTexto.Clicked += delegate
            {
                PrintText();
            };

            btnNFCE.Clicked += delegate
            {
                PrintXmlNFCe();
            };

            btnSAT.Clicked += delegate
            {
                PrintXmlSAT();
            };

            radioAlinhaEsquerda.CheckedChanged += OnRadioButtonCheckedChanged;
            radioAlinhaCentralizado.CheckedChanged += OnRadioButtonCheckedChanged;
            radioAlinhaDireita.CheckedChanged += OnRadioButtonCheckedChanged;

            //Width
            pickerFontFamily.SelectedIndexChanged += delegate (object sender, EventArgs e)
            {
                string itemSelecionado = pickerFontFamily.Items[pickerFontFamily.SelectedIndex];
                typeOfFontFamily = itemSelecionado.ToString();
                if (typeOfFontFamily.Equals("FONT B"))
                {
                    chkNegrito.IsChecked = false;
                    chkNegrito.IsVisible = false;
                    labelNegrito.IsVisible = false;
                }
                else
                {
                    chkNegrito.IsVisible = true;
                    labelNegrito.IsVisible = true;
                }
            };

            //Height
            pickerFontSize.SelectedIndexChanged += delegate (object sender, EventArgs e)
            {
                string itemSelecionado = pickerFontSize.Items[pickerFontSize.SelectedIndex];
                typeOfFontSize = int.Parse(itemSelecionado.ToString());
            };

            pickerFontFamily.SelectedIndex = 0;
            pickerFontSize.SelectedIndex = 0;

            if (PrinterMenuPage.selectedPrinterType.Equals("Interna"))
            {
                chkCutPaperContainer.IsVisible = false;
            }
        }

        void OnRadioButtonCheckedChanged(object sender, CheckedChangedEventArgs e)
        {
            if (radioAlinhaEsquerda.IsChecked)
            {
                typeOfAlignment = "Esquerda";
            }
            if (radioAlinhaCentralizado.IsChecked)
            {
                typeOfAlignment = "Interna";
            }
            if (radioAlinhaDireita.IsChecked)
            {
                typeOfAlignment = "Direita";
            }
        }

        public void PrintText()
        {
            if (string.IsNullOrEmpty(entryMensagem.Text))
            {
                AlertMessage();
                Console.WriteLine("Não imprimiu", "Não imprimiu");
            }
            else
            {
                Dictionary<string, object> mapValues = new Dictionary<string, object>() {
                    { "text", entryMensagem.Text },
                    { "align", typeOfAlignment },
                    { "font", typeOfFontFamily },
                    { "fontSize", typeOfFontSize },
                    { "isBold", chkNegrito.IsChecked },
                    { "isUnderline", chkSublinhado.IsChecked },
                    { "quant", 10 }
                };
                Console.WriteLine("ImprimeTexto: {0}", "DICT");
                foreach (KeyValuePair<string, object> kvp in mapValues)
                {
                    Console.WriteLine("Key = {0}, Value = {1}", kvp.Key, kvp.Value);
                }

                int Return = PrinterMenuPage.printerService.ImprimeTexto(mapValues);
                JumpLine();
                Console.WriteLine("ImprimeTexto: {0}", "" + Return.ToString());

                if (chkCutPaper.IsChecked) PrinterMenuPage.printerService.CutPaper(mapValues);
            }
        }
        public void PrintXmlNFCe()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            mapValues["xmlNFCe"] = xmlNFCE;
            mapValues["indexcsc"] = INDEXCSC;
            mapValues["csc"] = CSC;
            mapValues["param"] = PARAM;

            int Return = PrinterMenuPage.printerService.ImprimeXMLNFCe(mapValues);
            Console.WriteLine("PrintXmlNFCe: {0}", "" + Return.ToString());
            JumpLine();

            if (chkCutPaper.IsChecked) PrinterMenuPage.printerService.CutPaper(mapValues);
        }

        public void PrintXmlSAT()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();

            mapValues["xmlSAT"] = xmlSat;
            mapValues["param"] = PARAM;

            int Return = PrinterMenuPage.printerService.ImprimeXMLSAT(mapValues);
            Console.WriteLine("ImprimeXMLSAT: {0}", "" + Return.ToString());
            JumpLine();

            if (chkCutPaper.IsChecked) PrinterMenuPage.printerService.CutPaper(mapValues);
        }

        public void JumpLine()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>();
            mapValues["quant"] = 10;
            PrinterMenuPage.printerService.AvancaLinhas(mapValues);
        }
        public void AlertMessage()
        {
            PrinterMenuPage.printerService.AlertMessageStatus("Campo código vazio.");
        }
    }
}