﻿using Android.App;
using Android.Content;
using Android.Graphics;
using Android.Util;
using Com.Elgin.E1.Impressora;
using Java.Util.Regex;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using Xamarin.Forms;
using Pattern = Java.Util.Regex.Pattern;

[assembly: Dependency(typeof(XamarinForms_SmartPOS.Droid.Printer))]
namespace XamarinForms_SmartPOS.Droid
{
    class Printer : IPrinter
    {
        private readonly Context mContext;

        public Printer()
        {
            mContext = (MainActivity)Forms.Context;

            Termica.SetContext(mContext);
        }

        public int PrinterInternalImpStart()
        {
            PrinterStop();
            int result = Termica.AbreConexaoImpressora(5, "SMARTPOS", "", 0);
            return result;
        }

        public int PrinterExternalImpStart(string ip, int port)
        {
            PrinterStop();
            try
            {
                int result = Termica.AbreConexaoImpressora(3, "I9", ip, port);
                return result;
            }
            catch (Exception)
            {
                return PrinterInternalImpStart();
            }
        }

        public void PrinterStop()
        {
            Termica.FechaConexaoImpressora();
        }

        public int AvancaLinhas(Dictionary<string, object> map)
        {
            int lines = (int)map["quant"];
            return Termica.AvancaPapel(lines);
        }

        public int CutPaper(Dictionary<string, object> map)
        {
            int lines = (int)map["quant"];
            return Termica.Corte(lines);
        }

        public int ImprimeTexto(Dictionary<string, object> map)
        {
            string text = (string)map["text"];
            string align = (string)map["align"];
            string font = (string)map["font"];
            int fontSize = (int)map["fontSize"];
            int styleValue = 0;

            int alignValue;
            // ALINHAMENTO VALUE
            if (align.Equals("Esquerda"))
            {
                alignValue = 0;
            }
            else if (align.Equals("Centralizado"))
            {
                alignValue = 1;
            }
            else
            {
                alignValue = 2;
            }
            //STILO VALUE
            if (font.Equals("FONT B"))
            {
                styleValue += 1;
            }
            if ((bool)map["isUnderline"])
            {
                styleValue += 2;
            }
            if ((bool)map["isBold"])
            {
                styleValue += 8;
            }

            //System.out.println(text + " " + align + " " + font + " " + string.valueOf(fontSize));

            int result = Termica.ImpressaoTexto(text, alignValue, styleValue, fontSize);
            return result;
        }

        public int CodeOfBarCode(string barCodeName)
        {
            if (barCodeName.Equals("UPC-A"))
                return 0;
            else if (barCodeName.Equals("UPC-E"))
                return 1;
            else if (barCodeName.Equals("EAN 13") || barCodeName.Equals("JAN 13"))
                return 2;
            else if (barCodeName.Equals("EAN 8") || barCodeName.Equals("JAN 8"))
                return 3;
            else if (barCodeName.Equals("CODE 39"))
                return 4;
            else if (barCodeName.Equals("ITF"))
                return 5;
            else if (barCodeName.Equals("CODE BAR"))
                return 6;
            else if (barCodeName.Equals("CODE 93"))
                return 7;
            else if (barCodeName.Equals("CODE 128"))
                return 8;
            else return 0;
        }

        public int ImprimeBarCode(Dictionary<string, object> map)
        {
            int barCodeType = CodeOfBarCode((string)map["barCodeType"]);
            string text = (string)map["text"];
            int height = (int)map["height"];
            int width = (int)map["width"];
            string align = (string)map["align"];

            int hri = 4; // NO PRINT
            int result;
            int alignValue;

            // ALINHAMENTO VALUE
            if (align.Equals("Esquerda"))
            {
                alignValue = 0;
            }
            else if (align.Equals("Centralizado"))
            {
                alignValue = 1;
            }
            else
            {
                alignValue = 2;
            }

            Termica.DefinePosicao(alignValue);

            result = Termica.ImpressaoCodigoBarras(barCodeType, text, height, width, hri);

            return result;
        }

        public int ImprimeQR_CODE(Dictionary<string, object> map)
        {
            int size = (int)map["qrSize"];
            string text = (string)map["text"];
            string align = (string)map["align"];
            int nivelCorrecao = 2;
            int result;
            int alignValue;

            // ALINHAMENTO VALUE
            if (align.Equals("Esquerda"))
            {
                alignValue = 0;
            }
            else if (align.Equals("Centralizado"))
            {
                alignValue = 1;
            }
            else
            {
                alignValue = 2;
            }

            Termica.DefinePosicao(alignValue);

            result = Termica.ImpressaoQRCode(text, size, nivelCorrecao);
            return result;
        }

        public int ImprimeImagem(Stream stream)
        {
            int result;

            Bitmap bitmap = BitmapFactory.DecodeStream(stream);
            result = Termica.ImprimeBitmap(bitmap);
            return result;
        }

        public int ImprimeImagemPadrao()
        {
            Bitmap bitmap;
            int id = mContext.ApplicationContext.Resources.GetIdentifier("elgin_logo_default_print_image", "drawable", mContext.ApplicationContext.PackageName);
            bitmap = BitmapFactory.DecodeResource(mContext.ApplicationContext.Resources, id);

            return Termica.ImprimeBitmap(bitmap);
        }

        public int ImprimeXMLNFCe(Dictionary<string, object> map)
        {
            string xml = (string)map["xmlNFCe"];
            int indexcsc = (int)map["indexcsc"];
            string csc = (string)map["csc"];
            int param = (int)map["param"];
            return Termica.ImprimeXMLNFCe(xml, indexcsc, csc, param);
        }

        public int ImprimeXMLSAT(Dictionary<string, object> map)
        {
            string xml = (string)map["xmlSAT"];
            int param = (int)map["param"];
            return Termica.ImprimeXMLSAT(xml, param);
        }

        public int ImprimeCupomTEF(Dictionary<string, object> map)
        {
            string base64 = (string)map["base64"];

            return Termica.ImprimeCupomTEF(base64);
        }

        public int StatusGaveta() { return Termica.StatusImpressora(1); }

        public int AbrirGaveta() { return Termica.AbreGavetaElgin(); }

        public int StatusSensorPapel()
        {
            return Termica.StatusImpressora(3);
        }

        public int StatusSensorPapelSmartPOS() { return Termica.StatusImpressora(0); }

        public void AlertMessageStatus(string messageAlert)
        {
            AlertDialog alertDialog = new AlertDialog.Builder(mContext).Create();
            alertDialog.SetTitle("Alert");
            alertDialog.SetMessage(messageAlert);
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }

        public bool IsIpValid(string ip)
        {
            Pattern pattern = Pattern.Compile("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]):[0-9]+$");
            Matcher matcher = pattern.Matcher(ip);
            return matcher.Matches();
        }
        
        public Task<Stream> GetImageStreamAsync()
        {
            var activity = (MainActivity)Forms.Context;
            ActivityResultListener listener = new ActivityResultListener(activity);

            const int RequestBarCode = 1000;
            Intent cameraIntent = new Intent(Intent.ActionPick);

            cameraIntent.SetType("image/*");
            activity.StartActivityForResult(cameraIntent, RequestBarCode);

            return listener.Task;
        }

        public string CarregarArquivo(string nomeArquivo)
        {
            var stream = mContext.Resources.OpenRawResource(mContext.Resources.GetIdentifier(nomeArquivo, "raw", mContext.PackageName));
            string conteudoArquivo = "";
            using (var reader = new StreamReader(stream))
            {
                conteudoArquivo = reader.ReadToEnd();
            }
            return conteudoArquivo;
        }

        private class ActivityResultListener
        {
            private readonly TaskCompletionSource<Stream> Complete = new TaskCompletionSource<Stream>();
            public Task<Stream> Task { get { return Complete.Task; } }

            public ActivityResultListener(MainActivity activity)
            {
                // subscribe to activity results
                activity.ActivityResult += OnActivityResult;
            }

            private void OnActivityResult(int requestCode, Result resultCode, Intent data)
            {
                // unsubscribe from activity results
                var activity = (MainActivity)Forms.Context;
                activity.ActivityResult -= OnActivityResult;

                Log.Debug("ON LOAD IMAGE", "request: " + requestCode + " result: " + resultCode.ToString());
                // process result
                if (requestCode != 1000 || (resultCode.ToString() != "2" && resultCode != Result.Ok) || data == null)
                    Complete.TrySetResult(null);
                else
                {
                    Android.Net.Uri uri = data.Data;
                    Stream stream = ((MainActivity)Forms.Context).ContentResolver.OpenInputStream(uri);
                    Complete.SetResult(stream);
                }
            }
        }
    }
}