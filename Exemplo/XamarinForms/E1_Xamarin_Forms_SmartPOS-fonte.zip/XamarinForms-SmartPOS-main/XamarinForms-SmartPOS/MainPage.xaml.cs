﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace XamarinForms_SmartPOS
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        async void openPrinterPage(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new PrinterMenuPage());
        }

        async void openElginPayPage(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new ElginPayPage());
        }

        async void openCarteiraDigitalPage(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new CarteiraDigitalPage());
        }

        async void openBarCodePage(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new BarcodeReaderPage());
        }
        protected override void OnAppearing()
        {
            Console.WriteLine("STOP INTERNA");
            PrinterMenuPage.printerService.PrinterStop();
        }
    }
}
