﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace XamarinForms_SmartPOS
{
    public interface IPrinter
    {
        int PrinterInternalImpStart();

        int PrinterExternalImpStart(string ip, int port);

        void PrinterStop();

        int AvancaLinhas(Dictionary<string, object> map);

        int CutPaper(Dictionary<string, object> map);

        int ImprimeTexto(Dictionary<string, object> map);

        int CodeOfBarCode(string barCodeName);

        int ImprimeBarCode(Dictionary<string, object> map);

        int ImprimeQR_CODE(Dictionary<string, object> map);

        int ImprimeImagem(Stream bitmap);

        int ImprimeImagemPadrao();

        int ImprimeXMLNFCe(Dictionary<string, object> map);

        int ImprimeXMLSAT(Dictionary<string, object> map);

        int ImprimeCupomTEF(Dictionary<string, object> map);

        int StatusGaveta();

        int AbrirGaveta();

        int StatusSensorPapel();

        int StatusSensorPapelSmartPOS();
        void AlertMessageStatus(string messageAlert);

        bool IsIpValid(string ip);

        Task<Stream> GetImageStreamAsync();
    }
}
