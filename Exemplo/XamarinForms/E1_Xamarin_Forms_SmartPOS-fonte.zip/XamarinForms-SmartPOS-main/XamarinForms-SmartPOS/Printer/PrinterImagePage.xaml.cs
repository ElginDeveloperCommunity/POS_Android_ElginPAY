﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PrinterImagePage : ContentPage
    {
        Stream selectedImage;
        public PrinterImagePage()
        {
            InitializeComponent();

            btnSelecionarImagem.Clicked += async delegate
            {
                await DisplayAlert("AVISO", "Certifique-se de que a imagem selecionada tenha até 400px de largura ou ela será cortada durante a impressão.", "OK");
                Stream imageStream = await PrinterMenuPage.printerService.GetImageStreamAsync();
                if (imageStream != null)
                {
                    selectedImage = new MemoryStream();
                    imageStream.CopyTo(selectedImage);

                    // RESETAR STREAMS
                    selectedImage.Position = 0;
                    imageStream.Position = 0;

                    imageView.Source = ImageSource.FromStream(() => imageStream);
                }
            };

            btnImprimirImagem.Clicked += delegate
            {
                if (selectedImage != null)
                {
                    //printerInstance.imprimeImagem(bitmap);
                    selectedImage.Position = 0;
                    Console.WriteLine("ImprimeImagem: FIM {0}", PrinterMenuPage.printerService.ImprimeImagem(selectedImage).ToString());
                }
                else
                {
                    //printerInstance.imprimeImagem(bitmap);
                    Console.WriteLine("ImprimeImagemPadrao: FIM {0}", PrinterMenuPage.printerService.ImprimeImagemPadrao().ToString());
                }

                JumpLine();

                Dictionary<string, object> mapValues = new Dictionary<string, object>
                {
                    ["quant"] = 1
                };
                if (chkCutPaper.IsChecked) PrinterMenuPage.printerService.CutPaper(mapValues);
            };

            if (PrinterMenuPage.selectedPrinterType.Equals("Interna"))
            {
                chkCutPaperContainer.IsVisible = false;
            }
        }
        public void JumpLine()
        {
            Dictionary<string, object> mapValues = new Dictionary<string, object>
            {
                ["quant"] = 10
            };
            PrinterMenuPage.printerService.AvancaLinhas(mapValues);
        }
    }
}