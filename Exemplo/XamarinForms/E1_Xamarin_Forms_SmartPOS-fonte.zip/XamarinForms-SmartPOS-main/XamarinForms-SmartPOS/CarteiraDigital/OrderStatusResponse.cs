﻿using Newtonsoft.Json;

namespace XamarinForms_SmartPOS
{
    public class OrderStatusResponse
    {
        [JsonProperty(PropertyName = "status")]
        public string status { get; set; }
    }
}