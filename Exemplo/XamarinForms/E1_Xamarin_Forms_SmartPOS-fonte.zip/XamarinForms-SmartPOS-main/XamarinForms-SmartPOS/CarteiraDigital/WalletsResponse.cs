﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace XamarinForms_SmartPOS
{
    class WalletsResponse
    {
        [JsonProperty(PropertyName = "wallets")]
        public List<Wallet> wallets { get; set; }
    }
}