﻿using Newtonsoft.Json;

namespace XamarinForms_SmartPOS
{
    public class CancelOrderResponse
    {
        [JsonProperty(PropertyName = "status")]
        public string status { get; set; }
    }
}