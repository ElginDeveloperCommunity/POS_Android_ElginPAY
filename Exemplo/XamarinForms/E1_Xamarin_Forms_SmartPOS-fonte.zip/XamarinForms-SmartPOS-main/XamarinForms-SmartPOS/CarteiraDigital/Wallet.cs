﻿using Newtonsoft.Json;

namespace XamarinForms_SmartPOS
{
    public class Wallet
    {
        [JsonProperty(PropertyName = "name")]
        public string name { get; set; }
    }
}