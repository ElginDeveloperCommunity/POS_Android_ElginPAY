﻿namespace XamarinForms_SmartPOS
{
    public interface IElginPay
    {
        void IniciaVendaDebito(string valor);

        void IniciaVendaCredito(string valor, int tipoFinanciamento, int numeroParcelas);

        void IniciaCancelamentoVenda(string valor);

        void IniciaOperacaoAdministrativa();
        void AlertMessageStatus(string titleAlert, string messageAlert);
    }
}
