﻿using BR.Com.Setis.Interfaceautomacao;
using System.Collections.Generic;

namespace XamarinForms_SmartPOS
{
    public interface IElginPay
    {
        void IniciarPagamentoDebito(string valor);

        void IniciarPagamentoCredito(string valor, int tipoFinanciamento);

        void IniciarCancelamentoVenda(string valor);

        void IniciarOperacaoAdministrativa();
        void AlertMessageStatus(string titleAlert, string messageAlert);
    }
}
