﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Xamarin.Forms;
using System.Globalization;

namespace XamarinForms_SmartPOS
{
    class InputMaskMoney : Behavior<Entry>
    {

        private bool _hasFormattedOnce = false;
        protected override void OnAttachedTo(Entry entry)
        {
            entry.TextChanged += OnEntryTextChanged;
            entry.Focused += EntryOnFocused;
            entry.Unfocused += EntryOnUnfocused;
            base.OnAttachedTo(entry);
        }

        private void EntryOnUnfocused(object sender, FocusEventArgs e)
        {
            var entry = sender as Entry;
            if (entry?.Text.Trim().Length == 0)
            {
                entry.Text = "0.00";
            }
            else if (entry?.Text == "0")
            {
                entry.Text = "0.00";
            }
        }

        private void EntryOnFocused(object sender, FocusEventArgs e)
        {
            var entry = sender as Entry;
            if (entry?.Text == "0.00")
            {
                entry.Text = "";
            }
        }

        protected override void OnDetachingFrom(Entry entry)
        {
            entry.TextChanged -= OnEntryTextChanged;
            entry.Focused -= EntryOnFocused;
            entry.Unfocused -= EntryOnUnfocused;
            base.OnDetachingFrom(entry);
        }

        private void OnEntryTextChanged(object sender, TextChangedEventArgs args)
        {
            if (args.NewTextValue.Contains("."))
            {
                if (args.NewTextValue.Length - 1 - args.NewTextValue.IndexOf(".") > 2)
                {
                    var s = args.NewTextValue.Substring(0, args.NewTextValue.IndexOf(".") + 2 + 1);
                    ((Entry)sender).Text = s;
                    ((Entry)sender).SelectionLength = s.Length;
                }
            }
        }

        public static string CleanInputMaskMoney(string value)
        {
            return value.Replace("[-]", "").Replace("[:]", "")
                    .Replace("[/]", "").Replace("[(]", "").Replace(",", "")
                    .Replace("[)]", "").Replace("[" + Regex.Escape(NumberFormatInfo.CurrentInfo.CurrencySymbol + "]"), "").Trim();
        }
    }
}
