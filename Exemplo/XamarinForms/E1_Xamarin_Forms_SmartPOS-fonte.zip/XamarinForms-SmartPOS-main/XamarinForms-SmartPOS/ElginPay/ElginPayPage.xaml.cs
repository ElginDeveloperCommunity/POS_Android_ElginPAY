﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ElginPayPage : ContentPage
    {
        IElginPay elginPayService = DependencyService.Get<IElginPay>();

        //INIT DEFAULT OPTIONS
        string selectedPaymentMethod = "Crédito";
        int selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;
        int numberOfInstallments = 1;

        // TYPE OF INSTALLMENTS
        private const int FINANCIAMENTO_A_VISTA = 1;
        private const int FINANCIAMENTO_PARCELADO_EMISSOR = 2;
        private const int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 3;

        private string retornoOperacao = "";

        public ElginPayPage()
        {
            InitializeComponent();

            //INIT DEFAULT INPUTS
            MaskInputValue();
            valorEntry.Text = "20.00";
            numberOfInstallmentsEntry.Text = numberOfInstallments.ToString();

            btnCreditOption.BorderColor = Color.FromHex("23F600");
            btnAvistaOption.BorderColor = Color.FromHex("23F600");
            containerInstallmentOptions.IsVisible = true;

            //SELECT OPTION CREDIT PAYMENT
            btnCreditOption.Clicked += delegate {
                selectedPaymentMethod = "Crédito";

                btnCreditOption.BorderColor = Color.FromHex("23F600");
                btnDebitOption.BorderColor = Color.Black;

                containerInstallmentOptions.IsVisible = true;

                //linearLayout of installmentsNumber should be restored
                numberOfInstallmentsLayout.IsVisible = true;
                numberOfInstallmentsEntry.Text = "1";
            };

            //SELECT OPTION DEBIT PAYMENT
            btnDebitOption.Clicked += delegate {
                selectedPaymentMethod = "Débito";

                btnCreditOption.BorderColor = Color.Black;
                btnDebitOption.BorderColor = Color.FromHex("23F600");

                containerInstallmentOptions.IsVisible = false;

                //linearLayout of installmentsNumber shold be gone:
                numberOfInstallmentsLayout.IsVisible = false;
            };

            //SELECT OPTION AVISTA INSTALLMENT
            btnAvistaOption.Clicked += delegate {
                selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;

                btnStoreOption.BorderColor = Color.Black;
                btnAdmOption.BorderColor = Color.Black;
                btnAvistaOption.BorderColor = Color.FromHex("23F600");
            };

            //SELECT OPTION STORE INSTALLMENT
            btnStoreOption.Clicked += delegate {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

                btnStoreOption.BorderColor = Color.FromHex("23F600");
                btnAdmOption.BorderColor = Color.Black;
                btnAvistaOption.BorderColor = Color.Black;
            };

            //SELECT OPTION ADM INSTALLMENT
            btnAdmOption.Clicked += delegate {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_EMISSOR;

                btnStoreOption.BorderColor = Color.Black;
                btnAdmOption.BorderColor = Color.FromHex("23F600");
                btnAvistaOption.BorderColor = Color.Black;
            };

            //SELECT BUTTON SEND TRANSACTION
            btnSendTransaction.Clicked += delegate {
                if (IsEntriesValid())
                {
                    if (!ValidInstallmentsField()) return;
                    StartActionTEF("SALE");
                }
            };

            //SELECT BUTTON CANCEL TRANSACTION
            btnCancelTransaction.Clicked += delegate
            {
                if (IsEntriesValid())
                {
                    StartActionTEF("CANCEL");
                }
            };

            //SELECT BUTTON CONFIGS TRANSACTION
            btnConfigsTransaction.Clicked += delegate
            {
                elginPayService.IniciaOperacaoAdministrativa();
            };
        }

        public void StartActionTEF(string action)
        {
            // Com o subscribe, aguardamos uma notificação que será enviada pelo Handler identificada pela chave ELGIN_PAY
            MessagingCenter.Subscribe<Application, string>(this, "ELGIN_PAY", (sender, resposta) =>
            {
                retornoOperacao = resposta;

                // Exibir um toast com a saida obtida
                // DependencyService.Get<IMessage>().LongAlert(retornoOperacao);

                DisplayAlert("DADOS ELGIN PAY:", retornoOperacao, "OK");

                // O Unsubscribe é preciso para que o Toast não seja mostrado mais de uma vez nos testes subsequentes
                MessagingCenter.Unsubscribe<Application, string>(this, "ELGIN_PAY");
            });
            SendElginPayParams(action);
        }

        public void SendElginPayParams(string action)
        {
            elginPayService = DependencyService.Get<IElginPay>();
            if (IsValueInvalidToElginPAY(valorEntry.Text))
            {
                AlertMessageStatus("Alerta", "O valor para essa transação deve ser maior ou igual a 1.00");
                return;
            }

            string cleanValue = CleanInputValue(valorEntry.Text.ToString());
            if (action.Equals("SALE"))
            {
                //Na opçao de pagamento por credito na lib E1 de versao 1.0.16 ou superior é necessario a data em que a venda foi realizada como parametro para realizar o cancelamento, para fins de simplificaçao e tomando que o app experience da Elgin
                //se trata de um exemplo iremos enviar sempre a data do dia atual.
                if (selectedPaymentMethod == "Crédito")
                {
                    elginPayService.IniciaVendaCredito(cleanValue, selectedInstallmentsMethod, numberOfInstallments);

                }
                else if (selectedPaymentMethod == "Débito")
                {
                    elginPayService.IniciaVendaDebito(cleanValue);
                }
            }
            if (action.Equals("CANCEL"))
            {
                elginPayService.IniciaCancelamentoVenda(cleanValue);
            }
        }

        public bool ValidInstallmentsField()
        {
            try
            {
                int intNumberOfInstallments = int.Parse(numberOfInstallmentsEntry.Text);

                if (intNumberOfInstallments == 0)
                {
                    AlertMessageStatus("Alert", "Digite um valor de número de parcelas maior que 0!");
                    return false;
                }

                //Como não há nenhum problema com o valor do campo de parcelas, atualizamos a váriavel:
                this.numberOfInstallments = intNumberOfInstallments;

                return true;

            }
            catch
            {
                //Como o inputType do campo está setado como "number" a única exception possível para este catch é de o campo estar vazio, uma vez que não é possível inserir quaisquer cacteres alem dos digitos [0-9].

                AlertMessageStatus("Alert", "O campo número de parcelas não pode ser vazio! Digite algum valor.");
                return false;
            }
        }

        public bool IsEntriesValid()
        {
            if (IsValueNotEmpty(valorEntry.Text.ToString()))
            {
                return true;
            }
            else
            {
                AlertMessageStatus("Alerta", "Verifique a entrada de valor de pagamento!");
                return false;
            }
        }

        public void AlertMessageStatus(string titleAlert, string messageAlert)
        {
            elginPayService.AlertMessageStatus(titleAlert, messageAlert);
        }

        public bool IsValueNotEmpty(string inputTextValue)
        {
            return !CleanInputValue(inputTextValue).Equals("0.00");
        }

        public bool IsValueInvalidToElginPAY(string inputTextValue)
        {
            string s = inputTextValue.Replace(",", ".");
            double value = double.Parse(s);
            return value < 1.00;
        }

        public bool IsInstallmentEmptyOrLessThanZero(string inputTextInstallment)
        {
            if (inputTextInstallment.Equals(""))
            {
                return false;
            }
            else
            {
                return int.Parse(inputTextInstallment) > 0;
            }
        }

        private void MaskInputValue()
        {
            var mask = new InputMaskMoney();
            valorEntry.Behaviors.Add(mask);
        }

        public string CleanInputValue(string value)
        {
            return InputMaskMoney.CleanInputMaskMoney(value);
        }
    }
}