﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;


namespace XamarinForms_SmartPOS
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class ElginPayPage : ContentPage
    {
        IElginPay elginPayService = DependencyService.Get<IElginPay>();

        //INIT DEFAULT OPTIONS
        string selectedPaymentMethod = "Crédito";
        int selectedInstallmentType = FINANCIAMENTO_A_VISTA;
        int numberOfInstallments = 1;

        // TYPE OF INSTALLMENTS
        private const int FINANCIAMENTO_A_VISTA = 1;
        private const int FINANCIAMENTO_PARCELADO_EMISSOR = 2;
        private const int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 3;

        private string retornoOperacao = "";

        public ElginPayPage()
        {
            InitializeComponent();

            //INIT DEFAULT INPUTS
            valorEntry.Text = "R$ 20.00";
            valorEntry.TextChanged += OnFinancialTextChanged;
            numberOfInstallmentsEntry.Text = numberOfInstallments.ToString();

            btnCreditOption.BorderColor = Color.FromHex("23F600");
            btnAvistaOption.BorderColor = Color.FromHex("23F600");
            containerInstallmentOptions.IsVisible = true;

            //SELECT OPTION CREDIT PAYMENT
            btnCreditOption.Clicked += delegate {
                selectedPaymentMethod = "Crédito";

                btnCreditOption.BorderColor = Color.FromHex("23F600");
                btnDebitOption.BorderColor = Color.Black;

                containerInstallmentOptions.IsVisible = true;

                //linearLayout of installmentsNumber should be restored
                numberOfInstallmentsLayout.IsVisible = true;
                numberOfInstallmentsEntry.Text = "1";
            };

            //SELECT OPTION DEBIT PAYMENT
            btnDebitOption.Clicked += delegate {
                selectedPaymentMethod = "Débito";

                btnCreditOption.BorderColor = Color.Black;
                btnDebitOption.BorderColor = Color.FromHex("23F600");

                containerInstallmentOptions.IsVisible = false;

                //linearLayout of installmentsNumber shold be gone:
                numberOfInstallmentsLayout.IsVisible = false;
            };

            //SELECT OPTION AVISTA INSTALLMENT
            btnAvistaOption.Clicked += delegate {
                selectedInstallmentType = FINANCIAMENTO_A_VISTA;

                btnStoreOption.BorderColor = Color.Black;
                btnAdmOption.BorderColor = Color.Black;
                btnAvistaOption.BorderColor = Color.FromHex("23F600");
            };

            //SELECT OPTION STORE INSTALLMENT
            btnStoreOption.Clicked += delegate {
                selectedInstallmentType = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

                btnStoreOption.BorderColor = Color.FromHex("23F600");
                btnAdmOption.BorderColor = Color.Black;
                btnAvistaOption.BorderColor = Color.Black;
            };

            //SELECT OPTION ADM INSTALLMENT
            btnAdmOption.Clicked += delegate {
                selectedInstallmentType = FINANCIAMENTO_PARCELADO_EMISSOR;

                btnStoreOption.BorderColor = Color.Black;
                btnAdmOption.BorderColor = Color.FromHex("23F600");
                btnAvistaOption.BorderColor = Color.Black;
            };

            //SELECT BUTTON SEND TRANSACTION
            btnSendTransaction.Clicked += delegate {
                //Checa se o número de parcelas é valido
                if (IsValueValidToElginPay() && IsInstallmentsFieldValid()) {
                    StartActionTEF("SALE");
                }
            };

            //SELECT BUTTON CANCEL TRANSACTION
            btnCancelTransaction.Clicked += delegate
            {
                if (IsValueValidToElginPay())
                {
                    StartActionTEF("CANCEL");
                }
            };

            //SELECT BUTTON CONFIGS TRANSACTION
            btnConfigsTransaction.Clicked += delegate
            {
                elginPayService.IniciaOperacaoAdministrativa();
            };
        }

        public void StartActionTEF(string action)
        {
            // Com o subscribe, aguardamos uma notificação que será enviada pelo Handler identificada pela chave ELGIN_PAY
            MessagingCenter.Subscribe<Application, string>(this, "ELGIN_PAY", (sender, resposta) =>
            {
                retornoOperacao = resposta;

                // Exibir um toast com a saida obtida
                // DependencyService.Get<IMessage>().LongAlert(retornoOperacao);

                DisplayAlert("DADOS ELGIN PAY:", retornoOperacao, "OK");

                // O Unsubscribe é preciso para que o Toast não seja mostrado mais de uma vez nos testes subsequentes
                MessagingCenter.Unsubscribe<Application, string>(this, "ELGIN_PAY");
            });
            SendElginPayParams(action);
        }

        public void SendElginPayParams(string action)
        {
            elginPayService = DependencyService.Get<IElginPay>();

            //Remove a vírgula do campo referente ao valor, uma vez que o ElginPay espera o valore em centavos (ex: 1850 para R$ 18,50)
            string cleanValue = valorEntry.Text.Replace("R$", "").Replace(".", "").Replace(",", "").Trim();
            
            if (action.Equals("SALE"))
            {
                //Na opçao de pagamento por credito na lib E1 de versao 1.0.16 ou superior é necessario a data em que a venda foi realizada como parametro para realizar o cancelamento, para fins de simplificaçao e tomando que o app experience da Elgin
                //se trata de um exemplo iremos enviar sempre a data do dia atual.
                if (selectedPaymentMethod == "Crédito")
                {
                    elginPayService.IniciaVendaCredito(cleanValue, selectedInstallmentType, numberOfInstallments);

                }
                else if (selectedPaymentMethod == "Débito")
                {
                    elginPayService.IniciaVendaDebito(cleanValue);
                }
            }
            if (action.Equals("CANCEL"))
            {
                elginPayService.IniciaCancelamentoVenda(cleanValue);
            }
        }

        public void AlertMessageStatus(string titleAlert, string messageAlert)
        {
            elginPayService.AlertMessageStatus(titleAlert, messageAlert);
        }

        public bool IsValueValidToElginPay()
        {
            string s = valorEntry.Text.Replace("R$", "").Replace(",", ".").Trim();
            double value = double.Parse(s);
            bool isValid = value / 100 >= 1.00;
            if (!isValid)
            {
                elginPayService.AlertMessageStatus("Alerta", "O valor mínimo para a transação é de R$1.00!");
            }
            return isValid;
        }

        public bool IsInstallmentsFieldValid()
        {
            int intNumberOfInstallments = int.Parse(numberOfInstallmentsEntry.Text);
            //Se o parcelamento não for a vista, o número mínimo de parcelas para se iniciar uma transação é 2
            if ((selectedInstallmentType == FINANCIAMENTO_PARCELADO_EMISSOR || selectedInstallmentType == FINANCIAMENTO_PARCELADO_ESTABELECIMENTO) && intNumberOfInstallments < 2)
            {
                elginPayService.AlertMessageStatus("Alerta", "O número mínimo de parcelas para esse tipo de parcelamento é 2!");
                return false;
            }

            //Como não há nenhum problema com o valor do campo de parcelas, atualizamos a váriavel:
            numberOfInstallments = intNumberOfInstallments;

            return true;
        }

        private void OnFinancialTextChanged(object sender, TextChangedEventArgs e)
        {
            var entry = (Entry)sender;

            var amt = e.NewTextValue.Replace("R$", "").Trim();


            if (decimal.TryParse(amt, out decimal num))
            {
                // Init our number
                if (string.IsNullOrEmpty(e.OldTextValue))
                {
                    num = num / 100;
                }
                // Shift decimal to right if added a decimal digit
                else if (num.DecimalDigits() > 2 && !e.IsDeletion())
                {
                    num = num * 10;
                }
                // Shift decimal to left if deleted a decimal digit
                else if (num.DecimalDigits() < 2 && e.IsDeletion())
                {
                    num = num / 10;
                }

                entry.Text = num.ToString("C");
            }
            else
            {
                entry.Text = e.OldTextValue;
            }
        }
    }
}