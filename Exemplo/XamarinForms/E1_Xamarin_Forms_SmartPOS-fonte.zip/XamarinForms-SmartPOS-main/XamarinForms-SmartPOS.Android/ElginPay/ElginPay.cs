﻿using Android.App;
using Android.Content;
using Android.Content.Res;
using Android.Widget;
using Android.Graphics;
using Android.Views.InputMethods;
using Android.Text;
using Xamarin.Forms;
using Android.OS;
using Android.Util;
using Java.IO;
using Java.Text;
using Java.Util;
using BR.Com.Setis.Interfaceautomacao;
using System.IO;
using IOException = Java.IO.IOException;
using File = Java.IO.File;

[assembly: Dependency(typeof(XamarinForms_SmartPOS.Droid.ElginPay))]
namespace XamarinForms_SmartPOS.Droid
{
    class ElginPay : IElginPay
    {
        private Handler handler;
        private Context context;
        readonly Com.Elgin.E1.Pagamento.ElginPay pagamento = new Com.Elgin.E1.Pagamento.ElginPay();

        public ElginPay()
        {
            context = (MainActivity)Forms.Context;
            pagamento.SetPersonalizacao(ObterPersonalizacao());

            //USADO PARA ENVIAR E PROCESSAR MENSAGENS
            handler = new CustomHandler(Looper.MainLooper, this);
        }

        public void IniciaVendaDebito(string valor)
        {
            Toast.MakeText(context, "Debito", ToastLength.Long).Show();
            pagamento.IniciaVendaDebito(valor, context, handler);
        }

        public void IniciaVendaCredito(string valor, int tipoFinanciamento, int numeroParcelas)
        {
            Toast.MakeText(context, "Crédito", ToastLength.Long).Show();
            pagamento.IniciaVendaCredito(valor, tipoFinanciamento, numeroParcelas, context, handler);
        }

        public void IniciaCancelamentoVenda(string valor)
        {

            //Data do dia de hoje:
            Date date = new Date();

            //Objeto capaz de formatar a date para o formato aceito pelo Elgin Pay ("dd/mm/aa")
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

            //Aplicando formatação
            string todayDate = dateFormat.Format(date);

            // Declare your builder here -
            AlertDialog.Builder builder = new AlertDialog.Builder(context);

            //Definindo título do AlertDialog
            builder.SetTitle("Código de Referência:");

            // Criando um EditText para pegar o input do usuário na caixa de diálogo
            EditText input = new EditText(context);

            //Configurando o EditText para negrito e configurando o tipo de inserção para apenas número
            input.Typeface = Typeface.DefaultBold;
            input.InputType = InputTypes.ClassNumber;

            //Tornando o dialógo não-cancelável
            builder.SetCancelable(false);

            builder.SetView(input);

            builder.SetPositiveButton("OK", (senderAlert, args) => {
                string saleRef = input.Text;

                //Setando o foco de para o input do dialógo
                input.RequestFocus();
                InputMethodManager imm = (InputMethodManager)context.GetSystemService(Context.InputMethodService);
                imm.ShowSoftInput(input, ShowFlags.Implicit);

                if (saleRef.Equals(""))
                {
                    AlertMessageStatus("Alert", "O campo código de referência da transação não pode ser vazio! Digite algum valor.");
                    return;
                }
                else
                {
                    Toast.MakeText(context, "Cancelamento", ToastLength.Long).Show();
                    pagamento.IniciaCancelamentoVenda(valor, saleRef, todayDate, context, handler);
                }
            });

            builder.Show();
        }

        public void IniciaOperacaoAdministrativa()
        {
            Toast.MakeText(context, "Administrativa", ToastLength.Long).Show();
            pagamento.IniciaOperacaoAdministrativa(context, handler);
        }

        public void AlertMessageStatus(string titleAlert, string messageAlert)
        {
            AlertDialog alertDialog = new AlertDialog.Builder(context).Create();
            alertDialog.SetTitle(titleAlert);
            alertDialog.SetMessage(messageAlert);
            alertDialog.SetButton((int)DialogButtonType.Neutral, "OK", (c, ev) =>
            {
                ((IDialogInterface)c).Dispose();
            });
            alertDialog.Show();
        }

        private File CreateFileFromInputStream(Stream inputStream)
        {
            try
            {
                File f = new File("sdcard/logo2.png");
                OutputStream outputStream = new FileOutputStream(f);
                byte[] buffer = new byte[1024];
                int length = 0;

                while ((length = inputStream.Read(buffer)) > 0)
                {
                    outputStream.Write(buffer, 0, length);
                }

                outputStream.Close();
                inputStream.Close();

                return f;
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }

            return null;
        }

        private Personalizacao ObterPersonalizacao()
        {
            //Processo de personalização do layout
            Personalizacao.Builder pb = new Personalizacao.Builder();
            string corDestaque = "#FED20B"; // AMARELO
            string corPrimaria = "#050609"; // PRETO
            string corSecundaria = "#808080";

            pb.InformaCorFonte(corDestaque);
            pb.InformaCorFonteTeclado(corPrimaria);
            pb.InformaCorFundoToolbar(corDestaque);
            pb.InformaCorFundoTela(corPrimaria);
            pb.InformaCorTeclaLiberadaTeclado(corDestaque);
            pb.InformaCorTeclaPressionadaTeclado(corSecundaria);
            pb.InformaCorFundoTeclado(corPrimaria);
            pb.InformaCorTextoCaixaEdicao(corDestaque);
            pb.InformaCorSeparadorMenu(corDestaque);

            try
            {
                AssetManager am = context.Assets;
                Stream inputStream = am.Open("logo.png");
                File file = CreateFileFromInputStream(inputStream);
                pb.InformaIconeToolbar(file);
            }
            catch (IOException e)
            {
                e.PrintStackTrace();
            }

            return pb.Build();
        }

        private class CustomHandler : Handler
        {
            ElginPay ctx;
            public CustomHandler(Looper l, ElginPay ctx) : base(l)
            {
                this.ctx = ctx;
            }

            public override void HandleMessage(Message msg)
            {
                base.HandleMessage(msg);
                string saida = (string)msg.Obj;
                //Toast.MakeText(ctx.context, saida, ToastLength.Long).Show();
                Log.Debug("Retorno", saida);

                // Notifica o módulo Forms quando a operação finaliza e envia o retorno do ElginPay
                MessagingCenter.Send(Xamarin.Forms.Application.Current, "ELGIN_PAY", saida);
            }
        }
    }
}