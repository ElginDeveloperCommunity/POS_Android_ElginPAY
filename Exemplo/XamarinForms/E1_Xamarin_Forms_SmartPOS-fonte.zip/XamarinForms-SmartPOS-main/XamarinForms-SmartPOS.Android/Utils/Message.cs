﻿using Android.Widget;
using Xamarin.Forms;
using Application = Android.App.Application;

[assembly: Dependency(typeof(XamarinForms_SmartPOS.Droid.MessageService))]
namespace XamarinForms_SmartPOS.Droid
{
    class MessageService : IMessage
    {
        void IMessage.LongAlert(string message)
        {
            Toast.MakeText(Application.Context, message, ToastLength.Long).Show();
        }

        void IMessage.ShortAlert(string message)
        {
            Toast.MakeText(Application.Context, message, ToastLength.Short).Show();
        }
    }
}