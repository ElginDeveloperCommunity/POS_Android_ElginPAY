package com.elgin.e1_java_smartpos;

import com.elgin.e1_java_smartpos.ElginPayController.*;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;

import android.app.AlertDialog;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class ElginPayPage extends AppCompatActivity {
    ElginPayService elginPayService;
    public static String saidaUltimaTransacao = "";

    //numberOfInstallmentsLayout
    LinearLayout numberOfInstallmentsLayout;

    //EDIT TEXTs
    EditText editTextValue;
    EditText editTextNumberOfInstallments;

    public static Context ctx;

    //BUTTONS TYPE OF PAYMENTS
    Button buttonCreditOption;
    Button buttonDebitOption;

    //BUTTONS TYPE OF INSTALLMENTS
    Button buttonStoreOption;
    Button buttonAdmOption;
    Button buttonAvistaOption;
    LinearLayout containerTypeInsatllments;

    //BUTTONS ACTIONS TEF
    Button buttonSendTransaction;
    Button buttonCancelTransaction;
    Button buttonConfigsTransaction;

    //CHECKBOX
    CheckBox checkBoxCustomLayout;

    //INIT DEFAULT OPTIONS
    String selectedPaymentMethod = "Crédito";

    String selectedAction = "SALE";

    // TYPE OF INSTALLMENTS
    public static final int FINANCIAMENTO_A_VISTA = 1;
    public static final int FINANCIAMENTO_PARCELADO_EMISSOR = 2;
    public static final int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 3;

    ////INIT DEFAULT OPTIONS
    int selectedInstallmentType = FINANCIAMENTO_A_VISTA;

    int numberOfInstallments = 1;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elgin_pay_menu);

        elginPayService = new ElginPayService((this));

        ctx = this;

        //Finding LinearLayout to remove conditionally
        numberOfInstallmentsLayout = findViewById(R.id.linearLayoutNumberOfInstallments);

        //INIT EDIT TEXTs
        editTextValue = findViewById(R.id.editTextInputValue);
        editTextNumberOfInstallments = findViewById(R.id.editTextInputNumberOfInstallments);


        //INIT BUTTONS TYPES PAYMENTS
        buttonCreditOption = findViewById(R.id.buttonCreditOption);
        buttonDebitOption = findViewById(R.id.buttonDebitOption);
        containerTypeInsatllments = findViewById(R.id.containerTypeInsatllments);

        //INIT BUTTONS TYPE INSTALLMENTS
        buttonStoreOption = findViewById(R.id.buttonStoreOption);
        buttonAdmOption = findViewById(R.id.buttonAdmOption);
        buttonAvistaOption = findViewById(R.id.buttonAvistaOption);

        //INIT BUTTONS ACTIONS TEF
        buttonSendTransaction = findViewById(R.id.buttonSendTransactionTEF);
        buttonCancelTransaction = findViewById(R.id.buttonCancelTransactionTEF);
        buttonConfigsTransaction = findViewById(R.id.buttonConfigsTEF);

        checkBoxCustomLayout = findViewById(R.id.checkBoxCustomLayout);

        //SELECT INITIALS OPTION
        buttonCreditOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
        buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));

        //Set MaskInput on editTextValue
        editTextValue.addTextChangedListener(new InputMaskMoney(editTextValue));

        //INIT DEFAULT INPUTS
        editTextValue.setText("2000");

        //O padrão da aplicação é iniciar com a opção de pagamento por crédito com parcelamento a vista, portanto o número de parcelas deve ser obrigatoriamente 1
        editTextNumberOfInstallments.setText("1");
        this.numberOfInstallments = 1;
        editTextNumberOfInstallments.setEnabled(false);


        //SELECT OPTION CREDIT PAYMENT
        buttonCreditOption.setOnClickListener(v -> {
            selectedPaymentMethod = "Crédito";

            buttonCreditOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
            buttonDebitOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
            containerTypeInsatllments.setVisibility(View.VISIBLE);

            //linearLayout of installmentsNumber should be restored
            numberOfInstallmentsLayout.setVisibility(View.VISIBLE);
            editTextNumberOfInstallments.setText("1");
        });

        //SELECT OPTION DEBIT PAYMENT
        buttonDebitOption.setOnClickListener(v -> {
                selectedPaymentMethod = "Débito";

                buttonCreditOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
                buttonDebitOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
                containerTypeInsatllments.setVisibility(View.INVISIBLE);

                //linearLayout of installmentsNumber shold be gone:
                numberOfInstallmentsLayout.setVisibility(View.GONE);
            });


        //SELECT OPTION STORE INSTALLMENT
        buttonStoreOption.setOnClickListener(v -> {
            selectedInstallmentType = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

            buttonStoreOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
            buttonAdmOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
            buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));

            editTextNumberOfInstallments.setText("2");
            numberOfInstallments = 1;
            editTextNumberOfInstallments.setEnabled(true);
        });

        //SELECT OPTION ADM INSTALLMENT
        buttonAdmOption.setOnClickListener(v -> {
            selectedInstallmentType = FINANCIAMENTO_PARCELADO_EMISSOR;

            buttonStoreOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
            buttonAdmOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
            buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));

            editTextNumberOfInstallments.setText("2");
            numberOfInstallments = 1;
            editTextNumberOfInstallments.setEnabled(true);
        });

        //SELECT OPTION AVISTA INSTALLMENT
        buttonAvistaOption.setOnClickListener(v -> {
            selectedInstallmentType = FINANCIAMENTO_A_VISTA;

            buttonStoreOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx,R.color.black));
            buttonAdmOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx,R.color.black));
            buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx,R.color.verde));

            editTextNumberOfInstallments.setText("1");
            numberOfInstallments = 1;
            editTextNumberOfInstallments.setEnabled(false);
        });

        /**
         * @!isValueValidToElginPay() é uma checagem feita antes de qualquer transação para checar se o valor a ser enviado é superior a R$ 1.00 e impedir transação caso seja.
         */
        //SELECT BUTTON SEND TRANSACTION
        buttonSendTransaction.setOnClickListener(v -> {
            //Checa se o número de parcelas é valido
            if(isValueValidToElginPay() && isInstallmentsFieldValid()){
                startActionTEF("SALE");
            }
        });

        //SELECT BUTTON CANCEL TRANSACTION
        buttonCancelTransaction.setOnClickListener(v -> {
            if(isValueValidToElginPay()) {
                startActionTEF("CANCEL");
            }
        });

        //SELECT BUTTON CONFIGS TRANSACTION
        buttonConfigsTransaction.setOnClickListener(v -> elginPayService.IniciarOperacaoAdministrativa());

        checkBoxCustomLayout.setOnClickListener(v -> {
            if(checkBoxCustomLayout.isChecked())
                elginPayService.setCustomLayoutOn();
            else
                elginPayService.setCustomLayoutOff();
            }
        );
    }

    public void startActionTEF(String action){
        selectedAction = action;
        sendElginPayParams(action);
    }

    public void sendElginPayParams(String action){
        //Remove a vírgula do campo referente ao valor, uma vez que o ElginPay espera o valore em centavos (ex: 1850 para R$ 18,50)
        String inputCleanForElginPay = editTextValue.getText().toString().replaceAll(",", "").trim();

        if (action.equals("SALE"))
        {
            //Na opçao de pagamento por credito na lib E1 de versao 1.0.16 ou superior é necessario a data em que a venda foi realizada como parametro para realizar o cancelamento, para fins de simplificaçao e tomando que o app experience da Elgin
            //se trata de um exemplo iremos enviar sempre a data do dia atual.
            if (selectedPaymentMethod.equals("Crédito"))
                elginPayService.IniciarPagamentoCredito(inputCleanForElginPay, selectedInstallmentType, this.numberOfInstallments);
            else if (selectedPaymentMethod.equals("Débito"))
                elginPayService.IniciarPagamentoDebito(inputCleanForElginPay);
        }
        else if (action.equals("CANCEL"))
            elginPayService.IniciarCancelamentoVenda(inputCleanForElginPay);
    }

    public boolean isInstallmentsFieldValid(){
        try{
            int intNumberOfInstallments = Integer.parseInt( String.valueOf(editTextNumberOfInstallments.getText()));

            //Se o parcelamento não for a vista, o número mínimo de parcelas para se iniciar uma transação é 2
            if( (this.selectedInstallmentType == FINANCIAMENTO_PARCELADO_EMISSOR || this.selectedInstallmentType == FINANCIAMENTO_PARCELADO_ESTABELECIMENTO ) && intNumberOfInstallments < 2){
                alertMessageStatus( "Alerta","O número mínimo de parcelas para esse tipo de parcelamento é 2!");
                return false;
            }

            //Como não há nenhum problema com o valor do campo de parcelas, atualizamos a váriavel:
            this.numberOfInstallments = intNumberOfInstallments;

            return true;
        } catch (Exception e){
            //Como o inputType do campo está setado como "number" a única exception possível para este catch é de o campo estar vazio, uma vez que não é possível inserir quaisquer cacteres alem dos digitos [0-9].
            alertMessageStatus("Alert","O campo número de parcelas não pode ser vazio! Digite algum valor.");

            return false;
        }
    }

    public boolean isValueValidToElginPay(){
        //Valor do campo formatado para a criação do BigDecimal formatado
        String valueFormatted = editTextValue.getText().toString().replaceAll(",", "\\.").trim();

        BigDecimal actualValueInBigDecimal;
        try{
            //BigDecimal utilizado para comparar com 1.00 real (valor mínimo para transação ElginPay) com maior precisão
            actualValueInBigDecimal = new BigDecimal(valueFormatted);
        } catch(NumberFormatException e){
            //Se o número for maior que 999, a mask irá colocar um "." a mais, estas ocorrências devem ser removidas antes da comparação
            String[] valueSplitted = valueFormatted.split("\\.");
            List<String> thousandsUnit = new ArrayList<>(Arrays.asList(valueSplitted));

            StringBuilder valueWithoutThousandsComma = new StringBuilder();

            for(int i = 0; i < thousandsUnit.size() - 1; i++)
                valueWithoutThousandsComma.append(thousandsUnit.get(i));

            valueWithoutThousandsComma.append(".").append(thousandsUnit.get(thousandsUnit.size() - 1));

            actualValueInBigDecimal = new BigDecimal(valueWithoutThousandsComma.toString());
        }

        //Checa se o valor é menor que 1 real
        if(actualValueInBigDecimal.compareTo( new BigDecimal("1.00")) < 0){
            alertMessageStatus("Alerta", "O valor mínimo para a transação é de R$1.00!");
            return false;
        }else
            return true;
    }

    public static void alertMessageStatus(String titleAlert, String messageAlert){
        AlertDialog alertDialog = new AlertDialog.Builder(ctx).create();
        alertDialog.setTitle(titleAlert);
        alertDialog.setMessage(messageAlert);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                (dialog, which) -> dialog.dismiss());
        alertDialog.show();
    }
}