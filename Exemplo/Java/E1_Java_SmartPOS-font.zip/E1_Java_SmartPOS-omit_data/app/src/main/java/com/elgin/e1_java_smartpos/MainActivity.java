package com.elgin.e1_java_smartpos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;

import com.elgin.e1_java_smartpos.NFCE.NfcePage;

public class MainActivity extends AppCompatActivity {

    LinearLayout buttonPrinterMenu, buttonElginPay, buttonDigitalWallet, buttonNFCE, buttonBarcodeReader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonPrinterMenu = findViewById(R.id.buttonPrinterMenu);
        buttonElginPay = findViewById(R.id.buttonElginPay);
        buttonDigitalWallet = findViewById(R.id.buttonDigitalWallet);
        buttonNFCE = findViewById(R.id.buttonNFCE);
        buttonBarcodeReader = findViewById(R.id.buttonBarcodeReader);

        buttonPrinterMenu.setOnClickListener(v -> startActivity(PrinterMenu.class));

        buttonElginPay.setOnClickListener(v -> startActivity(ElginPayPage.class));

        buttonDigitalWallet.setOnClickListener(v -> startActivity(ShipayMenu.class));

        buttonNFCE.setOnClickListener( v -> startActivity(NfcePage.class));

        buttonBarcodeReader.setOnClickListener(v -> startActivity(BarcodeReader.class));
    }



    public void startActivity(Class typeOfClass){
        Intent intent = new Intent(this, typeOfClass);
        startActivity(intent );
    }
}