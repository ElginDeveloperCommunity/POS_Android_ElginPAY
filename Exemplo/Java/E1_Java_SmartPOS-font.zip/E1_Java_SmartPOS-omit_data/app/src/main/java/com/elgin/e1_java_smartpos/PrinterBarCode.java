package com.elgin.e1_java_smartpos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.HashMap;
import java.util.Map;

public class PrinterBarCode extends AppCompatActivity {

    //EditText
    EditText editTextInputBarCode;

    //TextViews
    TextView textViewBarCodeWidth, textViewBarCodeHeight, textViewEstilicacao;

    //Spinner
    Spinner spinnerBarCodeType;
    Spinner spinnerBarCodeWidth;
    Spinner spinnerBarCodeHeight;

    //Radio Buttons
    RadioGroup radioGroupAlignBarCode;
    RadioButton buttonRadioAlignCenter;

    //Checkbox
    CheckBox checkBoxIsCutPaper;

    //Buttons
    Button buttonPrinterBarCode;

    //Default values
    String typeOfBarCode = "EAN 8";
    String typeAlignOfBarCode = "Centralizado";
    int widthOfBarCode = 1;
    int heightOfBarCode = 20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_bar_code);

        //editText
        editTextInputBarCode = findViewById(R.id.editTextInputBarCode);
        editTextInputBarCode.setText("40170725");

        //TextViews
        textViewEstilicacao = findViewById(R.id.textViewEstilizacao);
        textViewBarCodeWidth = findViewById(R.id.textViewBarCodeWidth);
        textViewBarCodeHeight = findViewById(R.id.textViewBarCodeHeight);


        //Radios, Spinners and Buttons
        spinnerBarCodeType = findViewById(R.id.spinnerBarCodeType);
        buttonRadioAlignCenter = findViewById(R.id.radioButtonBarCodeAlignCenter);
        spinnerBarCodeWidth = findViewById(R.id.spinnerBarCodeWidth);
        spinnerBarCodeHeight = findViewById(R.id.spinnerBarCodeHeight);
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode);

        //Checkboxs
        checkBoxIsCutPaper = findViewById(R.id.checkBoxCutPaperBarCode);

        if(PrinterMenu.selectedPrinterType.equals("Interna")) this.checkBoxIsCutPaper.setVisibility(View.INVISIBLE);

        //Initial state of views
        textViewEstilicacao.setVisibility(View.INVISIBLE);

        textViewBarCodeWidth.setVisibility(View.INVISIBLE);
        spinnerBarCodeWidth.setVisibility(View.INVISIBLE);

        textViewBarCodeHeight.setVisibility(View.INVISIBLE);
        spinnerBarCodeHeight.setVisibility(View.INVISIBLE);

        //Font Family
        spinnerBarCodeType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                typeOfBarCode = parent.getItemAtPosition(position).toString();
                setTypeCodeMessage(typeOfBarCode);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //Alignment
        buttonRadioAlignCenter.setChecked(true);
        radioGroupAlignBarCode = findViewById(R.id.radioGroupAlignBarCode);
        radioGroupAlignBarCode.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId) {
                case R.id.radioButtonBarCodeAlignLeft:
                    typeAlignOfBarCode = "Esquerda";
                    System.out.println(typeAlignOfBarCode);
                    break;
                case R.id.radioButtonBarCodeAlignCenter:
                    typeAlignOfBarCode = "Centralizado";
                    System.out.println(typeAlignOfBarCode);
                    break;
                case R.id.radioButtonBarCodeAlignRight:
                    typeAlignOfBarCode = "Direita";
                    System.out.println(typeAlignOfBarCode);
                    break;
            }
        });

        //Width
        spinnerBarCodeWidth.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                widthOfBarCode = Integer.parseInt(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        //Height
        spinnerBarCodeHeight.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                heightOfBarCode = Integer.parseInt(parent.getItemAtPosition(position).toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        //buttonPrinterBarCode
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode);

        //button print barcode
        buttonPrinterBarCode.setOnClickListener(v -> {
            if(typeOfBarCode.equals("QR CODE")){
                sendPrinterQrCode();
            }else{
                sendPrinterBarCode();
            }
        });
    }

    public void sendPrinterBarCode(){
        Map<String, Object> mapValues = new HashMap<>();

        if(editTextInputBarCode.getText().toString().equals("")) {
            alertMessage();
        }else{
            mapValues.put("barCodeType", typeOfBarCode);
            mapValues.put("text", editTextInputBarCode.getText().toString());
            mapValues.put("height", heightOfBarCode);
            mapValues.put("width", widthOfBarCode);
            mapValues.put("align", typeAlignOfBarCode);
            mapValues.put("quant", 10);

            int result = PrinterMenu.printerInstance.imprimeBarCode(mapValues);
            System.out.println("RESULT BAR CODE: " + result);
            jumpLine();

            if(checkBoxIsCutPaper.isChecked()) cutPaper();
        }
    }

    public void sendPrinterQrCode(){
        Map<String, Object> mapValues = new HashMap<>();

        if(editTextInputBarCode.getText().toString().equals("")) {
            alertMessage();
        }else{
            mapValues.put("qrSize", widthOfBarCode);
            mapValues.put("text", editTextInputBarCode.getText().toString());
            mapValues.put("align", typeAlignOfBarCode);
            mapValues.put("quant", 10);

            PrinterMenu.printerInstance.imprimeQR_CODE(mapValues);
            jumpLine();
            if(checkBoxIsCutPaper.isChecked()) cutPaper();
        }
    }


    public void setTypeCodeMessage(String typeActual){
        layoutChanges(typeActual);
        switch(typeActual){
            case "EAN 8":
                editTextInputBarCode.setText("40170725");
                break;
            case "EAN 13":
                editTextInputBarCode.setText("0123456789012");
                break;
            case "QR CODE":
                editTextInputBarCode.setText("ELGIN DEVELOPERS COMMUNITY");
                break;
            case "UPC-A":
                editTextInputBarCode.setText("123601057072");
                break;
            case "UPC-E":
                editTextInputBarCode.setText("00123457");
                break;
            case "CODE 39":
                editTextInputBarCode.setText("CODE39");
                break;
            case "ITF":
                editTextInputBarCode.setText("05012345678900");
                break;
            case "CODE BAR":
                editTextInputBarCode.setText("A3419500A");
                break;
            case "CODE 93":
                editTextInputBarCode.setText("CODE93");
                break;
            case "CODE 128":
                editTextInputBarCode.setText("{C1233");
                break;
        }
    }

    private void layoutChanges(String typeOfBarCode){
        if(typeOfBarCode.equals("QR CODE")){
            textViewEstilicacao.setVisibility(View.VISIBLE);
            textViewBarCodeWidth.setText("SQUARE");

            textViewBarCodeWidth.setVisibility(View.VISIBLE);
            spinnerBarCodeWidth.setVisibility(View.VISIBLE);

            textViewBarCodeHeight.setVisibility(View.INVISIBLE);
            spinnerBarCodeHeight.setVisibility(View.INVISIBLE);
        }
        else if(typeOfBarCode.equals("CODE 128")){
            textViewEstilicacao.setVisibility(View.VISIBLE);
            textViewBarCodeWidth.setText("WIDTH");

            textViewBarCodeWidth.setVisibility(View.VISIBLE);
            spinnerBarCodeWidth.setVisibility(View.VISIBLE);

            textViewBarCodeHeight.setVisibility(View.VISIBLE);
            spinnerBarCodeHeight.setVisibility(View.VISIBLE);
        }
        else{
            textViewEstilicacao.setVisibility(View.INVISIBLE);

            textViewBarCodeWidth.setVisibility(View.INVISIBLE);
            spinnerBarCodeWidth.setVisibility(View.INVISIBLE);

            textViewBarCodeHeight.setVisibility(View.INVISIBLE);
            spinnerBarCodeHeight.setVisibility(View.INVISIBLE);
        }
    }

    public void jumpLine(){
        Map<String, Object> mapValues = new HashMap<>();

        ///Se a impressão for por impressora externa, 5 é o suficiente; 10 caso contrário
        if(!PrinterMenu.printerInstance.isPrinterInternSelected)
            mapValues.put("quant", 5);
        else
            mapValues.put("quant", 10);

        PrinterMenu.printerInstance.AvancaLinhas(mapValues);
    }

    public void cutPaper(){
        Map<String, Object> mapValues = new HashMap<>();

        mapValues.put("quant", 1);

        PrinterMenu.printerInstance.cutPaper(mapValues);
    }

    public void alertMessage(){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Campo código vazio.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                (dialog, which) -> dialog.dismiss());
        alertDialog.show();
    }
}