package com.elgin.e1_java_smartpos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import com.elgin.e1_java_smartpos.Services.PrinterService;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PrinterMenu extends AppCompatActivity {

    //Printer Object
    public static PrinterService printerInstance;

    //EditTexts
    public static EditText editTextInputIP;

    //Radios
    RadioButton radioButtonConnectPrinterIntern;
    RadioGroup radioGroupConnectPrinterIE;

    //Buttons
    Button buttonPrinterText, buttonPrinterBarCode, buttonPrinterImage, buttonStatusPrinter, buttonStatusDrawer, buttonOpenDrawer;

    //Params
    public static String selectedPrinterType = "Interna";

    //Modelos de impressora
    private final String EXTERNAL_PRINTER_MODEL_I9 = "i9";
    private final String EXTERNAL_PRINTER_MODEL_I8 = "i8";

    //Modelo de impressora escolhido
    public String selectedPrinterModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_menu);

        printerInstance = new PrinterService(this);
        printerInstance.printerInternalImpStart();


        buttonPrinterText = findViewById(R.id.buttonPrinterText);
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode);
        buttonPrinterImage = findViewById(R.id.buttonPrinterImage);
        buttonStatusPrinter = findViewById(R.id.buttonStatusPrinter);
        buttonStatusDrawer = findViewById(R.id.buttonStatusDrawer);
        buttonOpenDrawer = findViewById(R.id.buttonOpenDrawer);

        radioButtonConnectPrinterIntern = findViewById(R.id.radioButtonConnectPrinterIntern);
        radioButtonConnectPrinterIntern.setChecked(true);

        editTextInputIP = findViewById(R.id.editTextInputIP);
        editTextInputIP.setText("192.168.0.100:9100");

        radioGroupConnectPrinterIE = findViewById(R.id.radioGroupConnectPrinterIE);
        radioGroupConnectPrinterIE.setOnCheckedChangeListener((group, checkedId) -> {
            switch (checkedId){
                case R.id.radioButtonConnectPrinterIntern:
                    selectedPrinterType = "Interna";
                    printerInstance.printerInternalImpStart();
                    break;

                case R.id.radioButtonConnectPrinterExtern:
                    if(isIpValid(editTextInputIP.getText().toString())){
                        selectedPrinterType = "Externa";
                        //Invoca o alertDialog que permite a escolha do modelo de impressora antes da tentativa de iniciar a conexão por IP
                        alertDialogSelectPrinterModelToConnect();
                    }else{
                        alertMessageStatus("Digite um IP válido.");
                        radioButtonConnectPrinterIntern.setChecked(true);
                    }
                    break;
            }
        });


        buttonPrinterText.setOnClickListener(v -> startActivity(PrinterText.class));

        buttonPrinterBarCode.setOnClickListener(v -> startActivity(PrinterBarCode.class));

        buttonPrinterImage.setOnClickListener(v -> startActivity(PrinterImage.class));

        buttonStatusPrinter.setOnClickListener(v -> statusPrinter());

        buttonStatusDrawer.setOnClickListener(v -> statusGaveta());

        buttonOpenDrawer.setOnClickListener(v -> abrirGaveta());
    }

    public void alertDialogSelectPrinterModelToConnect(){
        String[] operations = {EXTERNAL_PRINTER_MODEL_I9, EXTERNAL_PRINTER_MODEL_I8};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Selecione o modelo de impressora a ser conectado");

        //Tornando o dialógo não-cancelável
        builder.setCancelable(false);

        builder.setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Se a opção de cancelamento tiver sido escolhida, retorne sempre à opção de impressão por impressora interna
                radioButtonConnectPrinterIntern.setChecked(true);
                dialog.dismiss();
            }
        });

        builder.setItems(operations, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Envia o parâmetro escolhido para a função que atualiza o modelo de impressora selecionado
                setSelectedPrinterModel(which);

                //Tenta inicializar a impressora externa
                tryToConnectExternPrinter();
            }
        });
        builder.show();
    }



    public void setSelectedPrinterModel(int whichSelected){
        if(whichSelected == 0)
            this.selectedPrinterModel = EXTERNAL_PRINTER_MODEL_I9;
        else
            this.selectedPrinterModel = EXTERNAL_PRINTER_MODEL_I8;
    }

    public void tryToConnectExternPrinter(){
        String[] ipAndPort = editTextInputIP.getText().toString().split(":");

        int result = printerInstance.printerExternalImpStart(this.selectedPrinterModel, ipAndPort[0], Integer.parseInt(ipAndPort[1]));

        if(result != 0) {
            alertMessageStatus("A tentativa de conexão de impressora externa por IP não foi bem sucedida!");
            printerInstance.printerInternalImpStart();
            radioButtonConnectPrinterIntern.setChecked(true);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        printerInstance.printerStop();
    }

    public void statusPrinter(){
        String statusPrinter = "";
        int resultStatus = printerInstance.statusSensorPapel();
        System.out.println("STATUS GAVETA: " + printerInstance.statusGaveta());

        if(resultStatus == 5)
            statusPrinter = "Papel está presente e não está próximo do fim!";
        else if(resultStatus == 6)
            statusPrinter = "Papel próximo do fim!";
        else if(resultStatus == 7)
            statusPrinter = "Papel ausente!";
        else
            statusPrinter = "Status Desconhecido!";

        alertMessageStatus(statusPrinter);
    }

    private void statusGaveta(){
        String statusGaveta = "";

        int resultStatusGaveta = this.printerInstance.statusGaveta();

        if(resultStatusGaveta == 1)
            statusGaveta = "Gaveta aberta!";
        else if(resultStatusGaveta == 2)
            statusGaveta = "Gaveta fechada!";
        else
            statusGaveta = "Status Desconhecido!";

        alertMessageStatus(statusGaveta);
    }

    private void abrirGaveta(){
        int resultStatusGaveta = this.printerInstance.abrirGaveta();
        Log.d("DEBUG", Integer.toString(resultStatusGaveta));
    }

    public void alertMessageStatus(String messageAlert){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(messageAlert);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                (dialog, which) -> dialog.dismiss());
        alertDialog.show();
    }

    public static boolean isIpValid(String ip) {
        Pattern pattern = Pattern.compile("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]):[0-9]+$");
        Matcher matcher = pattern.matcher(ip);
        return matcher.matches();
    }

    public void startActivity(Class typeOfClass){
        Intent intent = new Intent(this, typeOfClass);
        startActivity(intent );
    }
}