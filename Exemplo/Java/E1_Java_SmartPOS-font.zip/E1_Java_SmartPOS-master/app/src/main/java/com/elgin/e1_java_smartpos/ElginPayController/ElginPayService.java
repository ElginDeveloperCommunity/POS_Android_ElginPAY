 package com.elgin.e1_java_smartpos.ElginPayController;


import static com.elgin.e1_java_smartpos.ElginPayPage.alertMessageStatus;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.InputType;
import android.util.Log;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.elgin.e1.Pagamento.ElginPay;
import com.elgin.e1_java_smartpos.ElginPayPage;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import br.com.setis.interfaceautomacao.Confirmacoes;
import br.com.setis.interfaceautomacao.EntradaTransacao;
import br.com.setis.interfaceautomacao.ModalidadesPagamento;
import br.com.setis.interfaceautomacao.Operacoes;
import br.com.setis.interfaceautomacao.Personalizacao;
import br.com.setis.interfaceautomacao.SaidaTransacao;
import br.com.setis.interfaceautomacao.Transacoes;

public class ElginPayService {

    //Objeto utilizado para receber o contexto da classe ElginPayMenu para facilitar o uso de operações que necessitem de contexto.
    private Context context;

    ElginPay pagamento = new ElginPay();

    //USADO PARA ENVIAR E PROCESSAR MENSAGENS
    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            String saida = (String) msg.obj;

            //Guarda o ultimo retorno do Elgin Pay em uma váriavel reservada dentro da atividade que lida com o mesmo.
            ElginPayPage.saidaUltimaTransacao = saida;

            Log.d("DEBUG", saida);
            alertMessageStatus("Retorno ElginPay",ElginPayPage.saidaUltimaTransacao);
        }
    };

    public ElginPayService(Context c){
        context = c;
    }

    public void IniciarPagamentoDebito(String valor){
        Toast.makeText(context, "Débito", Toast.LENGTH_LONG).show();
        pagamento.iniciaVendaDebito(valor, context, handler);
    }

    public void IniciarPagamentoCredito(String valor, int tipoFinanciamento, int numeroParcelas)
    {
        Toast.makeText(context, "Crédito", Toast.LENGTH_LONG).show();
        pagamento.iniciaVendaCredito(valor, tipoFinanciamento, numeroParcelas, context, handler);
    }

    public void IniciarCancelamentoVenda(String valor)
    {
        //Data do dia de hoje:
        Date date = new Date();

        //Objeto capaz de formatar a date para o formato aceito pelo Elgin Pay ("dd/mm/aa")
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");

        //Aplicando formatação
        String todayDate = dateFormat.format(date);

        // Declare your builder here -
        final AlertDialog.Builder builder = new AlertDialog.Builder(this.context);

        //Definindo título do AlertDialog
        builder.setTitle("Código de Referência:");

        // Criando um EditText para pegar o input do usuário na caixa de diálogo
        final EditText input = new EditText(this.context);

        //Configurando o EditText para negrito e configurando o tipo de inserção para apenas número
        input.setTypeface(null, Typeface.BOLD);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);

        //Tornando o dialógo não-cancelável
        builder.setCancelable(false);

        builder.setView(input);

        builder.setPositiveButton("OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        String saleRef = input.getText().toString();

                        //Setando o foco de para o input do dialógo
                        input.requestFocus();
                        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);

                        if(saleRef.equals("")){
                            alertMessageStatus("Alert", "O campo código de referência da transação não pode ser vazio! Digite algum valor.");
                            return;
                        }else{
                            Toast.makeText(context, "Cancelamento", Toast.LENGTH_LONG).show();
                            pagamento.iniciaCancelamentoVenda(valor, saleRef, todayDate, context, handler);
                        }
                    }
                });

        builder.show();
    }

    public void IniciarOperacaoAdministrativa()
    {
        Toast.makeText(context, "Administrativa", Toast.LENGTH_LONG).show();
        pagamento.iniciaOperacaoAdministrativa(context, handler);
    }


    private File createFileFromInputStream(InputStream inputStream) {

        try{
            File f = new File("sdcard/logo2.png");
            OutputStream outputStream = new FileOutputStream(f);
            byte buffer[] = new byte[1024];
            int length = 0;

            while((length=inputStream.read(buffer)) > 0) {
                outputStream.write(buffer,0,length);
            }

            outputStream.close();
            inputStream.close();

            return f;
        }catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }

    private Personalizacao obterPersonalizacao(){
        //Processo de personalização do layout
        Personalizacao.Builder pb = new Personalizacao.Builder();
        String corDestaque = "#FED20B"; // AMARELO
        String corPrimaria = "#050609"; // PRETO
        String corSecundaria = "#808080";

        pb.informaCorFonte(corDestaque);
        pb.informaCorFonteTeclado(corPrimaria);
        pb.informaCorFundoToolbar(corDestaque);
        pb.informaCorFundoTela(corPrimaria);
        pb.informaCorTeclaLiberadaTeclado(corDestaque);
        pb.informaCorTeclaPressionadaTeclado(corSecundaria);
        pb.informaCorFundoTeclado(corPrimaria);
        pb.informaCorTextoCaixaEdicao(corDestaque);
        pb.informaCorSeparadorMenu(corDestaque);

        try {
            AssetManager am = context.getAssets();
            InputStream inputStream = am.open("logo.png");
            File file = createFileFromInputStream(inputStream);
            pb.informaIconeToolbar(file);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return pb.build();
    }

    //Métodos de customização

    //Aplica o layout do batpay ao objeto de pagamento
    public void setCustomLayoutOn(){
        this.pagamento.setPersonalizacao(obterPersonalizacao());
    }

    //Aplica um layout padrão ao objeto de pagamento
    public void setCustomLayoutOff(){
        this.pagamento.setPersonalizacao(new Personalizacao.Builder().build());
    }

}
