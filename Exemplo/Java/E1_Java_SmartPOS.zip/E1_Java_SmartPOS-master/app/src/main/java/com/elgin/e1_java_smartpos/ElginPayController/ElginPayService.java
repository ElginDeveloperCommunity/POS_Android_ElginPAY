 package com.elgin.e1_java_smartpos.ElginPayController;


import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.elgin.e1.Pagamento.ElginPay;
import com.elgin.e1_java_smartpos.ElginPayMenu;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import br.com.setis.interfaceautomacao.Confirmacoes;
import br.com.setis.interfaceautomacao.EntradaTransacao;
import br.com.setis.interfaceautomacao.ModalidadesPagamento;
import br.com.setis.interfaceautomacao.Operacoes;
import br.com.setis.interfaceautomacao.SaidaTransacao;
import br.com.setis.interfaceautomacao.Transacoes;

public class ElginPayService {


    private Context context;
    ElginPay pagamento = new ElginPay();

    //USADO PARA ENVIAR E PROCESSAR MENSAGENS
    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            String saida = (String) msg.obj;

            //Guarda o ultimo retorno do Elgin Pay em uma váriavel reservada dentro da atividade que lida com o mesmo.
            ElginPayMenu.saidaUltimaTransacao = saida;

            ElginPayMenu.alertMessageStatus("Retorno ElginPay",ElginPayMenu.saidaUltimaTransacao);
        }
    };

    public ElginPayService(Context c){
        context = c;


    }

    public void IniciarPagamentoDebito(String valor){
        Toast.makeText(context, "Débito", Toast.LENGTH_LONG).show();
        pagamento.iniciarPagamentoDebito(valor, context, handler);
    }

    public void IniciarPagamentoCredito(String valor, int tipoFinanciamento)
    {
        Toast.makeText(context, "Crédito", Toast.LENGTH_LONG).show();
        pagamento.inciarPagamentoCredito(valor, tipoFinanciamento, context, handler);
    }

    public void IniciarCancelamentoVenda(String valor)
    {
        Toast.makeText(context, "Cancelamento", Toast.LENGTH_LONG).show();
        pagamento.iniciarCancelamentoVenda(valor, context, handler);
    }

    public void IniciarOperacaoAdministrativa()
    {
        Toast.makeText(context, "Administrativa", Toast.LENGTH_LONG).show();
        pagamento.iniciarOperacaoAdministrativa(context, handler);
    }

    private class CustomHandler extends Handler{
        ElginPayService ctx;


        public CustomHandler(Looper l, ElginPayService ctx){
            super(l);
            this.ctx = ctx;
        }

        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            String saida = (String) msg.obj;
            Toast.makeText(ctx.context, saida, Toast.LENGTH_LONG).show();
            Log.d("Retorno", saida);
        }
    }


}
