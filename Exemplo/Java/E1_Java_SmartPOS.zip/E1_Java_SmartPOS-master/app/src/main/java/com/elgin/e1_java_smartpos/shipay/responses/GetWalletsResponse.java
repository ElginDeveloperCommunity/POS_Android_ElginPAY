package com.elgin.e1_java_smartpos.shipay.responses;

import com.elgin.e1_java_smartpos.shipay.models.wallet.Wallet;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetWalletsResponse {
    @SerializedName("wallets")
    public List<Wallet> wallets;
}
