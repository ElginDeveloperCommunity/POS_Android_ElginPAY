package com.elgin.e1_java_smartpos;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class PrinterImage extends AppCompatActivity {

    //ImageView
    ImageView imageView;

    //Buttons
    Button buttonSelectImage, buttonPrintImage;

    //Path of image
    Bitmap bitmap;
    String pathImage = "";

    //CheckBox
    CheckBox checkBoxIsCutPaper;

    //Default name of path and file image default
    public static String NAME_IMAGE = "elgin";
    public static String DEF_TYPE = "drawable";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_image);

        //image view
        imageView = findViewById(R.id.previewImgDefault);

        //button
        buttonSelectImage = findViewById(R.id.buttonSelectImage);
        buttonPrintImage = findViewById(R.id.buttonPrintImage);


        //Checkbox
        checkBoxIsCutPaper = findViewById(R.id.checkBoxCutPaperImage);

        if(PrinterMenu.selectedPrinterType.equals("Interna"))  checkBoxIsCutPaper.setVisibility(View.INVISIBLE);

        buttonSelectImage.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                startGallery();
            }
        });

        buttonPrintImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendPrinterImage();
            }
        });
    }

    private void startGallery() {
        Toast.makeText(this, "Selecione uma imagem com no máximo 400 pixels de largura!", Toast.LENGTH_LONG).show();
        Intent cameraIntent = new Intent(Intent.ACTION_PICK);

        cameraIntent.setType("image/*");

        startActivityForResult(cameraIntent, 1000);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == 1000) {
                Uri returnUri = data.getData();

                Bitmap bitmapImage = null;
                try {
                    bitmapImage = MediaStore.Images.Media.getBitmap(this.getContentResolver(), returnUri);
                    setBitmap(bitmapImage);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                imageView.setImageBitmap(bitmapImage);
            }
        } else {
            Toast.makeText(this, "Você não escolheu uma imagem!", Toast.LENGTH_LONG).show();
        }
    }

    public void setBitmap(Bitmap bitmapFileSelected){
        bitmap = bitmapFileSelected;
    }

    public void sendPrinterImage(){
        if(bitmap != null){

            //printerInstance.imprimeImagem(bitmap);
            Log.d("MADARA", String.valueOf(PrinterMenu.printerInstance.imprimeImagem(bitmap)));
        }else{
            int id = 0;

            id = this.getApplicationContext().getResources().getIdentifier(
                    NAME_IMAGE,
                    DEF_TYPE,
                    this.getApplicationContext().getPackageName()
            );
            System.out.println("id: " + id);


            bitmap = BitmapFactory.decodeResource(this.getApplicationContext().getResources(), id);

            //printerInstance.imprimeImagem(bitmap);
            Log.d("MADARA", String.valueOf(PrinterMenu.printerInstance.imprimeImagem(bitmap)));
        }

        jumpLine();
        //if (checkBoxCutPaperImage.isChecked()) cutPaper();
    }

    public void jumpLine(){
        Map<String, Object> mapValues = new HashMap<>();
        mapValues.put("quant", 10);
        PrinterMenu.printerInstance.AvancaLinhas(mapValues);
    }


}