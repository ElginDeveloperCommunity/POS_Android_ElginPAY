package com.elgin.e1_java_smartpos;

import com.elgin.e1_java_smartpos.ElginPayController.*;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

import br.com.setis.interfaceautomacao.Operacoes;

public class ElginPayMenu extends AppCompatActivity {
    ElginPayService elginPayService;
    public static String saidaUltimaTransacao = "";

    //EDIT TEXTs
    EditText editTextValueTEF;


    public static Context ctx;

    //BUTTONS TYPE OF PAYMENTS
    Button buttonCreditOption;
    Button buttonDebitOption;

    //BUTTONS TYPE OF INSTALLMENTS
    Button buttonStoreOption;
    Button buttonAdmOption;
    Button buttonAvistaOption;
    LinearLayout containerTypeInsatllments;

    //BUTTONS ACTIONS TEF
    Button buttonSendTransaction;
    Button buttonCancelTransaction;
    Button buttonConfigsTransaction;

    //INIT DEFAULT OPTIONS
    String selectedPaymentMethod = "Crédito";

    String selectedTefType = "PayGo";
    String selectedAction = "SALE";

    // TYPE OF INSTALLMENTS
    public static final int FINANCIAMENTO_A_VISTA = 0;
    public static final int FINANCIAMENTO_PARCELADO_EMISSOR = 1;
    public static final int FINANCIAMENTO_PARCELADO_ESTABELECIMENTO = 2;

    ////INIT DEFAULT OPTIONS
    int selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elgin_pay_menu);

        elginPayService = new ElginPayService((this));


        ctx = this;

        //INIT EDIT TEXTs
        editTextValueTEF = findViewById(R.id.editTextInputValueTEF);

        //INIT BUTTONS TYPES PAYMENTS
        buttonCreditOption = findViewById(R.id.buttonCreditOption);
        buttonDebitOption = findViewById(R.id.buttonDebitOption);
        containerTypeInsatllments = findViewById(R.id.containerTypeInsatllments);

        //INIT BUTTONS TYPE INSTALLMENTS
        buttonStoreOption = findViewById(R.id.buttonStoreOption);
        buttonAdmOption = findViewById(R.id.buttonAdmOption);
        buttonAvistaOption = findViewById(R.id.buttonAvistaOption);

        //INIT BUTTONS ACTIONS TEF
        buttonSendTransaction = findViewById(R.id.buttonSendTransactionTEF);
        buttonCancelTransaction = findViewById(R.id.buttonCancelTransactionTEF);
        buttonConfigsTransaction = findViewById(R.id.buttonConfigsTEF);

        //SELECT INITIALS OPTION
        buttonCreditOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
        buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));


        //INIT DEFAULT INPUTS
        maskInputValue();
        editTextValueTEF.setText("2000");


        //SELECT OPTION CREDIT PAYMENT
        buttonCreditOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedPaymentMethod = "Crédito";

                buttonCreditOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
                buttonDebitOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
                containerTypeInsatllments.setVisibility(View.VISIBLE);
            }
        });

        //SELECT OPTION DEBIT PAYMENT
        buttonDebitOption.setOnClickListener(new View.OnClickListener() {            @Override
            public void onClick(View v) {
                selectedPaymentMethod = "Débito";

                buttonCreditOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
                buttonDebitOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
                containerTypeInsatllments.setVisibility(View.INVISIBLE);
            }
        });


        //SELECT OPTION STORE INSTALLMENT
        buttonStoreOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_ESTABELECIMENTO;

                buttonStoreOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
                buttonAdmOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
                buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
            }
        });

        //SELECT OPTION ADM INSTALLMENT
        buttonAdmOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedInstallmentsMethod = FINANCIAMENTO_PARCELADO_EMISSOR;

                buttonStoreOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
                buttonAdmOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.verde));
                buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx ,R.color.black));
            }
        });

        //SELECT OPTION AVISTA INSTALLMENT
        buttonAvistaOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedInstallmentsMethod = FINANCIAMENTO_A_VISTA;

                buttonStoreOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx,R.color.black));
                buttonAdmOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx,R.color.black));
                buttonAvistaOption.setBackgroundTintList( AppCompatResources.getColorStateList(ctx,R.color.verde));
            }
        });

        //SELECT BUTTON SEND TRANSACTION
        buttonSendTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEntriesValid()){
                    startActionTEF("SALE");
                }
            }
        });

        //SELECT BUTTON CANCEL TRANSACTION
        buttonCancelTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEntriesValid()) {
                    startActionTEF("CANCEL");
                }
            }
        });

        //SELECT BUTTON CONFIGS TRANSACTION
        buttonConfigsTransaction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isEntriesValid()) {
                    elginPayService.IniciarOperacaoAdministrativa();
                }
            }
        });
    }


    public void startActionTEF(String action){
        selectedAction = action;
        sendElginPayParams(action);
    }

    //Declaração da Classe Handler para receber a saida da transação.
    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            String saida = (String) msg.obj;
            Toast.makeText(getApplicationContext(), saida, Toast.LENGTH_LONG).show();
        }
    };

    public void sendElginPayParams(String action){
        if (isValueInvalidToElginPAY(editTextValueTEF.getText().toString()))
        {
            alertMessageStatus( "Alerta", "O valor para essa transação deve ser maior ou igual a 1.00");
            return;
        }

        if (action.equals("SALE"))
        {
            if (selectedPaymentMethod == "Crédito")
            {
                elginPayService.IniciarPagamentoCredito(cleanInputValue(editTextValueTEF.getText().toString()), selectedInstallmentsMethod);
            }
            else if (selectedPaymentMethod == "Débito")
            {
                elginPayService.IniciarPagamentoDebito(cleanInputValue(editTextValueTEF.getText().toString()));
            }
        }
        if (action.equals("CANCEL"))
        {
            elginPayService.IniciarCancelamentoVenda(cleanInputValue(editTextValueTEF.getText().toString()));
        }
    }

    public void optionReturnElginPay(Map map){
        Map<String, Object> mapValues = new HashMap<>();

        if(map.get("retorno") != null){
            if(map.get("retorno").equals("Transacao autorizada")){
                String imageViaBase64 = (String) map.get("via_impressao");

                byte[] decodedString = Base64.decode(imageViaBase64, Base64.DEFAULT);
                Bitmap decodedByte = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                mapValues.put("quant", 10);
                mapValues.put("base64", imageViaBase64);

                alertImage("Comprovante ElginPAY", decodedByte);
                alertMessageStatus("Alert", map.get("retorno").toString());
            }else{
                alertMessageStatus("Alert", map.get("retorno").toString());
            }
        }else{
            alertMessageStatus("Alert", map.get("retorno").toString());
        }
    }

    public boolean isEntriesValid(){
            if(isValueNotEmpty(editTextValueTEF.getText().toString())){
                return true;
            }else {
                alertMessageStatus("Alerta", "Digite um número de parcelas válido maior que 0.");
                return false;
            }

    }

    public void alertMessageStatus(String titleAlert, String messageAlert){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle(titleAlert);
        alertDialog.setMessage(messageAlert);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public void alertImage(String titleAlert, Bitmap bitmap){
        ImageView image = new ImageView(this);
        image.setImageBitmap(bitmap);
        image.setMinimumHeight(100);

        AlertDialog.Builder builder =
                new AlertDialog.Builder(this).
                        setMessage(titleAlert).
                        setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).
                        setView(image);
        builder.create().show();
    }

    public boolean isValueNotEmpty(String inputTextValue) {
        return !cleanInputValue(inputTextValue).equals("000");
    }

    public boolean isValueInvalidToElginPAY(String inputTextValue){
        double value = Double.parseDouble(inputTextValue.replace(",", "."));
        return value < 1.00;
    }

    public boolean isInstallmentEmptyOrLessThanZero(String inputTextInstallment) {
        if(inputTextInstallment.equals("")){
            return false;
        }else {
            return Integer.parseInt(inputTextInstallment) > 0;
        }
    }

    private void maskInputValue() {
        editTextValueTEF.addTextChangedListener(new InputMaskMoney(editTextValueTEF));
    }

    public String cleanInputValue(String value){
        return InputMaskMoney.cleanInputMaskMoney(value);
    }
}