package com.elgin.e1_java_smartpos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PrinterMenu extends AppCompatActivity {

    //Printer Object
    public static Printer printerInstance;

    //EditTexts
    public static EditText editTextInputIP;

    //Radios
    RadioButton radioButtonConnectPrinterIntern;
    RadioGroup radioGroupConnectPrinterIE;

    //Buttons
    Button buttonPrinterText, buttonPrinterBarCode, buttonPrinterImage, buttonStatusPrinter, buttonStatusDrawer, buttonOpenDrawer;

    //Params
    public static String selectedPrinterType = "Interna";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_menu);

        printerInstance = new Printer(this);
        printerInstance.printerInternalImpStart();


        buttonPrinterText = findViewById(R.id.buttonPrinterText);
        buttonPrinterBarCode = findViewById(R.id.buttonPrinterBarCode);
        buttonPrinterImage = findViewById(R.id.buttonPrinterImage);
        buttonStatusPrinter = findViewById(R.id.buttonStatusPrinter);
        buttonStatusDrawer = findViewById(R.id.buttonStatusDrawer);
        buttonOpenDrawer = findViewById(R.id.buttonOpenDrawer);

        radioButtonConnectPrinterIntern = findViewById(R.id.radioButtonConnectPrinterIntern);
        radioButtonConnectPrinterIntern.setChecked(true);

        editTextInputIP = findViewById(R.id.editTextInputIP);
        editTextInputIP.setText("192.168.0.34:9100");

        radioGroupConnectPrinterIE = findViewById(R.id.radioGroupConnectPrinterIE);
        radioGroupConnectPrinterIE.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radioButtonConnectPrinterIntern:
                        selectedPrinterType = "Interna";
                        printerInstance.printerInternalImpStart();
                        break;

                    case R.id.radioButtonConnectPrinterExtern:
                        if(isIpValid(editTextInputIP.getText().toString())){
                            selectedPrinterType = "Externa";
                            connectExternPrinter(editTextInputIP.getText().toString());
                        }else{
                            alertMessageStatus("Digite um IP válido.");
                            radioButtonConnectPrinterIntern.setChecked(true);
                        }
                        break;
                }
            }
        });


        buttonPrinterText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(PrinterText.class);
            }
        });

        buttonPrinterBarCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(PrinterBarCode.class);
            }
        });

        buttonPrinterImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(PrinterImage.class);
            }
        });

        buttonStatusPrinter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                statusPrinter();
            }
        });

        buttonStatusDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                statusGaveta();
            }
        });

        buttonOpenDrawer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                abrirGaveta();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        printerInstance.printerStop();
    }

    public void statusPrinter(){
        String statusPrinter = "";
        int resultStatus = printerInstance.statusSensorPapel();
        System.out.println("STATUS GAVETA: " + printerInstance.statusGaveta());

        if(resultStatus == 5){
            statusPrinter = "Papel está presente e não está próximo do fim!";
        }else if(resultStatus == 6){
            statusPrinter = "Papel próximo do fim!";
        }else if(resultStatus == 7){
            statusPrinter = "Papel ausente!";
        }else {
            statusPrinter = "Status Desconhecido!";
        }

        alertMessageStatus(statusPrinter);
    }

    private void statusGaveta(){
        String statusGaveta = "";

        int resultStatusGaveta = this.printerInstance.statusGaveta();

        if(resultStatusGaveta == 1){
            statusGaveta = "Gaveta aberta!";
        }else if(resultStatusGaveta == 2){
            statusGaveta = "Gaveta fechada!";
        }else {
            statusGaveta = "Status Desconhecido!";
        }

        alertMessageStatus(statusGaveta);
    }

    private int abrirGaveta(){
        int resultStatusGaveta = this.printerInstance.abrirGaveta();
        return resultStatusGaveta;
    }

    public void alertMessageStatus(String messageAlert){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(messageAlert);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    public static boolean isIpValid(String ip) {
        Pattern pattern = Pattern.compile("^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5]):[0-9]+$");

        Matcher matcher = pattern.matcher(ip);

        return matcher.matches();
    }

    public void startActivity(Class typeOfClass){
        Intent intent = new Intent(this, typeOfClass);
        startActivity(intent );
    }
    public void connectExternPrinter(String ip){
        String[] ipAndPort = ip.split(":");
        int result = printerInstance.printerExternalImpStart(ipAndPort[0], Integer.parseInt(ipAndPort[1]));
        System.out.println("RESULT EXTERN: " + result);
    }

}