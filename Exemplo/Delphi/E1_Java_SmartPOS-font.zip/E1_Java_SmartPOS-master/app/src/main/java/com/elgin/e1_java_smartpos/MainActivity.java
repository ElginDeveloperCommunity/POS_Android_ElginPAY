package com.elgin.e1_java_smartpos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    LinearLayout buttonPrinterMenu, buttonElginPay, buttonDigitalWallet, buttonBarcodeReader;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonPrinterMenu = findViewById(R.id.buttonPrinterMenu);
        buttonElginPay = findViewById(R.id.buttonElginPay);
        buttonDigitalWallet = findViewById(R.id.buttonDigitalWallet);
        buttonBarcodeReader = findViewById(R.id.buttonBarcodeReader);

        buttonPrinterMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(PrinterMenu.class);
            }
        });

        buttonElginPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(ElginPayPage.class);
            }
        });

        buttonDigitalWallet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(ShipayMenu.class);
            }
        });

        buttonBarcodeReader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(BarcodeReader.class);
            }
        });


    }



    public void startActivity(Class typeOfClass){
        Intent intent = new Intent(this, typeOfClass);
        startActivity(intent );
    }
}