package com.elgin.e1_java_smartpos;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.util.Printer;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class PrinterText extends AppCompatActivity {

    Context mContext;

    //Buttons
    Button buttonPrintText, buttonPrinterNFCe, buttonPrinterSAT;


    //EditText messagem
    EditText editTextInputMessage;

    //Alignment
    RadioGroup radioGroupAlign;
    RadioButton buttonRadioCenter;

    //FontFamily/FontSize
    Spinner spinnerFontFamily;
    Spinner spinnerFontSize;

    //Checkbox
    CheckBox checkBoxIsBold;
    CheckBox checkBoxIsUnderLine;
    CheckBox checkBoxIsCutPaper;

    //Initial values
    String typeOfAlignment = "Centralizado";
    String typeOfFontFamily = "FONT A";
    int typeOfFontSize = 17;
    String xmlNFCe = "xmlnfce";
    String xmlSAT = "xmlsat";

    //PARAMS DEFAULT TO PRINT XML NFCe AND SAT
    public static int INDEXCSC = 1;
    public static String CSC = "CODIGO-CSC-CONTRIBUINTE-36-CARACTERES";
    public static int PARAM = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_printer_text);

        mContext = this;

        //INIT EDIT TEXT
        editTextInputMessage = findViewById(R.id.editTextInputMessage);
        editTextInputMessage.setText("ELGIN DEVELOPERS COMMUNITY");

        //INIT RADIOS, SPINNER AND BUTTONS
        radioGroupAlign = findViewById(R.id.radioGroupAlign);
        buttonRadioCenter = findViewById(R.id.radioButtonCenter);
        spinnerFontFamily = findViewById(R.id.spinnerFontFamily);

        spinnerFontSize = findViewById(R.id.spinnerFontSize);

        checkBoxIsBold = findViewById(R.id.checkBoxBold);
        checkBoxIsUnderLine = findViewById(R.id.checkBoxUnderline);
        checkBoxIsCutPaper = findViewById(R.id.checkBoxCutPaper);

        if(PrinterMenu.selectedPrinterType.equals("Interna")) this.checkBoxIsCutPaper.setVisibility(View.INVISIBLE);


        buttonPrintText = findViewById(R.id.buttonPrintText);
        buttonPrinterNFCe = findViewById(R.id.buttonPrinterNFCe);
        buttonPrinterSAT = findViewById(R.id.buttonPrinterSAT);

        buttonPrintText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                printText();
            }
        });

        buttonPrinterNFCe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    printXmlNFCe();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        buttonPrinterSAT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    printXmlSAT();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        //Alignment
        buttonRadioCenter.setChecked(true);
        radioGroupAlign = findViewById(R.id.radioGroupAlign);
        radioGroupAlign.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.radioButtonLeft:
                        typeOfAlignment = "Esquerda";
                        break;
                    case R.id.radioButtonCenter:
                        typeOfAlignment = "Centralizado";
                        break;
                    case R.id.radioButtonRight:
                        typeOfAlignment = "Direita";
                        break;
                }
            }
        });

        //Font Family
        spinnerFontFamily.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }

            @Override
            public void onItemSelected(AdapterView adapter, View v, int i, long lng) {
                typeOfFontFamily = adapter.getItemAtPosition(i).toString();

                if(typeOfFontFamily.equals("FONT B")){
                    checkBoxIsBold.setChecked(false);
                    checkBoxIsBold.setVisibility(View.INVISIBLE);
                }
                else{
                    checkBoxIsBold.setVisibility(View.VISIBLE);
                }
            }
        });

        //Font Size
        spinnerFontSize.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }

            @Override
            public void onItemSelected(AdapterView adapter, View v, int i, long lng) {
                typeOfFontSize = Integer.parseInt(adapter.getItemAtPosition(i).toString());
            }
        });
    }

    public void printText(){
        if(editTextInputMessage.getText().toString().equals("")) {
            alertMessage();
        }else {
            Map<String, Object> mapValues = new HashMap<String, Object>() {{
                put("text", editTextInputMessage.getText().toString());
                put("align", typeOfAlignment);
                put("font", typeOfFontFamily);
                put("fontSize", typeOfFontSize);
                put("isBold", checkBoxIsBold.isChecked());
                put("isUnderline", checkBoxIsUnderLine.isChecked());
                put("quant", 10);
            }};

            PrinterMenu.printerInstance.imprimeTexto(mapValues);

            jumpLine();

            if(checkBoxIsCutPaper.isChecked()) cutPaper();
        }
    }
    public void printXmlNFCe() throws IOException {
        String stringXMLNFCe;

        InputStream ins = mContext.getResources().openRawResource(
                mContext.getResources().getIdentifier(
                        xmlNFCe,
                        "raw",
                        mContext.getPackageName()
                )
        );

        BufferedReader br = new BufferedReader(new InputStreamReader(ins));
        StringBuilder sb = new StringBuilder();
        String line = null;

        try {
            line = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        while (line != null) {
            sb.append(line);
            sb.append(System.lineSeparator());
            line = br.readLine();
        }
        stringXMLNFCe = sb.toString();

        Map<String, Object> mapValues = new HashMap<>();

        mapValues.put("xmlNFCe", stringXMLNFCe);
        mapValues.put("indexcsc", INDEXCSC);
        mapValues.put("csc", CSC);
        mapValues.put("param", PARAM);
        mapValues.put("quant", 10);

        PrinterMenu.printerInstance.imprimeXMLNFCe(mapValues);

        jumpLine();

        if(checkBoxIsCutPaper.isChecked()) cutPaper();
    }

    public void printXmlSAT() throws IOException {
        String stringXMLSat;

        InputStream ins = mContext.getResources().openRawResource(
                mContext.getResources().getIdentifier(
                        xmlSAT,
                        "raw",
                        mContext.getPackageName()
                )
        );

        BufferedReader br = new BufferedReader(new InputStreamReader(ins));
        StringBuilder sb = new StringBuilder();
        String line = null;

        try {
            line = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        while (line != null) {
            sb.append(line);
            sb.append(System.lineSeparator());
            line = br.readLine();
        }
        stringXMLSat = sb.toString();

        Map<String, Object> mapValues = new HashMap<>();

        mapValues.put("xmlSAT", stringXMLSat);
        mapValues.put("param", PARAM);

        PrinterMenu.printerInstance.imprimeXMLSAT(mapValues);

        jumpLine();

        if(checkBoxIsCutPaper.isChecked()) cutPaper();
    }

    public void jumpLine(){
        Map<String, Object> mapValues = new HashMap<>();

        ///Se a impressão for por impressora externa, 5 é o suficiente; 10 caso contrário


        if(!PrinterMenu.printerInstance.isPrinterInternSelected) mapValues.put("quant", 5);
        else mapValues.put("quant", 10);

        PrinterMenu.printerInstance.AvancaLinhas(mapValues);
    }

    public void cutPaper(){
        Map<String, Object> mapValues = new HashMap<>();

        mapValues.put("quant", 1);

        PrinterMenu.printerInstance.cutPaper(mapValues);
    }


    public void alertMessage(){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage("Campo Mensagem vazio.");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
}