package com.elgin.e1_java_smartpos.shipay.models.wallet;

import com.google.gson.annotations.SerializedName;

public class WalletItem {
    @SerializedName("item_title")
    public WalletItemItemTitle item_title;
    @SerializedName("quantity")
    public WalletItemQuantity quantity;
    @SerializedName("type")
    public WalletItemType type;
}
