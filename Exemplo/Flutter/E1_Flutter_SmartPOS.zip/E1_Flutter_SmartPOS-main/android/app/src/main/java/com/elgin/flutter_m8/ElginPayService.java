package com.elgin.flutter_m8;


import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.elgin.e1.Pagamento.ElginPay;


import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import br.com.setis.interfaceautomacao.Confirmacoes;
import br.com.setis.interfaceautomacao.EntradaTransacao;
import br.com.setis.interfaceautomacao.ModalidadesPagamento;
import br.com.setis.interfaceautomacao.Operacoes;
import br.com.setis.interfaceautomacao.SaidaTransacao;
import br.com.setis.interfaceautomacao.Transacoes;
import io.flutter.plugin.common.MethodChannel;

public class ElginPayService {


    private Context context;
    MethodChannel methodChannel;
    ElginPay pagamento = new ElginPay();


    //USADO PARA ENVIAR E PROCESSAR MENSAGENS
    private Handler handler = new Handler(Looper.getMainLooper()){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            String retornoTransacao = "";
            retornoTransacao = (String) msg.obj;
            //Toast.makeText(MainActivity.mContext, saida, Toast.LENGTH_LONG).show();
            Map<String, Object> args = new HashMap<String, Object>();

            args.put("saida", retornoTransacao);
            methodChannel.invokeMethod("elginpayConcluido", args);
        }
    };

    public ElginPayService(Context c){
        context = c;
    }

    public void iniciaVendaDebito(String valor){
       // methodChannel = channel;
        Toast.makeText(context, "Débito", Toast.LENGTH_LONG).show();

        pagamento.iniciaVendaDebito(valor, context, handler);
    }

    public void iniciaVendaCredito(String valor, int tipoFinanciamento, int numeroParcelas)
    {
        //methodChannel = channel;
        Toast.makeText(context, "Crédito", Toast.LENGTH_LONG).show();

        pagamento.iniciaVendaCredito(valor, tipoFinanciamento, numeroParcelas, context, handler);
    }

    public void iniciaCancelamentoVenda(String valor, String saleRef, String date)
    {
        Toast.makeText(context, "Cancelamento", Toast.LENGTH_LONG).show();

        Log.d("DEBUG", "valor: " + valor + " saleRef: " + saleRef + " date:" + date);

        pagamento.iniciaCancelamentoVenda(valor, saleRef, date, context, handler);
    }

    public void iniciaOperacaoAdministrativa()
    {
        Toast.makeText(context, "Administrativa", Toast.LENGTH_LONG).show();

        pagamento.iniciaOperacaoAdministrativa(context, handler);
    }

}
