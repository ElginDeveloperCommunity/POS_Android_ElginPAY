import 'dart:math';

import 'package:flutter/services.dart';

class ElginpayService {
  final _platform = const MethodChannel('samples.flutter.elgin/Printer');

  setHandler(_methodCallHandler) async {
    _platform.setMethodCallHandler(_methodCallHandler);
  }

  Future<String> iniciaVendaDebito({required String value}) async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['Value'] = value;
    mapParam['typeElginpay'] = 'iniciaVendaDébito';

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }

  Future<String> iniciaVendaCredito(
      {required String value, required String installmentMethod, required int numberOfInstallments}) async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['Value'] = value;
    mapParam['typeElginpay'] = 'iniciaVendaCrédito';
    mapParam['installmentMethod'] = installmentMethod;
    mapParam['numberOfInstallments'] = numberOfInstallments;

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }

  Future<String> iniciaCancelamentoVenda({required String value, required String saleRef, required String date}) async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['Value'] = value;
    mapParam['typeElginpay'] = 'iniciaCancelamentoVenda';
    mapParam['saleRef'] = saleRef;
    mapParam['date'] = date;


    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }

  Future<String> iniciaOperacaoAdministrativa() async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['typeElginpay'] = 'iniciaOperacaoAdministrativa';

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }
}
