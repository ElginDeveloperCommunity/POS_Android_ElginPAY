import 'dart:math';

import 'package:flutter/services.dart';

class ElginpayService {
  final _platform = const MethodChannel('samples.flutter.elgin/Printer');

  Future<String> inicializarPagamentoDebito({required String value}) async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['Value'] = value;
    mapParam['typeElginpay'] = 'IniciarPagamentoDébito';

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }

  Future<String> inicializarPagamentoCredito(
      {required String value, required String installmentMethod}) async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['Value'] = value;
    mapParam['typeElginpay'] = 'IniciarPagamentoCrédito';
    mapParam['installmentMethod'] = installmentMethod;

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }

  Future<String> inicializarCancelamento({required String value}) async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['Value'] = value;
    mapParam['typeElginpay'] = 'IniciarCancelamento';

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }

  Future<String> inicializarOperacaoAdministrativa() async {
    Map<String, dynamic> mapParam = new Map();

    mapParam['typeElginpay'] = 'IniciarOperacaoAdministrativa';

    return await _platform.invokeMethod("elginpay", {"args": mapParam});
  }
}
