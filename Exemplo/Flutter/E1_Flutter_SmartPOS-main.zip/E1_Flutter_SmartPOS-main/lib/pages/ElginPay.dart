import 'dart:math';
import 'dart:core';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter_smartpos/Struct/enums.dart';
import 'package:flutter_smartpos/Utils/utils.dart';
import 'package:flutter_smartpos/Widgets/widgets.dart';
import 'package:flutter_smartpos/components/components.dart';
import 'package:flutter_smartpos/services/service_elginpay.dart';
import 'package:flutter_smartpos/services/service_printer.dart';
import 'package:flutter_smartpos/services/service_shipay.dart';

import 'dart:convert';

class ElginPayPage extends StatefulWidget {
  @override
  _ElginPayPageState createState() => _ElginPayPageState();
}

class _ElginPayPageState extends State<ElginPayPage> {
  TextEditingController inputValue = new TextEditingController(text: "20,00");

  ElginpayService elginpayService = new ElginpayService();

  String selectedPaymentMethod = "Crédito";
  String selectedInstallmentsMethod = "Loja";

  String boxText = '';

  PrinterService printerService = new PrinterService();

  @override
  void initState() {
    super.initState();
    printerService.connectInternalImp().then((value) => print(value));
  }

  onChangePaymentMethod(String value) {
    setState(() => selectedPaymentMethod = value);
  }

  onChangeInstallmentsMethod(String value) {
    setState(() => selectedInstallmentsMethod = value);
  }

  sendElginPayParams(String function) async {
    if (function == "SALE") {
      if (selectedPaymentMethod == "Débito") {
        elginpayService.inicializarPagamentoDebito(value: inputValue.text);
      } else {
        elginpayService.inicializarPagamentoCredito(
            value: inputValue.text,
            installmentMethod: this.selectedInstallmentsMethod);
      }
    } else if (function == "CANCEL") {
      elginpayService.inicializarCancelamento(value: inputValue.text);
    } else {
      elginpayService.inicializarOperacaoAdministrativa();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
      child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            GeneralWidgets.headerScreen("ELGIN PAY"),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              child: fieldsMsitef(),
            ),
            GeneralWidgets.baseboard(),
          ],
        ),
      ),
    ));
  }

  Widget fieldsMsitef() {
    return Container(
      height: 410,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          GeneralWidgets.inputField(
            inputValue,
            'VALOR:  ',
            textSize: 14,
            iWidht: 350,
            textInputType: TextInputType.number,
          ),
          Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("FORMAS DE PAGAMENTO:",
                    style:
                        TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
                SizedBox(
                  height: 10,
                ),
                paymentsMethodsWidget(selectedPaymentMethod),
              ],
            ),
          ),
          Container(
              child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("TIPO DE PARCELAMENTO:",
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold)),
              SizedBox(
                height: 10,
              ),
              installmentsMethodsWidget(selectedInstallmentsMethod),
            ],
          )),
          Container(
            child: Column(
              children: [
                Row(
                  children: [
                    GeneralWidgets.personButton(
                        textButton: "ENVIAR TRANSAÇÃO",
                        callback: () => sendElginPayParams("SALE"),
                        width: 160,
                        fontSize: 10),
                    SizedBox(width: 20),
                    GeneralWidgets.personButton(
                        textButton: "CANCELAR TRANSAÇÃO",
                        callback: () => sendElginPayParams("CANCEL"),
                        width: 160,
                        fontSize: 10),
                  ],
                ),
                SizedBox(height: 10),
                GeneralWidgets.personButton(
                    textButton: "CONFIGURAÇÃO",
                    callback: () => sendElginPayParams("CONFIGS"),
                    width: MediaQuery.of(context).size.width,
                    fontSize: 10)
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget paymentsMethodsWidget(String selectedPaymentMethod) {
    return Row(
      children: [
        GeneralWidgets.personSelectedButton(
          nameButton: 'Crédito',
          fontLabelSize: 12,
          assetImage: 'assets/images/card.png',
          isSelectedBtn: selectedPaymentMethod == 'Crédito',
          onSelected: () => onChangePaymentMethod('Crédito'),
        ),
        GeneralWidgets.personSelectedButton(
          nameButton: 'Débito',
          fontLabelSize: 12,
          assetImage: 'assets/images/card.png',
          isSelectedBtn: selectedPaymentMethod == 'Débito',
          onSelected: () => onChangePaymentMethod('Débito'),
        ),
      ],
    );
  }

  Widget installmentsMethodsWidget(String selectedInstall) {
    return Row(
      children: [
        if (selectedPaymentMethod == "Crédito") ...{
          GeneralWidgets.personSelectedButton(
            nameButton: 'Loja',
            fontLabelSize: 12,
            isSelectedBtn: selectedInstall == 'Loja',
            assetImage: 'assets/images/store.png',
            onSelected: () => onChangeInstallmentsMethod('Loja'),
          ),
          GeneralWidgets.personSelectedButton(
            nameButton: 'Adm',
            fontLabelSize: 12,
            isSelectedBtn: selectedInstall == 'Adm',
            assetImage: 'assets/images/adm.png',
            onSelected: () => onChangeInstallmentsMethod('Adm'),
          ),
          GeneralWidgets.personSelectedButton(
            nameButton: 'A vista',
            fontLabelSize: 12,
            isSelectedBtn: selectedInstall == 'Avista',
            assetImage: 'assets/images/card.png',
            onSelected: () => onChangeInstallmentsMethod('Avista'),
          ),
        }
      ],
    );
  }
}
