package com.elgin.flutter_m8;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.elgin.e1.Pagamento.ElginPay;
import com.elgin.e1.Scanner.Scanner;
import com.google.zxing.integration.android.IntentIntegrator;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.plugins.GeneratedPluginRegistrant;

import br.com.setis.interfaceautomacao.Operacoes;

public class MainActivity extends FlutterActivity {
    public static MethodChannel.Result resultFlutter;

    Bundle bundle = new Bundle();
    Printer printer;


    ElginPayService elginPayService;
    //ServiceSat serviceSat;
    Activity activity;
    MethodChannel methodChannel;
    public static Context mContext;
    private IntentIntegrator qrScan;

    Intent intentSitef = new Intent("br.com.softwareexpress.sitef.msitef.ACTIVITY_CLISITEF");
    private String CHANNEL = "samples.flutter.elgin/Printer";

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        GeneratedPluginRegistrant.registerWith(flutterEngine);

        activity = this;
        mContext = this;

        elginPayService = new ElginPayService(this);

        printer = new Printer(activity);

        BinaryMessenger binaryMessenger = flutterEngine.getDartExecutor().getBinaryMessenger();
        methodChannel = new MethodChannel(binaryMessenger, CHANNEL);
        methodChannel.setMethodCallHandler((call, result) -> {
            bundle = new Bundle();
            resultFlutter = result;

            if (call.method.equals("printer")) {
                HashMap map = call.argument("args");
                formatActionPrinter(map);
            }

            if(call.method.equals("scanner")){
                Intent in = Scanner.getScanner(this);
                startActivityForResult(in, 1);
            }

            if(call.method.equals("elginpay")){

                Map map = call.argument("args");
                formatActionElginPay(map);
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if(printer.statusGaveta() != -4){
            Log.d("DEBUG", "PRINTER INITIALIZED, STOPPING IT...");
            printer.printerStop();
        }
        else{
            Log.d("DEBUG", "PRINTER NOT INITIALIZED, DOING NOTHING ON ONDESTROY()..");
        }
    }







    public String cleanInputValue(String value){
        return InputMaskMoney.cleanInputMaskMoney(value);
    }

    public boolean isValueNotEmpty(String inputTextValue) {

        return !cleanInputValue(inputTextValue).equals("000");
    }

    public boolean isValueValidToElginPAY(String inputTextValue){
        double value = Double.parseDouble(inputTextValue.replace(",", "."));

        return value > 1.00;
    }

    public boolean isEntriesValid(String value){
        if(isValueNotEmpty(value)){
            return true;
        }else{
            return false;
        }

    }

    public int finaciamentoValue(String financiamento){
        if(financiamento.equals("Avista")){
            return 0;
        }
        else if(financiamento.equals("Adm")){
            return 1;
        }
        else{
            return 2;
        }
    }

    public void formatActionElginPay(Map map){
        String result = "...";

        if(Objects.equals(map.get("typeElginpay"), "IniciarOperacaoAdministrativa")){
            elginPayService.IniciarOperacaoAdministrativa();

            resultFlutter.success("sucess");
        }

        else if(isEntriesValid((String) map.get("Value"))){
            if(isValueValidToElginPAY((String) map.get("Value"))){
                if(Objects.equals(map.get("typeElginpay"), "IniciarPagamentoDébito")){
                    elginPayService.IniciarPagamentoDebito(cleanInputValue((String) map.get("Value")), methodChannel);
                    resultFlutter.success("sucess");
                }
                else if(Objects.equals(map.get("typeElginpay"), "IniciarPagamentoCrédito")){
                    int tipoFinanciamento = finaciamentoValue((String) map.get("installmentMethod"));

                    elginPayService.IniciarPagamentoCredito(cleanInputValue((String) map.get("Value")), tipoFinanciamento, methodChannel);
                    resultFlutter.success("sucess");
                }
                else if(Objects.equals(map.get("typeElginpay"), "IniciarCancelamento")){
                    elginPayService.IniciarCancelamentoVenda(cleanInputValue((String) map.get("Value")));

                    resultFlutter.success("sucess");
                }
               else{
                    resultFlutter.notImplemented();
                    return;
                }
            }
            else{
                alertMessageStatus( "Alerta", "O valor para essa transação deve ser maior ou igual a 1.00");
            }
        }
        else {
            alertMessageStatus("Alerta", "Digite um valor maior do que 0.");
        }
            resultFlutter.notImplemented();
            return;
    }

    public void formatActionPrinter(Map map) {
        int result = -1;
        if (Objects.equals(map.get("typePrinter"), "printerText")) {
            result = printer.imprimeTexto(map);

        } else if(Objects.equals(map.get("typePrinter"), "printerCupomTEF")){
            result = printer.imprimeCupomTEF(map);

        } else if (Objects.equals(map.get("typePrinter"), "printerBarCode")) {
            result = printer.imprimeBarCode(map);

        } else if (Objects.equals(map.get("typePrinter"), "printerQrCode")) {
            result = printer.imprimeQR_CODE(map);

        } else if (Objects.equals(map.get("typePrinter"), "printerImage")) {
            result = printer.imprimeImagem(map);

        } else if (Objects.equals(map.get("typePrinter"), "printerNFCe")) {
            result = printer.imprimeXMLNFCe(map);

        } else if (Objects.equals(map.get("typePrinter"), "printerSAT")) {
            result = printer.imprimeXMLSAT(map);

        } else if (Objects.equals(map.get("typePrinter"), "jumpLine")) {
            result = printer.AvancaLinhas(map);

        } else if (Objects.equals(map.get("typePrinter"), "gavetaStatus")) {
            result = printer.statusGaveta();

        } else if (Objects.equals(map.get("typePrinter"), "abrirGaveta")) {
            result = printer.abrirGaveta();

        } else if (Objects.equals(map.get("typePrinter"), "printerStatus")) {
            result = printer.statusSensorPapel();

        } else if (Objects.equals(map.get("typePrinter"), "cutPaper")) {
            result = printer.cutPaper(map);

        } else if (Objects.equals(map.get("typePrinter"), "printerConnectExternal")) {
            String ip = (String) map.get("ip");
            int port = (int) map.get("port");
            result = printer.printerExternalImpStart(ip, port);
        } else if (Objects.equals(map.get("typePrinter"), "printerConnectInternal")) {
            result = printer.printerInternalImpStart();
        } else {
            resultFlutter.notImplemented();
            return;
        }
        resultFlutter.success(result);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 3) {
            if (data.getStringExtra("retorno").equals("0")) {
                if(data.getStringExtra("erro") != null){
                    resultFlutter.success(data.getStringExtra("erro"));
                }else{
                    System.out.println("RETORNO: " + data.getStringExtra("mensagem"));
                    resultFlutter.success("ERRO");
                }
            } else {
                resultFlutter.success(data.getStringExtra("mensagem"));
            }
        }
        if(requestCode == 1){
            if (resultCode == 2) {
                String[] result = data.getStringArrayExtra("result");
                CharSequence cs;

                if (result[0].equals("1")) {
                    cs =  result[1] + ":+-" + result[3];
                    resultFlutter.success(cs);
                } else {
                    cs = "Erro # " + result[0] + " na leitura do código.";
                    Toast.makeText(this, cs, Toast.LENGTH_LONG).show();
                    resultFlutter.success("error");
                }
            }
        }
    }

    public void alertMessageStatus(String titleAlert, String messageAlert){
        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle(titleAlert);
        alertDialog.setMessage(messageAlert);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }
}
