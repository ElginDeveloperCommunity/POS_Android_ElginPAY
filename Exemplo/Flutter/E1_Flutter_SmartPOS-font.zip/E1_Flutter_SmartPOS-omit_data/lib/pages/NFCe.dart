import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_smartpos/pages/ElginPay.dart';
import 'package:flutter_smartpos/services/service_nfce.dart';
import 'package:flutter_smartpos/services/service_printer.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../Widgets/widgets.dart';

class NFCePage extends StatefulWidget {
  @override
  _NFCePageState createState() => _NFCePageState();
}

class _NFCePageState extends State<NFCePage> {
  final NfceService nfceService = new NfceService();
  final PrinterService printerService = new PrinterService();

  @override
  void initState() {
    super.initState();

    connectInternalImp();
  }

  final TextEditingController productName =
      new TextEditingController(text: "CAFE");
  final TextEditingController productPrice =
      new TextEditingController(text: "8,00");
  final TextEditingController emitionTime = new TextEditingController(text: "");
  final TextEditingController nfceNumber = new TextEditingController(text: "");
  final TextEditingController nfceSerie = new TextEditingController(text: "");
  bool isNfceButtonEnabled = false;

  void sendConfigurateXmlNFCe() async {
    final String configurateXmlNFCeResult =
        await nfceService.configurateXmlNFCE();

    if (configurateXmlNFCeResult == 'Success') {
      setState(() {
        isNfceButtonEnabled = true;
      });

      Fluttertoast.showToast(
          msg: "NFC-e configurada com sucesso!",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.green,
          textColor: Colors.white,
          fontSize: 16.0);
    } else
      Fluttertoast.showToast(
          msg: "Erro na configuração de NFC-e!",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
  }

  void sendSaleNfce() async {
    print(productName.text.toString() + " " + getProductPriceFormatted());
    final String sendSaleNfceResult = await nfceService.sendSaleNFCE(
        productName: productName.text.toString(),
        productPrice: getProductPriceFormatted());

    if (sendSaleNfceResult == "ERROR_SALE_CONFIGURATION")
      Fluttertoast.showToast(
          msg: "Erro na configuração de venda!",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);

    //Se nao ocorreu erro na configuração da venda, os únicos cenários possíveis são a nota foi emitida online ou em contigência, em ambos os casos deve-se expor o número e série da nota
    //Se a nota foi emitida online deverá ser exposto o tempo em segundos que a emissão levou.
    final List<String> it4rResponses = sendSaleNfceResult.split('|');

    if (it4rResponses[0] == "SUCCESS_CONTINGENCY") {
      GeneralWidgets.showAlertDialog(
          mainWidgetContext: context,
          dialogTitle: "NFC-e",
          dialogText:
              "Erro ao emitir NFC-e online, a impressão será da nota em contigência!");
      setState(() {
        this.nfceNumber.text = it4rResponses[1];
        this.nfceSerie.text = it4rResponses[2];
      });
    } else {
      GeneralWidgets.showAlertDialog(
          mainWidgetContext: context,
          dialogTitle: "NFC-e",
          dialogText: "NFC-e emitida com sucesso!");

      print(it4rResponses);
      setState(() {
        this.emitionTime.text =
            (it4rResponses[0] != "0") ? it4rResponses[0] + " SEGUNDOS" : "";
        this.nfceNumber.text = it4rResponses[1];
        this.nfceSerie.text = it4rResponses[2];
      });
    }
  }

  String getProductPriceFormatted() {
    return this.productPrice.text.toString().replaceAll(',', '.');
  }

  connectInternalImp() async {
    int result = await printerService.connectInternalImp();
    print("Internal: " + result.toString());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Image.asset("assets/images/elgin_logo.png", height: 80),
            ),
            Column(
              children: [
                mainBox(),
                SizedBox(
                  height: 10,
                ),
                emitionTimeBox(),
                SizedBox(
                  height: 10,
                ),
                nfceInfoBox()
              ],
            ),
            GeneralWidgets.baseboard(),
          ],
        ),
      )),
    );
  }

  Widget nfceInfoBox() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 3),
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
        child: Padding(
          padding: EdgeInsets.all(8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Text(
                "NOTA N°:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: 90,
                child: TextFormField(
                    textAlign: TextAlign.center,
                    enabled: false,
                    controller: nfceNumber,
                    decoration: new InputDecoration(
                      border: InputBorder.none,
                    )),
              ),
              Text(
                "SÉRIE N°:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: 50,
                child: TextFormField(
                    textAlign: TextAlign.center,
                    enabled: false,
                    controller: nfceSerie,
                    decoration: new InputDecoration(
                      border: InputBorder.none,
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget emitionTimeBox() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 3),
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "TEMPO DE EMISSÃO:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(
                width: 150,
                child: TextFormField(
                    textAlign: TextAlign.center,
                    enabled: false,
                    controller: emitionTime,
                    decoration: new InputDecoration(
                      border: InputBorder.none,
                    )),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget mainBox() {
    final CurrencyTextInputFormatter _formatter =
        new CurrencyTextInputFormatter(
            decimalDigits: 2,
            locale: 'pt_BR',
            symbol: '',
            turnOffGrouping: true);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.black, width: 3),
          borderRadius: BorderRadius.all(Radius.circular(16)),
        ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              GeneralWidgets.inputField(productName, 'NOME DO PRODUTO:',
                  textSize: 14, iWidht: 350, textInputType: TextInputType.text),
              GeneralWidgets.inputFieldWithFormatter(
                  productPrice, 'PREÇO DO PRODUTO:', _formatter,
                  textSize: 14,
                  iWidht: 350,
                  textInputType: TextInputType.number),
              SizedBox(
                height: 25,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GeneralWidgets.personButton(
                      textButton: 'CONFIGURAR NFCE',
                      width: (MediaQuery.of(context).size.width - 50) / 2,
                      height: 35,
                      callback: () => sendConfigurateXmlNFCe()),
                  GeneralWidgets.personButton(
                      textButton: 'ENVIAR VENDA NFCE',
                      width: (MediaQuery.of(context).size.width - 50) / 2,
                      height: 35,
                      callback: () => sendSaleNfce(),
                      isButtonEnabled: isNfceButtonEnabled),
                ],
              )
            ],
          ),
        ),
      ),
    );
  }
}
