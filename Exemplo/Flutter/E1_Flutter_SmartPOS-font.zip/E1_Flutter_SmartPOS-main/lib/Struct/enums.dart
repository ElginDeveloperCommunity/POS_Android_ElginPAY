//SITEF
enum FunctionSitef { SALE, CANCELL, CONFIGS }
